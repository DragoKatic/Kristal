﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;

public partial class Nezaposleni_Samoaktualizacija : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!this.IsPostBack)
        {
            UcitajPodatke_Pitanja();
            UcitajPodatke_Bodovi();
        }
    }

    protected void UcitajPodatke_Pitanja()
    {
        Label1.Text = "Mislim da sam postigao/la maksimum u odnosu na mogućnosti koje sam imao/la.";
        Label2.Text = "U suštini sam zadovoljan/na svojim životom.";
        Label3.Text = "Najveći broj dana se osećam srećno I ispunjeno.";
        Label4.Text = "Imam osećaj da svojim radom doprinosim nečemu.";
        Label5.Text = "Sposoban/na sam da uradim većinu stvari.";
        Label6.Text = "Često iznosim svoje mišljenje jer mi se čini da ono što bih rekao/la jeste važno.";
        Label7.Text = "Retko tražim pomoć od kolega.";
        Label8.Text = "Mislim da sam u svom timu jedan od bitnijih igrača.";
        Label9.Text = "Ljudi poštuju moje mišljenje i to sa razlogom.";
        Label10.Text = "Verujem da sam postigao/la više od većine ljudi iz moje generacije.";
        Label11.Text = "Mislim da mom napretku nema granica.";
        Label12.Text = "Često se osećam ponosnim na sebe.";
        Label13.Text = "Smatram da sam u životu postigao/la sve što je bilo moguće.";
        Label14.Text = "Mislim da postoji perspektiva u onom čim se bavim.";
        Label15.Text = "Osećam se sigurno u vezi sa svojim poslom.";
        Label16.Text = "Vidim sebe kao važnog člana radne organizacije u kojoj sam angažovan.";
        Label17.Text = "Osećam se sposobnijim od svojih saradnika.";
        Label18.Text = "Kada u nečemu uspem to je obično zbog mojih sposobnosti i truda.";
        Label19.Text = "Mislim da sam uspešniji/a od većine ljudi koje poznajem.";
        Label20.Text = "Verujem u sebe.";
    }

    protected void UcitajPodatke_Bodovi()
    {
        for (int i = 1; i <= 4; i++)
        {
            DropDownList1.Items.Add(i.ToString());
            DropDownList2.Items.Add(i.ToString());
            DropDownList3.Items.Add(i.ToString());
            DropDownList4.Items.Add(i.ToString());
            DropDownList5.Items.Add(i.ToString());
            DropDownList6.Items.Add(i.ToString());
            DropDownList7.Items.Add(i.ToString());
            DropDownList8.Items.Add(i.ToString());
            DropDownList9.Items.Add(i.ToString());
            DropDownList10.Items.Add(i.ToString());
            DropDownList11.Items.Add(i.ToString());
            DropDownList12.Items.Add(i.ToString());
            DropDownList13.Items.Add(i.ToString());
            DropDownList14.Items.Add(i.ToString());
            DropDownList15.Items.Add(i.ToString());
            DropDownList16.Items.Add(i.ToString());
            DropDownList17.Items.Add(i.ToString());
            DropDownList18.Items.Add(i.ToString());
            DropDownList19.Items.Add(i.ToString());
            DropDownList20.Items.Add(i.ToString());
        }
    }
    protected void cmdSnimiPodatkeSamoaktualizacija_Click(object sender, EventArgs e)
    {
        Samoaktualizacija s = new Samoaktualizacija();

        s.Postignuce = DropDownList1.SelectedValue.ToString();
        s.Zadovoljstvo = DropDownList2.SelectedValue.ToString();
        s.Ispunjenost = DropDownList3.SelectedValue.ToString();
        s.Korisnost = DropDownList4.SelectedValue.ToString();
        s.Sposobnost = DropDownList5.SelectedValue.ToString();
        s.Ekspresivnost = DropDownList6.SelectedValue.ToString();
        s.Samostalnost = DropDownList7.SelectedValue.ToString();
        s.Vaznost = DropDownList8.SelectedValue.ToString();
        s.Postovanje = DropDownList9.SelectedValue.ToString();
        s.Uspesnost = DropDownList10.SelectedValue.ToString();
        s.Neogranicenost = DropDownList11.SelectedValue.ToString();
        s.Ponos = DropDownList12.SelectedValue.ToString();
        s.Ostvarenost = DropDownList13.SelectedValue.ToString();
        s.Perspektivnost = DropDownList14.SelectedValue.ToString();
        s.Sigurnost = DropDownList15.SelectedValue.ToString();
        s.Svrsishodnost = DropDownList16.SelectedValue.ToString();
        s.Ambicioznost = DropDownList17.SelectedValue.ToString();
        s.Realnost = DropDownList18.SelectedValue.ToString();
        s.Razlicitost = DropDownList19.SelectedValue.ToString();
        s.Samouverenost = DropDownList20.SelectedValue.ToString();

        s.SnimiPodatke_TabelaSamoaktualizacija(
            s.Postignuce,
            s.Zadovoljstvo,
            s.Ispunjenost,
            s.Korisnost,
            s.Sposobnost,
            s.Ekspresivnost,
            s.Samostalnost,
            s.Vaznost,
            s.Postovanje,
            s.Uspesnost,
            s.Neogranicenost,
            s.Ponos,
            s.Ostvarenost,
            s.Perspektivnost,
            s.Sigurnost,
            s.Svrsishodnost,
            s.Ambicioznost,
            s.Realnost,
            s.Razlicitost,
            s.Samouverenost);
    }
}

﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;

public partial class Nezaposleni_OsnovnoObrazovanje : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        UcitajPodatke_VozackaDozvola();
        UcitajPodatke_StraniJezici();
        UcitajPodatke_Godine();
        UcitajPodatke_StepenZavrsenogSkolovanja();
    }

    protected void UcitajPodatke_Godine()
    {
        lstGodinaZavrsetkaSkolovanja.Items.Add("Godina");
        for (int i = 1950; i <= 2011; i++)
        {
            lstGodinaZavrsetkaSkolovanja.Items.Add(i.ToString());
        }
    }

    protected void UcitajPodatke_VozackaDozvola()
    {
        lstVozackaDozvola.Items.Add("Izaberite:");
        lstVozackaDozvola.Items.Add("Nemam");
        lstVozackaDozvola.Items.Add("B kategorija");
        lstVozackaDozvola.Items.Add("B i druge kategorije");
    }

    protected void UcitajPodatke_StraniJezici()
    {
        lstEngleskiNivo.Items.Add("Izaberite:");
        lstEngleskiNivo.Items.Add("Ne znam");
        lstEngleskiNivo.Items.Add("Pasivno");
        lstEngleskiNivo.Items.Add("Govorno");
        lstEngleskiNivo.Items.Add("Tečno govorim i pišem");

        lstDrugiStraniJezikNivo.Items.Add("Izaberite:");
        lstDrugiStraniJezikNivo.Items.Add("Ne znam");
        lstDrugiStraniJezikNivo.Items.Add("Pasivno");
        lstDrugiStraniJezikNivo.Items.Add("Govorno");
        lstDrugiStraniJezikNivo.Items.Add("Tečno govorim i pišem");

        lstFrancuskiNivo.Items.Add("Izaberite:");
        lstFrancuskiNivo.Items.Add("Ne znam");
        lstFrancuskiNivo.Items.Add("Pasivno");
        lstFrancuskiNivo.Items.Add("Govorno");
        lstFrancuskiNivo.Items.Add("Tečno govorim i pišem");

        lstItalijanskiNivo.Items.Add("Izaberite:");
        lstItalijanskiNivo.Items.Add("Ne znam");
        lstItalijanskiNivo.Items.Add("Pasivno");
        lstItalijanskiNivo.Items.Add("Govorno");
        lstItalijanskiNivo.Items.Add("Tečno govorim i pišem");

        lstNemackiNivo.Items.Add("Izaberite:");
        lstNemackiNivo.Items.Add("Ne znam");
        lstNemackiNivo.Items.Add("Pasivno");
        lstNemackiNivo.Items.Add("Govorno");
        lstNemackiNivo.Items.Add("Tečno govorim i pišem");

        lstRuskiNivo.Items.Add("Izaberite:");
        lstRuskiNivo.Items.Add("Ne znam");
        lstRuskiNivo.Items.Add("Pasivno");
        lstRuskiNivo.Items.Add("Govorno");
        lstRuskiNivo.Items.Add("Tečno govorim i pišem");
    }

    protected void UcitajPodatke_StepenZavrsenogSkolovanja()
    {
        lstStepenSkolovanja.Items.Add("Izaberite");
        lstStepenSkolovanja.Items.Add("Osnovna škola");
        lstStepenSkolovanja.Items.Add("Srednja škola");
        lstStepenSkolovanja.Items.Add("Viša škola");
        lstStepenSkolovanja.Items.Add("Bachelor (BA)");
        lstStepenSkolovanja.Items.Add("Master/Spec. (MA/MS)");
        lstStepenSkolovanja.Items.Add("Doktorske studije (PhD)");
    }
    protected void cmdSnimiPodatke_TabelaOsnovnoObrazovanje_Click(object sender, EventArgs e)
    {
        OsnovnoObrazovanje db = new OsnovnoObrazovanje();
        db.VozackaDozvola = lstVozackaDozvola.SelectedValue.ToString();
        db.EngleskiJezikNivo = lstEngleskiNivo.SelectedValue.ToString();
        db.FrancuskiJezikNivo = lstFrancuskiNivo.SelectedValue.ToString();
        db.NemackiJezikNivo = lstNemackiNivo.SelectedValue.ToString();
        db.ItalijanskiJezikNivo = lstItalijanskiNivo.SelectedValue.ToString();
        db.RuskiJezikNivo = lstRuskiNivo.SelectedValue.ToString();
        db.DrugiJezik = txtDrugiStraniJezikNaziv.Text;
        db.DrugiJezikNivo = lstDrugiStraniJezikNivo.SelectedValue.ToString();
        db.StepenSkolovanja = lstStepenSkolovanja.SelectedValue.ToString();
        db.NazivSkole = txtNazivSkole.Text;
        db.SmerStudija = txtSmerStudija.Text;
        db.GodinaZavrsetkaSkole = lstGodinaZavrsetkaSkolovanja.SelectedValue.ToString();
        db.OblastMagistrature = txtOblastMagistrature.Text;
        db.OblastDoktorata = txtOblastDoktorata.Text;
        db.SpecijalistickaZnanja = txtSpecijalistickaZnanja.Text;
        db.DrugaObrazovanja = txtDrugaObrazovanja.Text;
        db.PromeneUPoslu = txtPromeneUPoslu.Text;
        db.KnjigeOPoslu = txtKnjigeOPoslu.Text;
        db.StandardiUPoslu = txtStandardiUPoslu.Text;

        db.SnimiPodatke_TabelaOsnovnoObrazovanje(
            db.VozackaDozvola,
            db.EngleskiJezikNivo,
            db.FrancuskiJezikNivo,
            db.NemackiJezikNivo,
            db.ItalijanskiJezikNivo,
            db.RuskiJezikNivo,
            db.DrugiJezik,
            db.DrugiJezikNivo,
            db.StepenSkolovanja,
            db.NazivSkole,
            db.SmerStudija,
            db.GodinaZavrsetkaSkole,
            db.OblastMagistrature,
            db.OblastDoktorata,
            db.SpecijalistickaZnanja,
            db.DrugaObrazovanja,
            db.PromeneUPoslu,
            db.KnjigeOPoslu,
            db.StandardiUPoslu);
    }
}
﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;
using System.Data.OleDb;
using System.Web.Configuration;

public partial class Nezaposleni_PonudaRadnihMesta : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            UcitajPodatke_PoslovniOglasi();
        }
    }
    private string connectionStringKristal =
            WebConfigurationManager.ConnectionStrings[
            "KristalKonekcija"].ConnectionString;

    protected void UcitajPodatke_PoslovniOglasi()
    {
        ddlPoslovniOglasi.Items.Clear();

        string greska = "";
        string selectTabelaPoslovniOglas =
            "SELECT `korisnik_id`, `naziv`, `radno_mesto`, `mesto` FROM `TabelaPoslovniOglas`";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(selectTabelaPoslovniOglas, con);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                ListItem newItem = new ListItem();
                newItem.Text = reader["naziv"] + "  " + reader["radno_mesto"] + "  " + reader["mesto"];
                newItem.Value = reader["korisnik_id"].ToString();
                ddlPoslovniOglasi.Items.Add(newItem);
            }

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void UcitajPodatke_TabelaPoslovniOglas()
    {
        string greska = "";
        string selectTabelaPoslovniOglas =
        "SELECT * FROM [TabelaPoslovniOglas] WHERE ([korisnik_id] = '" + ddlPoslovniOglasi.SelectedItem.Value + "')";
       // "UPDATE `TabelaPoslovniOglas` SET `naziv` = ?, `radno_mesto` = ?, `mesto` = ?, `opstina` = ?, `kategorija` = ?, `min_stepen_obrazovanja` = ?, `max_stepen_obrazovanja` = ?, `oglas` = ?, `obavestenje` = ?, `e_mail` = ?, `web_site` = ? WHERE `korisnik_id` = ?"

        lblEMail.Text = "";
        lblKategorija.Text = "";
        lblMaxStepenObrazovanja.Text = "";
        lblMesto.Text = "";
        lblMinStepenObrazovanja.Text = "";
        lblNaziv.Text = "";
        lblNazivRadnogMesta.Text = "";
        lblOglas.Text = "";
        lblOpstina.Text = "";
        lblWebSajt.Text = "";


        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(selectTabelaPoslovniOglas, con);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            lblKategorija.Text += reader["kategorija"];
            lblNazivRadnogMesta.Text += reader["radno_mesto"];
            lblEMail.Text += reader["e_mail"];
            lblMaxStepenObrazovanja.Text += reader["max_stepen_obrazovanja"];
            lblMesto.Text += reader["mesto"];
            lblMinStepenObrazovanja.Text += reader["min_stepen_obrazovanja"];
            lblNaziv.Text += reader["naziv"];
            lblOglas.Text += reader["oglas"];
            lblOpstina.Text += reader["opstina"];
            lblWebSajt.Text += reader["web_site"];

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void ddlPoslovniOglasi_SelectedIndexChanged1(object sender, EventArgs e)
    {
        lblKorisnikID.Text = ddlPoslovniOglasi.SelectedItem.Value.ToString();
        UcitajPodatke_TabelaPoslovniOglas();
    }
}

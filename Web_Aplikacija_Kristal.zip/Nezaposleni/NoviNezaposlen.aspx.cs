﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.IO;
using KristalBiblioteka;

public partial class Nezaposleni_NoviNezaposlen : System.Web.UI.Page
{
    private string uploadDirectory;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            uploadDirectory = Path.Combine(Request.PhysicalApplicationPath, "Fotografije_Korisnika");
            UcitajPodatke_Dani();
            UcitajPodatke_Meseci();
            UcitajPodatke_Godine();
        }
    }

    protected void UcitajPodatke_Dani()
    {
        lstDan.Items.Add("Dan");
        for (int i = 1; i <= 31; i++)
        {
            lstDan.Items.Add(i.ToString());
        }
    }

    protected void UcitajPodatke_Meseci()
    {
        lstMesec.Items.Add("Mesec");
        lstMesec.Items.Add("Januar");
        lstMesec.Items.Add("Februar");
        lstMesec.Items.Add("Mart");
        lstMesec.Items.Add("April");
        lstMesec.Items.Add("Maj");
        lstMesec.Items.Add("Jun");
        lstMesec.Items.Add("Jul");
        lstMesec.Items.Add("Avgust");
        lstMesec.Items.Add("Septembar");
        lstMesec.Items.Add("Oktobar");
        lstMesec.Items.Add("Novembar");
        lstMesec.Items.Add("Decembar");
    }

    protected void UcitajPodatke_Godine()
    {
        lstGodina.Items.Add("Godina");
        for (int i = 1950; i <= 2011; i++)
        {
            lstGodina.Items.Add(i.ToString());
        }
    }

    protected void cmdUpload_Click(object sender, EventArgs e)
    {
        if (Uploader.PostedFile.FileName == "")
        {
            lblInfo.Text = "Niste odabrali fotografiju.";
        }
        else
        {
            string extension = Path.GetExtension(Uploader.PostedFile.FileName);

            switch (extension.ToLower())
            {
                case ".jpg":
                    break;
                default:
                    lblInfo.Text = "Tip fotografije nije adekvatan.<br />Fotografija treba da ima \".jpg\" ekstenziju.";
                    return;
            }

            KorisnickiPodaci korisnik = new KorisnickiPodaci();
            string ImageName = korisnik.ObezbediKorisnickiKljuc();

            uploadDirectory = Path.Combine(Request.PhysicalApplicationPath, "Fotografije_Korisnika" + @"\");
            if (!System.IO.Directory.Exists(uploadDirectory))
                System.IO.Directory.CreateDirectory(uploadDirectory);


            string serverFileName = Path.GetFileName(ImageName + extension);
            string fullUploadPath = Path.Combine(uploadDirectory, serverFileName);

            Fotografije fotografija = new Fotografije();
            fotografija.PutanjaDoFotografije = "~/Fotografije_Korisnika" + @"/" + serverFileName;
            fotografija.SnimiPodatke_TabelaFotografije(fotografija.PutanjaDoFotografije);

            try
            {
                Uploader.PostedFile.SaveAs(fullUploadPath);
                lblInfo.Text = "Fotografija  je uspešno snimljena.";
            }
            catch (Exception err)
            {
                lblInfo.Text = err.Message;
            }
        }
    }

    protected void cmdSnimiPodatke_TabelaOsnovniPodaci_Click(object sender, EventArgs e)
    {
        OsnovniPodaci db = new OsnovniPodaci();
        db.Ime = txtIme.Text;
        db.Prezime = txtPrezime.Text;
        db.Pol = rbtnPol.SelectedValue.ToString();
        db.DatumRodjenja =
            lstDan.SelectedValue.ToString() + ". " +
            lstMesec.SelectedValue.ToString() + " " +
            lstGodina.SelectedValue.ToString() + ".";
        db.Drzavljanstvo = txtDrzavljanstvo.Text;
        db.BracnoStanje = rbtnBracnoStanje.SelectedValue.ToString();
        db.Adresa =
            txtUlica.Text + " " +
            txtUlaz.Text + "/" +
            txtStan.Text + ".";
        db.PostanskiBroj = txtPostanskiBroj.Text;
        db.Grad = txtGrad.Text;
        db.Opstina = txtOpstina.Text;
        db.Drzava = txtDrzava.Text;
        db.KucniTelefon = "+" +
            txtIzlazKucniTelefon.Text + " (" +
            txtPozivniKucniTelefon.Text + ") " +
            txtPrviDeoKucniTelefon.Text + "/" +
            txtDrugiDeoKucniTelefon.Text;
        db.MobilniTelefon = "+" +
            txtIzlazMobilniTelefon.Text + " (" +
            txtPozivniMobilniTelefon.Text + ") " +
            txtPrviDeoMobilniTelefon.Text + "/" +
            txtDrugiDeoMobilniTelefon.Text;
        db.WebSite = txtWebSite.Text;

        db.SnimiPodatke_TabelaOsnovniPodaci(
            db.Ime,
            db.Prezime,
            db.Pol,
            db.DatumRodjenja,
            db.Drzavljanstvo,
            db.BracnoStanje,
            db.Adresa,
            db.PostanskiBroj,
            db.Grad,
            db.Opstina,
            db.Drzava,
            db.KucniTelefon,
            db.MobilniTelefon,
            db.WebSite);
    }
}
﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;

public partial class Nezaposleni_OpstaInteresovanja : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            UcitajGodine();
            UcitajOcene();
            UcitajPitanja();
        }
    }

    protected void UcitajGodine()
    {
        for (int i = 1; i <= 16; i++)
        {
            dropDownListLinuxGodineIskustva.Items.Add(i.ToString());
            dropDownListOfficeGodineIskustva.Items.Add(i.ToString());
            dropDownListWinGodineIskustva.Items.Add(i.ToString());
        }
    }

    protected void UcitajOcene()
    {
        for (int i = 1; i <= 16; i++)
        {
            dropDownListLinuxOcena.Items.Add(i.ToString());
            dropDownListOfficeOcena.Items.Add(i.ToString());
            dropDownListWinOcena.Items.Add(i.ToString());
        }
    }

    protected void UcitajPitanja()
    {
        lblPitanjeAktivnostiIProjekti.Text = 
            "Ukratko opišite Vaše projekte/aktivnosti koji nemaju veze sa poslom za koji se prijavljujete i njihov status.";
        lblPitanjeEkspertiza.Text =
            "U kojoj oblasti smatrate da ste ekspert i zašto?";
        lblPitanjeHobi.Text =
            "Vaš hobi (Čime se bavite u slobodno vreme)?";
        lblPitanjeLinux.Text =
            "Poznavanje rada u Linux-u?";
        lblPitanjeOblastiKojeVolite.Text =
            "Koje oblasti u okviru posla za koji se prijavljujete volite i zašto?";
        lblPitanjeOffice.Text =
            "Poznavanje Office aplikacija?";
        lblPitanjeOmiljenaArhitektura.Text =
            "Koja je vaša omiljena arhitektura računara?";
        lblPitanjeOmoljeniOs.Text =
            "Koji je Vaš omiljeni operativni sistem?";
        lblPitanjePonosIPosao.Text =
            "Na šta ste najviše ponosni od stvari koje ste uradili u okviru poslova kojim ste se bavili?";
        lblPitanjePosaoUSlobodnoVreme.Text =
            "Da li se u slobodno vreme bavite poslom za koji se priavljujete i u kom obliku?";
        lblPitanjeWin.Text =
            "Poznavanje rada u Windows-u?";
    }

    protected void cmdSnimiPodatkeOpstaInteresovanja_Click(object sender, EventArgs e)
    {
        OpstaInteresovanja o = new OpstaInteresovanja();

        o.AktivnostiProjekti = txtOdgovorAktivnostiIProjekti.Text;
        o.Ekspertiza = txtOdgovorEkspertiza.Text;
        o.Hobi = txtOdgovorHobi.Text;
        o.LinuxGodine = dropDownListLinuxGodineIskustva.SelectedValue.ToString();
        o.LinuxOcena = dropDownListLinuxOcena.SelectedValue.ToString();
        o.LinuxOpis = txtOdgovorLinux.Text;
        o.OblastiKojeVolite = txtOdgovorOblastiKojeVolite.Text;
        o.OfficeGodine = dropDownListOfficeGodineIskustva.SelectedValue.ToString();
        o.OfficeOcena = dropDownListOfficeOcena.SelectedValue.ToString();
        o.OfficeOpis = txtOdgovorOffice.Text;
        o.OmiljenaArhitektura = txtOdgovorOmiljenaArhitektura.Text;
        o.OmiljeniOs = txtOdgovorOmiljeniOs.Text;
        o.PonosIPosao = txtOdgovorPonosIPosao.Text;
        o.PosaoUSlobodnoVreme = txtOdgovorPosaoUSlobodnoVreme.Text;
        o.WinGodine = dropDownListWinGodineIskustva.SelectedValue.ToString();
        o.WinOcena = dropDownListWinOcena.SelectedValue.ToString();
        o.WinOpis = txtOdgovorWin.Text;

        o.SnimiPodatke_TabelaOpstaInteresovanja(
            o.WinOcena,
            o.WinGodine,
            o.WinOpis,
            o.LinuxOcena,
            o.LinuxGodine,
            o.LinuxOpis,
            o.OfficeOcena,
            o.OfficeGodine,
            o.OfficeOpis,
            o.OmiljeniOs,
            o.OmiljenaArhitektura,
            o.Hobi,
            o.PosaoUSlobodnoVreme,
            o.Ekspertiza,
            o.OblastiKojeVolite,
            o.PonosIPosao,
            o.AktivnostiProjekti);
    }
}

﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;

public partial class Nezaposleni_Kredibilitet : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            UcitajPitanja();
        }
    }

    protected void UcitajPitanja()
    {
        lblPitanjeKogaZaposljavate.Text =
            "Šta je ono što ima najviše uticaja na Vašu odluku da nekoga zaposlite?";
        lblPitanjeKomePoveravatePosao.Text =
            "Koliko osobe kojima poveravate posao veruju u Vas?";
        lblPitanjeOsobeBezKredibiliteta.Text =
            "Da li postoje osobe bez kredibiliteta?";
        lblPitanjeOsobeKojePrihvatajuGreske.Text =
            "Da li se smanjuje kredibilitet kod osoba koje prihvataju svoje greške?";
        lblPitanjePopravkaKredibiliteta.Text =
            "Da li se kredibilitet može popraviti?";
        lblPitanjePovracajPoverenja.Text =
            "Koliko imate poverenja u osobu koja Vas je jednom već izneverila?";
        lblPitanjeProveraPoverenja.Text =
            "Kako proveravate poverenje?";
        lblPitanjeStaJeKredibilitet.Text =
            "Šta je kredibilitet?";
        lblPitanjeStaZaVasZnaciKredibilitet.Text =
            "Šta za vas znači kredibilitet?";
        lblPitanjeVaznostPoverenja.Text =
            "Da li je poverenje važno u poslu?";
        lblPitanjeVaznostSamosvesnosti.Text =
            "Koliko je važno da osoba bude svesna svojih mana?";
        lblPitanjeVaznostTacnosti.Text =
            "Koliko je tačnost važna za shvatanje ozbiljnosti neke osobe?";
    }
    protected void cmdSnimiPodatkeKredibilitet_Click(object sender, EventArgs e)
    {
        Kredibilitet k = new Kredibilitet();

        k.KogaZaposljavate = txtOdgovorKogaZaposljavate.Text;
        k.KomePoveravatePosao = txtOdgovorKomePoveravatePosao.Text;
        k.OsobeBezKredibiliteta = txtOdgovorOsobeBezKredibiliteta.Text;
        k.OsobeKojePrihvatajuGreske = txtOdgovorOsobeKojePrihvatajuGreske.Text;
        k.PopravkaKredibiliteta = txtOdgovorPopravkaKredibiliteta.Text;
        k.PovracajPoverenja = txtOdgovorPovracajPoverenja.Text;
        k.ProveraPoverenja = txtOdgovorProveraPoverenja.Text;
        k.StaJeKredibilitet = txtOdgovorStaJeKredibilitet.Text;
        k.StaZaVasZnaciKredibilitet = txtOdgovorStaZaVasZnaciKredibilitet.Text;
        k.VaznostPoverenja = txtOdgovorVaznostPoverenja.Text;
        k.VaznostSamosvesnosti = txtOdgovorVaznostSamosvesnosti.Text;
        k.VaznostTacnosti = txtOdgovorVaznostTacnosti.Text;

        k.SnimiPodatke_TabelaKredibilitet(
            k.StaJeKredibilitet,
            k.StaZaVasZnaciKredibilitet,
            k.VaznostTacnosti,
            k.VaznostPoverenja,
            k.ProveraPoverenja,
            k.PovracajPoverenja,
            k.PopravkaKredibiliteta,
            k.OsobeBezKredibiliteta,
            k.KogaZaposljavate,
            k.KomePoveravatePosao,
            k.VaznostSamosvesnosti,
            k.OsobeKojePrihvatajuGreske);
    }
}

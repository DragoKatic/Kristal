﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;
using System.Data.OleDb;
using System.Web.Configuration;

public partial class Poslodavci_Ponuda : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            UcitajPodatke_ImenaNezaposlenih();
        }
    }

    private string connectionStringKristal =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;

    protected void UcitajPodatke_ImenaNezaposlenih()
    {
        ddlImenaNezaposlenih.Items.Clear();

        string greska = "";
        string selectTabelaOsnovniPodaci =
            "SELECT `korisnik_id`, `ime`, `prezime` FROM `TabelaOsnovniPodaci`";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(selectTabelaOsnovniPodaci, con);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                ListItem newItem = new ListItem();
                newItem.Text = reader["ime"] + "  " + reader["prezime"];
                newItem.Value = reader["korisnik_id"].ToString();
                ddlImenaNezaposlenih.Items.Add(newItem);
            }

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void ddlImenaNezaposlenih_SelectedIndexChanged(Object sender, EventArgs e)
    {
        lblKorisnikID.Text = ddlImenaNezaposlenih.SelectedItem.Value.ToString();
        UcitajPodatke_TabelaOsnovniPodaci();
    }
    
    protected void UcitajPodatke_TabelaOsnovniPodaci()
    {
            string greska = "";
            string selectTabelaOsnovniPodaci =
            "SELECT * FROM [TabelaOsnovniPodaci] WHERE ([korisnik_id] = '" + ddlImenaNezaposlenih.SelectedItem.Value + "')";
            
            lblAdresa.Text = "";
            lblBracnoStanje.Text = "";
            lblDatumRodjenja.Text = "";
            lblDrzava.Text = "";
            lblDrzavljanstvo.Text = "";
            lblEmail.Text = "";
            lblGrad.Text = "";
            lblIme.Text = "";
            lblKucniTelefon.Text = "";
            lblMobilniTelefon.Text = "";
            lblOpstina.Text = "";
            lblPol.Text = "";
            lblPosBroj.Text = "";
            lblPrezime.Text = "";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(selectTabelaOsnovniPodaci, con);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            lblIme.Text += reader["ime"];
            lblIme.Text += " ";
            lblPrezime.Text += reader["prezime"];
            lblPrezime.Text += "<br /><br />";
            lblDatumRodjenja.Text += "Rođ: ";
            lblDatumRodjenja.Text += reader["datum_rodjenja"];
            lblDatumRodjenja.Text += "<br />";
            lblPol.Text += "Pol :";
            lblPol.Text += reader["pol"];
            lblPol.Text += "<br /><br />";
            lblDrzavljanstvo.Text += "Državljanstvo:  ";
            lblDrzavljanstvo.Text += reader["drzavljanstvo"];
            lblDrzavljanstvo.Text += "<br />";
            lblBracnoStanje.Text += "Bračno stanje:  ";
            lblBracnoStanje.Text += reader["bracno_stanje"];
            lblBracnoStanje.Text += "<br /><br />";
            lblAdresa.Text += "Adresa: <br />";
            lblAdresa.Text += reader["adresa"];
            lblAdresa.Text += "<br />";
            lblPosBroj.Text += reader["postanski_broj"];
            lblPosBroj.Text += "  ";
            lblOpstina.Text += reader["opstina"];
            lblOpstina.Text += "<br />";
            lblGrad.Text += reader["grad"];
            lblGrad.Text += "  ";
            lblDrzava.Text += reader["drzava"];
            lblDrzava.Text += "<br /><br />";
            lblEmail.Text += "E - mail: ";
            lblEmail.Text += reader["web_site"];
            lblEmail.Text += "<br />";
            lblKucniTelefon.Text += "Kućni telefon:  ";
            lblKucniTelefon.Text += reader["kucni_telefon"];
            lblKucniTelefon.Text += "<br />";
            lblMobilniTelefon.Text += "Mobilni telefon:  ";
            lblMobilniTelefon.Text += reader["mobilni_telefon"];
            lblMobilniTelefon.Text += "<br /><br />";

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void UcitajPodatke_TabelaOsnovnoObrazovanje()
    {
        string greska = "";
        string selectTabelaOsnovnoObrazovanje =
        "SELECT * FROM [TabelaOsnovnoObrazovanje] WHERE ([korisnik_id] = '" + ddlImenaNezaposlenih.SelectedItem.Value + "')";
        
        lblVozackaDozvola.Text = "";
        lblEngledkiNivo.Text = "";
        lblFrancuskiNivo.Text = "";
        lblNemackiNivo.Text = "";
        lblItalijanskiNivo.Text = "";
        lblRuskiNivo.Text = "";
        lblDrugiJezik.Text = "";
        lblDrugiJezikNivo.Text = "";
        lblStepenObrazovanja.Text = "";
        lblGodinaZavrsetka.Text = "";
        lblNazivSkole.Text = "";
        lblSmerStudija.Text = "";
        lblOblastMagistrature.Text = "";
        lblOblastDoktorata.Text = "";
        lblDrugaObrazovanja.Text = "";
        lblSpecijalistickaZnanja.Text = "";
        lblPromeneUPoslu.Text = "";
        lblKnjigeOPoslu.Text = "";
        lblStandardiUPoslu.Text = "";


        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(selectTabelaOsnovnoObrazovanje, con);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            lblVozackaDozvola.Text += "Vozačka dozvola: ";
            lblVozackaDozvola.Text += reader["vozacka_dozvola"];
            lblVozackaDozvola.Text += "<br />";
            lblEngledkiNivo.Text += "Znanje stranih jezika: <br />";
            lblEngledkiNivo.Text += "Engleski jezik: ";
            lblEngledkiNivo.Text += reader["engleski_jezik_nivo"];
            lblFrancuskiNivo.Text += "Francuski jezik: ";
            lblFrancuskiNivo.Text += reader["francuski_jezik_nivo"];
            lblNemackiNivo.Text += "Nemački jezik: ";
            lblNemackiNivo.Text += reader["nemacki_jezik_nivo"];
            lblItalijanskiNivo.Text += "Italijanski jezik: ";
            lblItalijanskiNivo.Text += reader["italijanski_jezik_nivo"];
            lblRuskiNivo.Text += "Ruski jezik: ";
            lblRuskiNivo.Text += reader["ruski_jezik_nivo"];
            lblDrugiJezik.Text += reader["drugi_jezik"];
            lblDrugiJezik.Text += " jezik: ";
            lblDrugiJezikNivo.Text += reader["drugi_jezik_nivo"];
            lblDrugiJezikNivo.Text += "<br />";
            lblStepenObrazovanja.Text += "Stepen Obrazovanja: ";
            lblStepenObrazovanja.Text += reader["stepen_skolovanja"];
            lblGodinaZavrsetka.Text += "Od ";
            lblGodinaZavrsetka.Text += reader["godina_zavrsetka_skole"];
            lblGodinaZavrsetka.Text += " godine.";
            lblNazivSkole.Text += "Naziv škole: <br />";
            lblNazivSkole.Text += reader["naziv_skole"];
            lblSmerStudija.Text += "Smer studija: <br />";
            lblSmerStudija.Text += reader["smer_studija"];
            lblOblastMagistrature.Text += "Oblast magistrature:<br />";
            lblOblastMagistrature.Text += reader["oblast_magistrature"];
            lblOblastDoktorata.Text += "Oblast doktorata: <br />";
            lblOblastDoktorata.Text += reader["oblast_doktorata"];
            lblDrugaObrazovanja.Text += "Druga obrazovanja: <br />";
            lblDrugaObrazovanja.Text += reader["druga_obrazovanja"];
            lblSpecijalistickaZnanja.Text += "Specijalistička znanja: <br />";
            lblSpecijalistickaZnanja.Text += reader["specijalisticka_znanja"];
            lblPromeneUPoslu.Text += "Praćenje promena u poslu: <br />";
            lblPromeneUPoslu.Text += reader["promene_u_poslu"];
            lblKnjigeOPoslu.Text += "Literatura u vezi sa poslom: <br />";
            lblKnjigeOPoslu.Text += reader["knjige_o_poslu"];
            lblKnjigeOPoslu.Text += "Standardi u vez sa poslom:  <br />";
            lblStandardiUPoslu.Text += reader["standardi_u_poslu"];

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }
}

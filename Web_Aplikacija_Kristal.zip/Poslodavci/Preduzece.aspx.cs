﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;

public partial class Poslodavci_Preduzece : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void cmdSnimiPodatkePreduzeca_Click(object sender, EventArgs e)
    {
        Preduzeca p = new Preduzeca();

        p.Adresa = txtAdresaUlica.Text + "/" + txtAdresaBroj.Text;
        p.EMail = txtE_mail.Text;
        p.FiksniTelefon = "+" +
            txtIzlazFiksniTelefon.Text + " (" +
            txtPozivniFiksniTelefon.Text + ") " +
            txtPrviDeoFiksniTelefon.Text + "/" +
            txtDrugiDeoFiksniTelefon.Text;
        p.KontaktOsoba = txtKontaktOsoba.Text;
        p.Mesto = txtMesto.Text;
        p.MobilniTelefon = "+" +
            txtIzlazMobilniTel.Text + " (" +
            txtPozivniMobilniTel.Text + ") " +
            txtPrviDeoMobilniTel.Text + "/" +
            txtDrugiDeoMobilniTel.Text;
        p.Naziv = txtNaziv.Text;
        p.Pib = txtPib.Text;
        p.PostanskiBroj = txtPosBr.Text;
        p.Region = txtRegion.Text;
        p.WebSite = txtWeb_Site.Text;

        p.SnimiPodatke_TabelaPreduzeca(
            p.Naziv,
            p.Pib,
            p.KontaktOsoba,
            p.FiksniTelefon,
            p.MobilniTelefon,
            p.Adresa,
            p.PostanskiBroj,
            p.Mesto,
            p.Region,
            p.EMail,
            p.WebSite);
    }
}

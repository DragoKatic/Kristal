﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;

public partial class Poslodavci_Oglasavanje : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            UcitajPodatke_StepenZavrsenogSkolovanja();
        }
    }

    protected void UcitajPodatke_StepenZavrsenogSkolovanja()
    {
        ddlMinStepenObrazovanja.Items.Add("Izaberite");
        ddlMinStepenObrazovanja.Items.Add("Osnovna škola");
        ddlMinStepenObrazovanja.Items.Add("Srednja škola");
        ddlMinStepenObrazovanja.Items.Add("Viša škola");
        ddlMinStepenObrazovanja.Items.Add("Bachelor (BA)");
        ddlMinStepenObrazovanja.Items.Add("Master/Spec. (MA/MS)");
        ddlMinStepenObrazovanja.Items.Add("Doktorske studije (PhD)");

        ddlMaxStepenObrazovanja.Items.Add("Izaberite");
        ddlMaxStepenObrazovanja.Items.Add("Osnovna škola");
        ddlMaxStepenObrazovanja.Items.Add("Srednja škola");
        ddlMaxStepenObrazovanja.Items.Add("Viša škola");
        ddlMaxStepenObrazovanja.Items.Add("Bachelor (BA)");
        ddlMaxStepenObrazovanja.Items.Add("Master/Spec. (MA/MS)");
        ddlMaxStepenObrazovanja.Items.Add("Doktorske studije (PhD)");
    }


    protected void cmdSnimiPodatkePoslovniOglas_Click(object sender, EventArgs e)
    {
        PoslovniOglasi p = new PoslovniOglasi();
        p.EMail = txtEMailPreduzeca.Text;
        p.Kategorija = txtKategorijaRadnogMesta.Text;
        p.MaxStepenObrazovanja = ddlMaxStepenObrazovanja.SelectedValue.ToString();
        p.MinStepenObrazovanja = ddlMinStepenObrazovanja.SelectedValue.ToString();
        p.Mesto = txtNazivMesta.Text;
        p.Naziv = txtNazivRadnogMesta.Text;
        p.Obavestenje = rblNacinInformisanja.SelectedValue.ToString();
        p.Oglas = txtOglas.Text;
        p.Opstina = txtNazivOpstine.Text;
        p.RadnoMesto = txtNazivRadnogMesta.Text;
        p.WebSite = txtWebAdresaPreduzeca.Text;

        p.SnimiPodatke_TabelaPoslovniOglas(
            p.Naziv,
            p.RadnoMesto,
            p.Mesto,
            p.Opstina,
            p.Kategorija,
            p.MinStepenObrazovanja,
            p.MaxStepenObrazovanja,
            p.Oglas,
            p.Obavestenje,
            p.EMail,
            p.WebSite);
    }
}

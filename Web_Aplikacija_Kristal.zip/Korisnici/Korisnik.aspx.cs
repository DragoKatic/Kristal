﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using KristalBiblioteka;
using System.Data.OleDb;
using System.Web.Configuration;

public partial class Korisnici_Korisnik : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            UcitajPodatkeOKorisniku();
        }
    }

    private string connectionStringKristal =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;

    protected void UcitajPodatkeOKorisniku()
    {
        string greska = "";
        string select = "";
        KorisnickiPodaci br = new KorisnickiPodaci();
        string korisnik_id = br.ObezbediKorisnickiKljuc();
        lblKorisnikID.Text = korisnik_id;
        select += "SELECT * FROM `TabelaOsnovniPodaci` WHERE `korisnik_id` = ?";
        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;
        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            lblIme.Text = reader["ime"].ToString();
            lblPrezime.Text = reader["prezime"].ToString();
            lblDatumRodjenja.Text = reader["datum_rodjenja"].ToString();
            lblAdresa.Text = reader["adresa"].ToString();
            lblPosBroj.Text = reader["postanski_broj"].ToString();
            lblGrad.Text = reader["grad"].ToString();
            lblOpstina.Text = reader["opstina"].ToString();
            lblDrzava.Text = reader["drzava"].ToString();

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
 
    }
}
﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;
using System.Net.Mail;

public partial class Korisnici_Kontakt : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtSubject.Text = "Tema";
            txtBody.Text = "Ovo je sadržaj poruke.";
        }
    }

    protected void btnPotvrdi_Click(object sender, EventArgs e)
    {
        string 
            sFrom, 
            sSubject, 
            sBody,
            greska;

        KorisnickiPodaci kp = new KorisnickiPodaci();
        sFrom = kp.ObezbediKorisnickiEmail();
        sSubject = txtSubject.Text.Trim();
        sBody = txtBody.Text.Trim();

        MailMessage message = new MailMessage();
        message.From = new MailAddress(sFrom);
        message.To.Add(new MailAddress("dragokatic@hotmail.com"));
        message.To.Add(new MailAddress("dragokatic@yahoo.com"));
        message.To.Add(new MailAddress("drgktc@gmail.com"));
        message.Subject = sSubject;
        message.Body = sBody;

        SmtpClient client = new SmtpClient();

        try
        {

            client.Send(message);
            lblPoruka.Text = "<h3>Poruka je uspešno poslata.</h3>";
        }
        catch (SmtpException err)
        {
            greska = err.Message;
        }



    }
    protected void btnPoništi_Click(object sender, EventArgs e)
    {
        txtSubject.Text = "";
        txtBody.Text = "";
    }
}

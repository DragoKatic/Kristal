﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;
using System.Data.OleDb;
using System.Web.Configuration;

public partial class Radnici_PlaniranjeVremena : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            UcitajPodatke_ProcentiISati();
            UcitajPodatke_Sati();
        }
    }

    private string connectionStringKristal =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;

    protected void UcitajPlaniranjeVremena()
    {
        string greska = "";
        string select = "";

        int cetUkupnoProcenata = 0;
        int nedUkupnoProcenata = 0;
        int petUkupnoProcenata = 0;
        int ponUkupnoProcenata = 0;
        int sreUkupnoProcenata = 0;
        int subUkupnoProcenata = 0;
        int utoUkupnoProcenata = 0;

        int ukupnoSati = 0;

        int ukupnoSatiPonedeljak = 0;
        int ukupnoSatiUtorak = 0;
        int ukupnoSatiSreda = 0;
        int ukupnoSatiCetvrtak = 0;
        int ukupnoSatiPetak = 0;
        int ukupnoSatiSubota = 0;
        int ukupnoSatiNedelja = 0;

        txtAkt1Opis.Text = "";
        txtAkt2Opis.Text = "";
        txtAkt3Opis.Text = "";
        txtAkt4Opis.Text = "";
        txtAkt5Opis.Text = "";
        txtAkt6Opis.Text = "";

        lblAkt1UkupnoSat.Text = "";
        lblAkt2UkupnoSat.Text = "";
        lblAkt3UkupnoSat.Text = "";
        lblAkt4UkupnoSat.Text = "";
        lblAkt5UkupnoSat.Text = "";
        lblAkt6UkupnoSat.Text = "";

        lblUkupnoProcCet.Text = "";
        lblUkupnoProcNed.Text = "";
        lblUkupnoProcPet.Text = "";
        lblUkupnoProcPon.Text = "";
        lblUkupnoProcSre.Text = "";
        lblUkupnoProcSub.Text = "";
        lblUkupnoProcUto.Text = "";

        ddlAkt1SatCet.Items.Clear();
        ddlAkt1SatNed.Items.Clear();
        ddlAkt1SatPet.Items.Clear();
        ddlAkt1SatPon.Items.Clear();
        ddlAkt1SatSre.Items.Clear();
        ddlAkt1SatSub.Items.Clear();
        ddlAkt1SatUto.Items.Clear();
        ddlAkt2SatCet.Items.Clear();
        ddlAkt2SatNed.Items.Clear();
        ddlAkt2SatPet.Items.Clear();
        ddlAkt2SatPon.Items.Clear();
        ddlAkt2SatSre.Items.Clear();
        ddlAkt2SatSub.Items.Clear();
        ddlAkt2SatUto.Items.Clear();
        ddlAkt3SatCet.Items.Clear();
        ddlAkt3SatNed.Items.Clear();
        ddlAkt3SatPet.Items.Clear();
        ddlAkt3SatPon.Items.Clear();
        ddlAkt3SatSre.Items.Clear();
        ddlAkt3SatSub.Items.Clear();
        ddlAkt3SatUto.Items.Clear();
        ddlAkt4SatCet.Items.Clear();
        ddlAkt4SatNed.Items.Clear();
        ddlAkt4SatPet.Items.Clear();
        ddlAkt4SatPon.Items.Clear();
        ddlAkt4SatSre.Items.Clear();
        ddlAkt4SatSub.Items.Clear();
        ddlAkt4SatUto.Items.Clear();
        ddlAkt5SatCet.Items.Clear();
        ddlAkt5SatNed.Items.Clear();
        ddlAkt5SatPet.Items.Clear();
        ddlAkt5SatPon.Items.Clear();
        ddlAkt5SatSre.Items.Clear();
        ddlAkt5SatSub.Items.Clear();
        ddlAkt5SatUto.Items.Clear();
        ddlAkt6SatCet.Items.Clear();
        ddlAkt6SatNed.Items.Clear();
        ddlAkt6SatPet.Items.Clear();
        ddlAkt6SatPon.Items.Clear();
        ddlAkt6SatSre.Items.Clear();
        ddlAkt6SatSub.Items.Clear();
        ddlAkt6SatUto.Items.Clear();



        KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
        string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

        select += "SELECT * FROM `TabelaUpravljanjeVremenom` WHERE `korisnik_id` = ?";
        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();
            
            Label lblAkt1UkupnoProcenata = new Label();
            lblAkt1UkupnoProcenata.Text = reader["akt1_ukupno_proc"].ToString();
            Label lblAkt2UkupnoProcenata = new Label();
            lblAkt2UkupnoProcenata.Text = reader["akt2_ukupno_proc"].ToString();
            Label lblAkt3UkupnoProcenata = new Label();
            lblAkt3UkupnoProcenata.Text = reader["akt3_ukupno_proc"].ToString();
            Label lblAkt4UkupnoProcenata = new Label();
            lblAkt4UkupnoProcenata.Text = reader["akt4_ukupno_proc"].ToString();
            Label lblAkt5UkupnoProcenata = new Label();
            lblAkt5UkupnoProcenata.Text = reader["akt5_ukupno_proc"].ToString();
            Label lblAkt6UkupnoProcenata = new Label();
            lblAkt6UkupnoProcenata.Text = reader["akt6_ukupno_proc"].ToString();
            
            txtAkt1Opis.Text = reader["akt1_opis"].ToString();
            txtAkt2Opis.Text = reader["akt2_opis"].ToString();
            txtAkt3Opis.Text = reader["akt3_opis"].ToString();
            txtAkt4Opis.Text = reader["akt4_opis"].ToString();
            txtAkt5Opis.Text = reader["akt5_opis"].ToString();
            txtAkt6Opis.Text = reader["akt6_opis"].ToString();
            
            lblAkt1UkupnoSat.Text = reader["akt1_ukupno_sat"].ToString();
            lblAkt2UkupnoSat.Text = reader["akt2_ukupno_sat"].ToString();
            lblAkt3UkupnoSat.Text = reader["akt3_ukupno_sat"].ToString();
            lblAkt4UkupnoSat.Text = reader["akt4_ukupno_sat"].ToString();
            lblAkt5UkupnoSat.Text = reader["akt5_ukupno_sat"].ToString();
            lblAkt6UkupnoSat.Text = reader["akt6_ukupno_sat"].ToString();

            ddlAkt1SatCet.Items.Add(reader["akt1_sat_cet"].ToString());
            ddlAkt1SatNed.Items.Add(reader["akt1_sat_ned"].ToString());
            ddlAkt1SatPet.Items.Add(reader["akt1_sat_pet"].ToString());
            ddlAkt1SatPon.Items.Add(reader["akt1_sat_pon"].ToString());
            ddlAkt1SatSre.Items.Add(reader["akt1_sat_sre"].ToString());
            ddlAkt1SatSub.Items.Add(reader["akt1_sat_sub"].ToString());
            ddlAkt1SatUto.Items.Add(reader["akt1_sat_uto"].ToString());

            ddlAkt2SatCet.Items.Add(reader["akt2_sat_cet"].ToString());
            ddlAkt2SatNed.Items.Add(reader["akt2_sat_ned"].ToString());
            ddlAkt2SatPet.Items.Add(reader["akt2_sat_pet"].ToString());
            ddlAkt2SatPon.Items.Add(reader["akt2_sat_pon"].ToString());
            ddlAkt2SatSre.Items.Add(reader["akt2_sat_sre"].ToString());
            ddlAkt2SatSub.Items.Add(reader["akt2_sat_sub"].ToString());
            ddlAkt2SatUto.Items.Add(reader["akt2_sat_uto"].ToString());

            ddlAkt3SatCet.Items.Add(reader["akt3_sat_cet"].ToString());
            ddlAkt3SatNed.Items.Add(reader["akt3_sat_ned"].ToString());
            ddlAkt3SatPet.Items.Add(reader["akt3_sat_pet"].ToString());
            ddlAkt3SatPon.Items.Add(reader["akt3_sat_pon"].ToString());
            ddlAkt3SatSre.Items.Add(reader["akt3_sat_sre"].ToString());
            ddlAkt3SatSub.Items.Add(reader["akt3_sat_sub"].ToString());
            ddlAkt3SatUto.Items.Add(reader["akt3_sat_uto"].ToString());

            ddlAkt4SatCet.Items.Add(reader["akt4_sat_cet"].ToString());
            ddlAkt4SatNed.Items.Add(reader["akt4_sat_ned"].ToString());
            ddlAkt4SatPet.Items.Add(reader["akt4_sat_pet"].ToString());
            ddlAkt4SatPon.Items.Add(reader["akt4_sat_pon"].ToString());
            ddlAkt4SatSre.Items.Add(reader["akt4_sat_sre"].ToString());
            ddlAkt4SatSub.Items.Add(reader["akt4_sat_sub"].ToString());
            ddlAkt4SatUto.Items.Add(reader["akt4_sat_uto"].ToString());

            ddlAkt5SatCet.Items.Add(reader["akt5_sat_cet"].ToString());
            ddlAkt5SatNed.Items.Add(reader["akt5_sat_ned"].ToString());
            ddlAkt5SatPet.Items.Add(reader["akt5_sat_pet"].ToString());
            ddlAkt5SatPon.Items.Add(reader["akt5_sat_pon"].ToString());
            ddlAkt5SatSre.Items.Add(reader["akt5_sat_sre"].ToString());
            ddlAkt5SatSub.Items.Add(reader["akt5_sat_sub"].ToString());
            ddlAkt5SatUto.Items.Add(reader["akt5_sat_uto"].ToString());

            ddlAkt6SatCet.Items.Add(reader["akt6_sat_cet"].ToString());
            ddlAkt6SatNed.Items.Add(reader["akt6_sat_ned"].ToString());
            ddlAkt6SatPet.Items.Add(reader["akt6_sat_pet"].ToString());
            ddlAkt6SatPon.Items.Add(reader["akt6_sat_pon"].ToString());
            ddlAkt6SatSre.Items.Add(reader["akt6_sat_sre"].ToString());
            ddlAkt6SatSub.Items.Add(reader["akt6_sat_sub"].ToString());
            ddlAkt6SatUto.Items.Add(reader["akt6_sat_uto"].ToString());

            lblUkupnoSatiProcenata.Text = "Ukupno " +
                reader["ukupno_u_satima"].ToString() + " sati<br />" +
                reader["ukupno_u_procentima"].ToString() + "%";

            ukupnoSati = Convert.ToInt32(reader["ukupno_u_satima"].ToString());

            ukupnoSatiPonedeljak =
                Convert.ToInt32(ddlAkt1SatPon.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt2SatPon.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt3SatPon.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt4SatPon.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt5SatPon.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt6SatPon.SelectedValue.ToString());
            ponUkupnoProcenata = ((100 * ukupnoSatiPonedeljak) + 1) / (ukupnoSati + 1);

            ukupnoSatiUtorak =
                Convert.ToInt32(ddlAkt1SatUto.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt2SatUto.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt3SatUto.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt4SatUto.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt5SatUto.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt6SatUto.SelectedValue.ToString());
            utoUkupnoProcenata = ((100 * ukupnoSatiUtorak) + 1) / (ukupnoSati + 1);

            ukupnoSatiSreda =
                Convert.ToInt32(ddlAkt1SatSre.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt2SatSre.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt3SatSre.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt4SatSre.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt5SatSre.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt6SatSre.SelectedValue.ToString());
            sreUkupnoProcenata = (100 * ukupnoSatiSreda + 1) / (ukupnoSati + 1);

            ukupnoSatiCetvrtak =
                Convert.ToInt32(ddlAkt1SatCet.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt2SatCet.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt3SatCet.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt4SatCet.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt5SatCet.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt6SatCet.SelectedValue.ToString());
            cetUkupnoProcenata = ((100 * ukupnoSatiCetvrtak) + 1) / (ukupnoSati + 1);

            ukupnoSatiPetak =
                Convert.ToInt32(ddlAkt1SatPet.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt2SatPet.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt3SatPet.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt4SatPet.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt5SatPet.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt6SatPet.SelectedValue.ToString());
            petUkupnoProcenata = ((100 * ukupnoSatiPetak) + 1) / (ukupnoSati + 1);

            ukupnoSatiSubota =
                Convert.ToInt32(ddlAkt1SatSub.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt2SatSub.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt3SatSub.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt4SatSub.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt5SatSub.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt6SatSub.SelectedValue.ToString());
            subUkupnoProcenata = ((100 * ukupnoSatiSubota) + 1) / (ukupnoSati + 1);

            ukupnoSatiNedelja =
                Convert.ToInt32(ddlAkt1SatNed.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt2SatNed.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt3SatNed.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt4SatNed.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt5SatNed.SelectedValue.ToString()) +
                Convert.ToInt32(ddlAkt6SatNed.SelectedValue.ToString());
            nedUkupnoProcenata = ((100 * ukupnoSatiNedelja) + 1) / (ukupnoSati + 1);

            lblUkupnoProcCet.Text = "Ukupno<br />" + Convert.ToString(cetUkupnoProcenata) + "%";
            lblUkupnoProcNed.Text = "Ukupno<br />" + Convert.ToString(nedUkupnoProcenata) + "%";
            lblUkupnoProcPet.Text = "Ukupno<br />" + Convert.ToString(petUkupnoProcenata) + "%";
            lblUkupnoProcPon.Text = "Ukupno<br />" + Convert.ToString(ponUkupnoProcenata) + "%";
            lblUkupnoProcSre.Text = "Ukupno<br />" + Convert.ToString(sreUkupnoProcenata) + "%";
            lblUkupnoProcSub.Text = "Ukupno<br />" + Convert.ToString(subUkupnoProcenata) + "%";
            lblUkupnoProcUto.Text = "Ukupno<br />" + Convert.ToString(utoUkupnoProcenata) + "%";

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void UcitajPodatke_ProcentiISati()
    {
        txtAkt1Opis.Text = "";
        txtAkt2Opis.Text = "";
        txtAkt3Opis.Text = "";
        txtAkt4Opis.Text = "";
        txtAkt5Opis.Text = "";
        txtAkt6Opis.Text = "";

        lblAkt1UkupnoSat.Text = "";
        lblAkt2UkupnoSat.Text = "";
        lblAkt3UkupnoSat.Text = "";
        lblAkt4UkupnoSat.Text = "";
        lblAkt5UkupnoSat.Text = "";
        lblAkt6UkupnoSat.Text = "";

        lblUkupnoProcCet.Text = "";
        lblUkupnoProcNed.Text = "";
        lblUkupnoProcPet.Text = "";
        lblUkupnoProcPon.Text = "";
        lblUkupnoProcSre.Text = "";
        lblUkupnoProcSub.Text = "";
        lblUkupnoProcUto.Text = "";

        lblUkupnoSatiProcenata.Text = "";
    }

    protected void UcitajPodatke_Sati()
    {
        ddlAkt1SatCet.Items.Clear();
        ddlAkt1SatNed.Items.Clear();
        ddlAkt1SatPet.Items.Clear();
        ddlAkt1SatPon.Items.Clear();
        ddlAkt1SatSre.Items.Clear();
        ddlAkt1SatSub.Items.Clear();
        ddlAkt1SatUto.Items.Clear();
        ddlAkt2SatCet.Items.Clear();
        ddlAkt2SatNed.Items.Clear();
        ddlAkt2SatPet.Items.Clear();
        ddlAkt2SatPon.Items.Clear();
        ddlAkt2SatSre.Items.Clear();
        ddlAkt2SatSub.Items.Clear();
        ddlAkt2SatUto.Items.Clear();
        ddlAkt3SatCet.Items.Clear();
        ddlAkt3SatNed.Items.Clear();
        ddlAkt3SatPet.Items.Clear();
        ddlAkt3SatPon.Items.Clear();
        ddlAkt3SatSre.Items.Clear();
        ddlAkt3SatSub.Items.Clear();
        ddlAkt3SatUto.Items.Clear();
        ddlAkt4SatCet.Items.Clear();
        ddlAkt4SatNed.Items.Clear();
        ddlAkt4SatPet.Items.Clear();
        ddlAkt4SatPon.Items.Clear();
        ddlAkt4SatSre.Items.Clear();
        ddlAkt4SatSub.Items.Clear();
        ddlAkt4SatUto.Items.Clear();
        ddlAkt5SatCet.Items.Clear();
        ddlAkt5SatNed.Items.Clear();
        ddlAkt5SatPet.Items.Clear();
        ddlAkt5SatPon.Items.Clear();
        ddlAkt5SatSre.Items.Clear();
        ddlAkt5SatSub.Items.Clear();
        ddlAkt5SatUto.Items.Clear();
        ddlAkt6SatCet.Items.Clear();
        ddlAkt6SatNed.Items.Clear();
        ddlAkt6SatPet.Items.Clear();
        ddlAkt6SatPon.Items.Clear();
        ddlAkt6SatSre.Items.Clear();
        ddlAkt6SatSub.Items.Clear();
        ddlAkt6SatUto.Items.Clear();

        for (int i = 0; i <= 24; i++)
        {
            ddlAkt1SatCet.Items.Add(i.ToString());
            ddlAkt1SatNed.Items.Add(i.ToString());
            ddlAkt1SatPet.Items.Add(i.ToString());
            ddlAkt1SatPon.Items.Add(i.ToString());
            ddlAkt1SatSre.Items.Add(i.ToString());
            ddlAkt1SatSub.Items.Add(i.ToString());
            ddlAkt1SatUto.Items.Add(i.ToString());
            ddlAkt2SatCet.Items.Add(i.ToString());
            ddlAkt2SatNed.Items.Add(i.ToString());
            ddlAkt2SatPet.Items.Add(i.ToString());
            ddlAkt2SatPon.Items.Add(i.ToString());
            ddlAkt2SatSre.Items.Add(i.ToString());
            ddlAkt2SatSub.Items.Add(i.ToString());
            ddlAkt2SatUto.Items.Add(i.ToString());
            ddlAkt3SatCet.Items.Add(i.ToString());
            ddlAkt3SatNed.Items.Add(i.ToString());
            ddlAkt3SatPet.Items.Add(i.ToString());
            ddlAkt3SatPon.Items.Add(i.ToString());
            ddlAkt3SatSre.Items.Add(i.ToString());
            ddlAkt3SatSub.Items.Add(i.ToString());
            ddlAkt3SatUto.Items.Add(i.ToString());
            ddlAkt4SatCet.Items.Add(i.ToString());
            ddlAkt4SatNed.Items.Add(i.ToString());
            ddlAkt4SatPet.Items.Add(i.ToString());
            ddlAkt4SatPon.Items.Add(i.ToString());
            ddlAkt4SatSre.Items.Add(i.ToString());
            ddlAkt4SatSub.Items.Add(i.ToString());
            ddlAkt4SatUto.Items.Add(i.ToString());
            ddlAkt5SatCet.Items.Add(i.ToString());
            ddlAkt5SatNed.Items.Add(i.ToString());
            ddlAkt5SatPet.Items.Add(i.ToString());
            ddlAkt5SatPon.Items.Add(i.ToString());
            ddlAkt5SatSre.Items.Add(i.ToString());
            ddlAkt5SatSub.Items.Add(i.ToString());
            ddlAkt5SatUto.Items.Add(i.ToString());
            ddlAkt6SatCet.Items.Add(i.ToString());
            ddlAkt6SatNed.Items.Add(i.ToString());
            ddlAkt6SatPet.Items.Add(i.ToString());
            ddlAkt6SatPon.Items.Add(i.ToString());
            ddlAkt6SatSre.Items.Add(i.ToString());
            ddlAkt6SatSub.Items.Add(i.ToString());
            ddlAkt6SatUto.Items.Add(i.ToString());
        }
    }
    protected void cmdSnimiPodatke_TabelaUpravljanjeVremenom_Click(object sender, EventArgs e)
    {
        lblAkt1UkupnoSat.Text = "";
        lblAkt2UkupnoSat.Text = "";
        lblAkt3UkupnoSat.Text = "";
        lblAkt4UkupnoSat.Text = "";
        lblAkt5UkupnoSat.Text = "";
        lblAkt6UkupnoSat.Text = "";

        lblUkupnoProcCet.Text = "";
        lblUkupnoProcNed.Text = "";
        lblUkupnoProcPet.Text = "";
        lblUkupnoProcPon.Text = "";
        lblUkupnoProcSre.Text = "";
        lblUkupnoProcSub.Text = "";
        lblUkupnoProcUto.Text = "";

        lblUkupnoSatiProcenata.Text = "";

        int akt1UkupnoSati = 0;
        int akt2UkupnoSati = 0;
        int akt3UkupnoSati = 0;
        int akt4UkupnoSati = 0;
        int akt5UkupnoSati = 0;
        int akt6UkupnoSati = 0;

        int akt1UkupnoProcenata = 0;
        int akt2UkupnoProcenata = 0;
        int akt3UkupnoProcenata = 0;
        int akt4UkupnoProcenata = 0;
        int akt5UkupnoProcenata = 0;
        int akt6UkupnoProcenata = 0;

        int ukupnoSatiPonedeljak = 0;
        int ukupnoSatiUtorak = 0;
        int ukupnoSatiSreda = 0;
        int ukupnoSatiCetvrtak = 0;
        int ukupnoSatiPetak = 0;
        int ukupnoSatiSubota = 0;
        int ukupnoSatiNedelja = 0;

        int cetUkupnoProcenata = 0;
        int nedUkupnoProcenata = 0;
        int petUkupnoProcenata = 0;
        int ponUkupnoProcenata = 0;
        int sreUkupnoProcenata = 0;
        int subUkupnoProcenata = 0;
        int utoUkupnoProcenata = 0;

        int ukupnoSati = 0;
        int ukupnoProcenata = 0;

        akt1UkupnoSati = 
            Convert.ToInt32(ddlAkt1SatCet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt1SatNed.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt1SatPet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt1SatPon.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt1SatSre.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt1SatSub.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt1SatUto.SelectedValue.ToString());
        lblAkt1UkupnoSat.Text = "Ukupno</br>" + Convert.ToString(akt1UkupnoSati) + " sati.";

        akt2UkupnoSati =
            Convert.ToInt32(ddlAkt2SatCet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt2SatNed.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt2SatPet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt2SatPon.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt2SatSre.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt2SatSub.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt2SatUto.SelectedValue.ToString());
        lblAkt2UkupnoSat.Text = "Ukupno</br>" + Convert.ToString(akt2UkupnoSati) + " sati.";

        akt3UkupnoSati =
            Convert.ToInt32(ddlAkt3SatCet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt3SatNed.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt3SatPet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt3SatPon.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt3SatSre.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt3SatSub.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt3SatUto.SelectedValue.ToString());
        lblAkt3UkupnoSat.Text = "Ukupno</br>" + Convert.ToString(akt3UkupnoSati) + " sati.";

        akt4UkupnoSati =
            Convert.ToInt32(ddlAkt4SatCet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt4SatNed.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt4SatPet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt4SatPon.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt4SatSre.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt4SatSub.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt4SatUto.SelectedValue.ToString());
        lblAkt4UkupnoSat.Text = "Ukupno</br>" + Convert.ToString(akt4UkupnoSati) + " sati.";

        akt5UkupnoSati =
            Convert.ToInt32(ddlAkt5SatCet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt5SatNed.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt5SatPet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt5SatPon.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt5SatSre.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt5SatSub.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt5SatUto.SelectedValue.ToString());
        lblAkt5UkupnoSat.Text = "Ukupno</br>" + Convert.ToString(akt5UkupnoSati) + " sati.";

        akt6UkupnoSati =
            Convert.ToInt32(ddlAkt6SatCet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt6SatNed.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt6SatPet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt6SatPon.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt6SatSre.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt6SatSub.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt6SatUto.SelectedValue.ToString());
        lblAkt6UkupnoSat.Text = "Ukupno</br>" + Convert.ToString(akt6UkupnoSati) + " sati.";

        ukupnoSati =
            akt1UkupnoSati +
            akt2UkupnoSati +
            akt3UkupnoSati +
            akt4UkupnoSati +
            akt5UkupnoSati +
            akt6UkupnoSati;

        ukupnoSatiPonedeljak = 
            Convert.ToInt32(ddlAkt1SatPon.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt2SatPon.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt3SatPon.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt4SatPon.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt5SatPon.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt6SatPon.SelectedValue.ToString());
        ponUkupnoProcenata = ((100 * ukupnoSatiPonedeljak) + 1) / (ukupnoSati + 1);
        lblUkupnoProcPon.Text = "Ukupno " + Convert.ToString(ponUkupnoProcenata)+ "%";

        ukupnoSatiUtorak =
            Convert.ToInt32(ddlAkt1SatUto.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt2SatUto.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt3SatUto.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt4SatUto.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt5SatUto.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt6SatUto.SelectedValue.ToString());
        utoUkupnoProcenata = ((100 * ukupnoSatiUtorak) + 1) / (ukupnoSati + 1);
        lblUkupnoProcUto.Text = "Ukupno " + Convert.ToString(utoUkupnoProcenata) + "%";

        ukupnoSatiSreda =
            Convert.ToInt32(ddlAkt1SatSre.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt2SatSre.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt3SatSre.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt4SatSre.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt5SatSre.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt6SatSre.SelectedValue.ToString());
        sreUkupnoProcenata = (100 * ukupnoSatiSreda + 1) / (ukupnoSati + 1);
        lblUkupnoProcSre.Text = "Ukupno " + Convert.ToString(sreUkupnoProcenata) + "%";

        ukupnoSatiCetvrtak =
            Convert.ToInt32(ddlAkt1SatCet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt2SatCet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt3SatCet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt4SatCet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt5SatCet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt6SatCet.SelectedValue.ToString());
        cetUkupnoProcenata = ((100 * ukupnoSatiCetvrtak) + 1) / (ukupnoSati + 1);
        lblUkupnoProcCet.Text = "Ukupno " + Convert.ToString(cetUkupnoProcenata) + "%";

        ukupnoSatiPetak =
            Convert.ToInt32(ddlAkt1SatPet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt2SatPet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt3SatPet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt4SatPet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt5SatPet.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt6SatPet.SelectedValue.ToString());
        petUkupnoProcenata = ((100 * ukupnoSatiPetak) + 1) / (ukupnoSati + 1);
        lblUkupnoProcPet.Text = "Ukupno " + Convert.ToString(petUkupnoProcenata) + "%";

        ukupnoSatiSubota =
            Convert.ToInt32(ddlAkt1SatSub.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt2SatSub.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt3SatSub.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt4SatSub.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt5SatSub.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt6SatSub.SelectedValue.ToString());
        subUkupnoProcenata = ((100 * ukupnoSatiSubota) + 1) / (ukupnoSati + 1);
        lblUkupnoProcSub.Text = "Ukupno " + Convert.ToString(subUkupnoProcenata) + "%";

        ukupnoSatiNedelja =
            Convert.ToInt32(ddlAkt1SatNed.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt2SatNed.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt3SatNed.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt4SatNed.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt5SatNed.SelectedValue.ToString()) +
            Convert.ToInt32(ddlAkt6SatNed.SelectedValue.ToString());
        nedUkupnoProcenata = ((100 * ukupnoSatiNedelja) + 1) / (ukupnoSati + 1);
        lblUkupnoProcNed.Text = "Ukupno " + Convert.ToString(nedUkupnoProcenata) + "%";

        ukupnoProcenata =
            ponUkupnoProcenata +
            utoUkupnoProcenata +
            sreUkupnoProcenata +
            cetUkupnoProcenata +
            petUkupnoProcenata +
            subUkupnoProcenata +
            nedUkupnoProcenata;

        lblUkupnoSatiProcenata.Text = 
            "Ukupno " + Convert.ToInt32(ukupnoSati) + 
            " sati</br>/</br>" + Convert.ToInt32(ukupnoProcenata) + "%";


        akt1UkupnoProcenata = ((100 * akt1UkupnoSati) + 1) / (ukupnoSati + 1);
        akt2UkupnoProcenata = ((100 * akt2UkupnoSati) + 1) / (ukupnoSati + 1);
        akt3UkupnoProcenata = ((100 * akt3UkupnoSati) + 1) / (ukupnoSati + 1);
        akt4UkupnoProcenata = ((100 * akt4UkupnoSati) + 1) / (ukupnoSati + 1);
        akt5UkupnoProcenata = ((100 * akt5UkupnoSati) + 1) / (ukupnoSati + 1);
        akt6UkupnoProcenata = ((100 * akt5UkupnoSati) + 1) / (ukupnoSati + 1);

        UpravljanjeVremenom u = new UpravljanjeVremenom();

        u.Akt1Opis = txtAkt1Opis.Text;
        u.Akt1SatCet = ddlAkt1SatCet.SelectedValue.ToString();
        u.Akt1SatNed = ddlAkt1SatNed.SelectedValue.ToString();
        u.Akt1SatPet = ddlAkt1SatPet.SelectedValue.ToString();
        u.Akt1SatPon = ddlAkt1SatPon.SelectedValue.ToString();
        u.Akt1SatSre = ddlAkt1SatSre.SelectedValue.ToString();
        u.Akt1SatSub = ddlAkt1SatSub.SelectedValue.ToString();
        u.Akt1SatUto = ddlAkt1SatUto.SelectedValue.ToString();
        u.Akt1UkupnoProc = Convert.ToString(akt1UkupnoProcenata);
        u.Akt1UkupnoSat = lblAkt1UkupnoSat.Text;

        u.Akt2Opis = txtAkt2Opis.Text;
        u.Akt2SatCet = ddlAkt2SatCet.SelectedValue.ToString();
        u.Akt2SatNed = ddlAkt2SatNed.SelectedValue.ToString();
        u.Akt2SatPet = ddlAkt2SatPet.SelectedValue.ToString();
        u.Akt2SatPon = ddlAkt2SatPon.SelectedValue.ToString();
        u.Akt2SatSre = ddlAkt2SatSre.SelectedValue.ToString();
        u.Akt2SatSub = ddlAkt2SatSub.SelectedValue.ToString();
        u.Akt2SatUto = ddlAkt2SatUto.SelectedValue.ToString();
        u.Akt2UkupnoProc = Convert.ToString(akt2UkupnoProcenata);
        u.Akt2UkupnoSat = lblAkt2UkupnoSat.Text;

        u.Akt3Opis = txtAkt3Opis.Text;
        u.Akt3SatCet = ddlAkt3SatCet.SelectedValue.ToString();
        u.Akt3SatNed = ddlAkt3SatNed.SelectedValue.ToString();
        u.Akt3SatPet = ddlAkt3SatPet.SelectedValue.ToString();
        u.Akt3SatPon = ddlAkt3SatPon.SelectedValue.ToString();
        u.Akt3SatSre = ddlAkt3SatSre.SelectedValue.ToString();
        u.Akt3SatSub = ddlAkt3SatSub.SelectedValue.ToString();
        u.Akt3SatUto = ddlAkt3SatUto.SelectedValue.ToString();
        u.Akt3UkupnoProc = Convert.ToString(akt3UkupnoProcenata);
        u.Akt3UkupnoSat = lblAkt3UkupnoSat.Text;

        u.Akt4Opis = txtAkt4Opis.Text;
        u.Akt4SatCet = ddlAkt4SatCet.SelectedValue.ToString();
        u.Akt4SatNed = ddlAkt4SatNed.SelectedValue.ToString();
        u.Akt4SatPet = ddlAkt4SatPet.SelectedValue.ToString();
        u.Akt4SatPon = ddlAkt4SatPon.SelectedValue.ToString();
        u.Akt4SatSre = ddlAkt4SatSre.SelectedValue.ToString();
        u.Akt4SatSub = ddlAkt4SatSub.SelectedValue.ToString();
        u.Akt4SatUto = ddlAkt4SatUto.SelectedValue.ToString();
        u.Akt4UkupnoProc = Convert.ToString(akt4UkupnoProcenata);
        u.Akt4UkupnoSat = lblAkt4UkupnoSat.Text;

        u.Akt5Opis = txtAkt5Opis.Text;
        u.Akt5SatCet = ddlAkt5SatCet.SelectedValue.ToString();
        u.Akt5SatNed = ddlAkt5SatNed.SelectedValue.ToString();
        u.Akt5SatPet = ddlAkt5SatPet.SelectedValue.ToString();
        u.Akt5SatPon = ddlAkt5SatPon.SelectedValue.ToString();
        u.Akt5SatSre = ddlAkt5SatSre.SelectedValue.ToString();
        u.Akt5SatSub = ddlAkt5SatSub.SelectedValue.ToString();
        u.Akt5SatUto = ddlAkt5SatUto.SelectedValue.ToString();
        u.Akt5UkupnoProc = Convert.ToString(akt5UkupnoProcenata);
        u.Akt5UkupnoSat = lblAkt5UkupnoSat.Text;

        u.Akt6Opis = txtAkt6Opis.Text;
        u.Akt6SatCet = ddlAkt6SatCet.SelectedValue.ToString();
        u.Akt6SatNed = ddlAkt6SatNed.SelectedValue.ToString();
        u.Akt6SatPet = ddlAkt6SatPet.SelectedValue.ToString();
        u.Akt6SatPon = ddlAkt6SatPon.SelectedValue.ToString();
        u.Akt6SatSre = ddlAkt6SatSre.SelectedValue.ToString();
        u.Akt6SatSub = ddlAkt6SatSub.SelectedValue.ToString();
        u.Akt6SatUto = ddlAkt6SatUto.SelectedValue.ToString();
        u.Akt6UkupnoProc = Convert.ToString(akt6UkupnoProcenata);
        u.Akt6UkupnoSat = lblAkt6UkupnoSat.Text;

        u.UkupnoUProcentima = Convert.ToString(ukupnoProcenata);
        u.UkupnoUSatima = Convert.ToString(ukupnoSati);

        u.SnimiPodatke_TabelaTabelaUpravljanjeVremenom(
            u.Akt1Opis,
            u.Akt1SatPon,
            u.Akt1SatUto,
            u.Akt1SatSre,
            u.Akt1SatCet,
            u.Akt1SatPet,
            u.Akt1SatSub,
            u.Akt1SatNed,
            u.Akt1UkupnoSat,
            u.Akt1UkupnoProc,
            u.Akt2Opis,
            u.Akt2SatPon,
            u.Akt2SatUto,
            u.Akt2SatSre,
            u.Akt2SatCet,
            u.Akt2SatPet,
            u.Akt2SatSub,
            u.Akt2SatNed,
            u.Akt2UkupnoSat,
            u.Akt2UkupnoProc,
            u.Akt3Opis,
            u.Akt3SatPon,
            u.Akt3SatUto,
            u.Akt3SatSre,
            u.Akt3SatCet,
            u.Akt3SatPet,
            u.Akt3SatSub,
            u.Akt3SatNed,
            u.Akt3UkupnoSat,
            u.Akt3UkupnoProc,
            u.Akt4Opis,
            u.Akt4SatPon,
            u.Akt4SatUto,
            u.Akt4SatSre,
            u.Akt4SatCet,
            u.Akt4SatPet,
            u.Akt4SatSub,
            u.Akt4SatNed,
            u.Akt4UkupnoSat,
            u.Akt4UkupnoProc,
            u.Akt5Opis,
            u.Akt5SatPon,
            u.Akt5SatUto,
            u.Akt5SatSre,
            u.Akt5SatCet,
            u.Akt5SatPet,
            u.Akt5SatSub,
            u.Akt5SatNed,
            u.Akt5UkupnoSat,
            u.Akt5UkupnoProc,
            u.Akt6Opis,
            u.Akt6SatPon,
            u.Akt6SatUto,
            u.Akt6SatSre,
            u.Akt6SatCet,
            u.Akt6SatPet,
            u.Akt6SatSub,
            u.Akt6SatNed,
            u.Akt6UkupnoSat,
            u.Akt6UkupnoProc,
            u.UkupnoUSatima,
            u.UkupnoUProcentima);
    }
    protected void cmdUcitajPodatke_TabelaUpravljanjeVremenom_Click(object sender, EventArgs e)
    {
        UcitajPlaniranjeVremena();
    }
    protected void cmdOsveziPodatke_TabelaUpravljanjeVremenom_Click(object sender, EventArgs e)
    {
        UcitajPodatke_ProcentiISati();
        UcitajPodatke_Sati();
    }
}

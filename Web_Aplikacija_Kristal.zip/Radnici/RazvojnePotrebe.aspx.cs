﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;
using System.Data.OleDb;
using System.Web.Configuration;

public partial class Radnici_RazvojnePotrebe : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            UcitajSlabosti();
        }
    }

    private string connectionStringKristal =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;

    protected void UcitajRazvojnePotrebe()
    {
        string greska = "";
        string select = "";

        txtSlabost1.Text = "";
        txtSlabost2.Text = "";
        txtSlabost3.Text = "";
        txtSlabost4.Text = "";
        txtSlabost5.Text = "";
        txtSlabost6.Text = "";

        txtCilj1.Text = "";
        txtCilj2.Text = "";
        txtCilj3.Text = "";
        txtCilj4.Text = "";
        txtCilj5.Text = "";
        txtCilj6.Text = "";

        txtAktivnost1.Text = "";
        txtAktivnost2.Text = "";
        txtAktivnost3.Text = "";
        txtAktivnost4.Text = "";
        txtAktivnost5.Text = "";
        txtAktivnost6.Text = "";

        txtResursi1.Text = "";
        txtResursi2.Text = "";
        txtResursi3.Text = "";
        txtResursi4.Text = "";
        txtResursi5.Text = "";
        txtResursi6.Text = "";

        kalendarVremenskiRok1.SelectedDate = DateTime.Now;
        kalendarVremenskiRok2.SelectedDate = DateTime.Now;
        kalendarVremenskiRok3.SelectedDate = DateTime.Now;
        kalendarVremenskiRok4.SelectedDate = DateTime.Now;
        kalendarVremenskiRok5.SelectedDate = DateTime.Now;
        kalendarVremenskiRok6.SelectedDate = DateTime.Now;

        chkBoxOstvareno1.Checked = false;
        chkBoxOstvareno2.Checked = false;
        chkBoxOstvareno3.Checked = false;
        chkBoxOstvareno4.Checked = false;
        chkBoxOstvareno5.Checked = false;
        chkBoxOstvareno6.Checked = false;


        KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
        string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

        select += "SELECT * FROM `TabelaRazvojnePotrebe` WHERE `korisnik_id` = ?";
        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();
            
            txtSlabost1.Text = reader["opis_ponasanja_1"].ToString();
            txtSlabost2.Text = reader["opis_ponasanja_2"].ToString();
            txtSlabost3.Text = reader["opis_ponasanja_3"].ToString();
            txtSlabost4.Text = reader["opis_ponasanja_4"].ToString();
            txtSlabost5.Text = reader["opis_ponasanja_5"].ToString();
            txtSlabost6.Text = reader["opis_ponasanja_6"].ToString();

            txtCilj1.Text = reader["cilj_karijere_1"].ToString();
            txtCilj2.Text = reader["cilj_karijere_2"].ToString();
            txtCilj3.Text = reader["cilj_karijere_3"].ToString();
            txtCilj4.Text = reader["cilj_karijere_4"].ToString();
            txtCilj5.Text = reader["cilj_karijere_5"].ToString();
            txtCilj6.Text = reader["cilj_karijere_6"].ToString();
            
            txtAktivnost1.Text = reader["aktivnosti_1"].ToString();
            txtAktivnost2.Text = reader["aktivnosti_2"].ToString();
            txtAktivnost3.Text = reader["aktivnosti_3"].ToString();
            txtAktivnost4.Text = reader["aktivnosti_4"].ToString();
            txtAktivnost5.Text = reader["aktivnosti_5"].ToString();
            txtAktivnost6.Text = reader["aktivnosti_6"].ToString();
            
            txtResursi1.Text = reader["potrebni_resursi_1"].ToString();
            txtResursi2.Text = reader["potrebni_resursi_2"].ToString();
            txtResursi3.Text = reader["potrebni_resursi_3"].ToString();
            txtResursi4.Text = reader["potrebni_resursi_4"].ToString();
            txtResursi5.Text = reader["potrebni_resursi_5"].ToString();
            txtResursi6.Text = reader["potrebni_resursi_6"].ToString();
            
            kalendarVremenskiRok1.SelectedDate = Convert.ToDateTime(reader["vremenski_rok_1"].ToString());
            kalendarVremenskiRok2.SelectedDate = Convert.ToDateTime(reader["vremenski_rok_2"].ToString());
            kalendarVremenskiRok3.SelectedDate = Convert.ToDateTime(reader["vremenski_rok_3"].ToString());
            kalendarVremenskiRok4.SelectedDate = Convert.ToDateTime(reader["vremenski_rok_4"].ToString());
            kalendarVremenskiRok5.SelectedDate = Convert.ToDateTime(reader["vremenski_rok_5"].ToString());
            kalendarVremenskiRok6.SelectedDate = Convert.ToDateTime(reader["vremenski_rok_6"].ToString());

            chkBoxOstvareno1.Checked = Convert.ToBoolean(reader["ostvareno_1"].ToString());
            chkBoxOstvareno2.Checked = Convert.ToBoolean(reader["ostvareno_2"].ToString());
            chkBoxOstvareno3.Checked = Convert.ToBoolean(reader["ostvareno_3"].ToString());
            chkBoxOstvareno4.Checked = Convert.ToBoolean(reader["ostvareno_4"].ToString());
            chkBoxOstvareno5.Checked = Convert.ToBoolean(reader["ostvareno_5"].ToString());
            chkBoxOstvareno6.Checked = Convert.ToBoolean(reader["ostvareno_6"].ToString());

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }


    protected void UcitajSlabosti()
    {
        string greska = "";
        string select = "";
        txtSlabost1.Text = "";
        txtSlabost2.Text = "";
        txtSlabost3.Text = "";
        txtSlabost4.Text = "";
        txtSlabost5.Text = "";
        txtSlabost6.Text = "";


        KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
        string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

        select += "SELECT * FROM `TabelaRazvojnePotrebe` WHERE `korisnik_id` = ?";
        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            txtSlabost1.Text = reader["opis_ponasanja_1"].ToString();
            txtSlabost2.Text = reader["opis_ponasanja_2"].ToString();
            txtSlabost3.Text = reader["opis_ponasanja_3"].ToString();
            txtSlabost4.Text = reader["opis_ponasanja_4"].ToString();
            txtSlabost5.Text = reader["opis_ponasanja_5"].ToString();
            txtSlabost6.Text = reader["opis_ponasanja_6"].ToString();

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }
    protected void cmdSnimiPodatkeRazvojnePotrebe_Click(object sender, EventArgs e)
    {
        RazvojnePotrebe r = new RazvojnePotrebe();

        r.OpisPonasanja1 = txtSlabost1.Text;
        r.OpisPonasanja2 = txtSlabost2.Text;
        r.OpisPonasanja3 = txtSlabost3.Text;
        r.OpisPonasanja4 = txtSlabost4.Text;
        r.OpisPonasanja5 = txtSlabost5.Text;
        r.OpisPonasanja6 = txtSlabost6.Text;

        r.CiljKarijere1 = txtCilj1.Text;
        r.CiljKarijere2 = txtCilj2.Text;
        r.CiljKarijere3 = txtCilj3.Text;
        r.CiljKarijere4 = txtCilj4.Text;
        r.CiljKarijere5 = txtCilj5.Text;
        r.CiljKarijere6 = txtCilj6.Text;

        r.Aktivnosti1 = txtAktivnost1.Text;
        r.Aktivnosti2 = txtAktivnost2.Text;
        r.Aktivnosti3 = txtAktivnost3.Text;
        r.Aktivnosti4 = txtAktivnost4.Text;
        r.Aktivnosti5 = txtAktivnost5.Text;
        r.Aktivnosti6 = txtAktivnost6.Text;

        r.PotrebniResursi1 = txtResursi1.Text;
        r.PotrebniResursi2 = txtResursi2.Text;
        r.PotrebniResursi3 = txtResursi3.Text;
        r.PotrebniResursi4 = txtResursi4.Text;
        r.PotrebniResursi5 = txtResursi5.Text;
        r.PotrebniResursi6 = txtResursi6.Text;

        r.VremenskiRok1 = Convert.ToString(kalendarVremenskiRok1.SelectedDate);
        r.VremenskiRok2 = Convert.ToString(kalendarVremenskiRok2.SelectedDate);
        r.VremenskiRok3 = Convert.ToString(kalendarVremenskiRok3.SelectedDate);
        r.VremenskiRok4 = Convert.ToString(kalendarVremenskiRok4.SelectedDate);
        r.VremenskiRok5 = Convert.ToString(kalendarVremenskiRok5.SelectedDate);
        r.VremenskiRok6 = Convert.ToString(kalendarVremenskiRok6.SelectedDate);

        r.Ostvareno1 = Convert.ToString(chkBoxOstvareno1.Checked);
        r.Ostvareno2 = Convert.ToString(chkBoxOstvareno2.Checked);
        r.Ostvareno3 = Convert.ToString(chkBoxOstvareno3.Checked);
        r.Ostvareno4 = Convert.ToString(chkBoxOstvareno4.Checked);
        r.Ostvareno5 = Convert.ToString(chkBoxOstvareno5.Checked);
        r.Ostvareno6 = Convert.ToString(chkBoxOstvareno6.Checked);

        r.SnimiPodatke_TabelaRazvojnePotrebe(
            r.OpisPonasanja1,
            r.OpisPonasanja2,
            r.OpisPonasanja3,
            r.OpisPonasanja4,
            r.OpisPonasanja5,
            r.OpisPonasanja6,
            r.CiljKarijere1,
            r.CiljKarijere2,
            r.CiljKarijere3,
            r.CiljKarijere4,
            r.CiljKarijere5,
            r.CiljKarijere6,
            r.Aktivnosti1,
            r.Aktivnosti2,
            r.Aktivnosti3,
            r.Aktivnosti4,
            r.Aktivnosti5,
            r.Aktivnosti6,
            r.PotrebniResursi1,
            r.PotrebniResursi2,
            r.PotrebniResursi3,
            r.PotrebniResursi4,
            r.PotrebniResursi5,
            r.PotrebniResursi6,
            r.VremenskiRok1,
            r.VremenskiRok2,
            r.VremenskiRok3,
            r.VremenskiRok4,
            r.VremenskiRok5,
            r.VremenskiRok6,
            r.Ostvareno1,
            r.Ostvareno2,
            r.Ostvareno3,
            r.Ostvareno4,
            r.Ostvareno5,
            r.Ostvareno6);

        Response.Redirect("~/Radnici/PlaniranjeVremena.aspx");
    }
    protected void cmdUcitajPodatkeRazvojnePotrebe_Click(object sender, EventArgs e)
    {
        UcitajRazvojnePotrebe();
    }
}

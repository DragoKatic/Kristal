﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.IO;
using KristalBiblioteka;
using System.Data.OleDb;
using System.Web.Configuration;

public partial class Radnici_NoviRadnik : System.Web.UI.Page
{
    private string uploadDirectory;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            uploadDirectory = Path.Combine(Request.PhysicalApplicationPath, "Fotografije_Korisnika");
            UcitajOsnovnePodatke();
        }
    }

    private string connectionStringKristal =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;

    protected void UcitajOsnovnePodatke()
    {
        string greska = "";
        string select = "";

        txtIme.Text = "";
        txtPrezime.Text = "";
        rbtnPol.SelectedValue.ToString();
        txtDatumRodjenja.Text = "";
        txtDrzavljanstvo.Text = "";
        rbtnBracnoStanje.SelectedValue.ToString();
        txtAdresa.Text = "";
        txtPostanskiBroj.Text = "";
        txtGrad.Text = "";
        txtOpstina.Text = "";
        txtDrzava.Text = "";
        txtKucniTelefon.Text = "";
        txtMobilniTelefon.Text = "";
        txtEmail.Text = "";


        KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
        string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

        select += "SELECT * FROM `TabelaOsnovniPodaci` WHERE `korisnik_id` = ?";
        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();
            
            txtIme.Text = reader["ime"].ToString();
            txtPrezime.Text = reader["prezime"].ToString(); ;
            rbtnPol.SelectedValue = reader["pol"].ToString();
            txtDatumRodjenja.Text = reader["datum_rodjenja"].ToString();
            txtDrzavljanstvo.Text = reader["drzavljanstvo"].ToString();
            rbtnBracnoStanje.SelectedValue = reader["bracno_stanje"].ToString();
            txtAdresa.Text = reader["adresa"].ToString();
            txtPostanskiBroj.Text = reader["postanski_broj"].ToString();
            txtGrad.Text = reader["grad"].ToString();
            txtOpstina.Text = reader["opstina"].ToString();
            txtDrzava.Text = reader["drzava"].ToString();
            txtKucniTelefon.Text = reader["kucni_telefon"].ToString();
            txtMobilniTelefon.Text = reader["mobilni_telefon"].ToString();
            txtEmail.Text = reader["web_site"].ToString();

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void cmdUpload_Click(object sender, EventArgs e)
    {
        if (Uploader.PostedFile.FileName == "")
        {
            lblInfo.Text = "<h3>Niste odabrali fotografiju.</h3>";
        }
        else
        {
            string extension = Path.GetExtension(Uploader.PostedFile.FileName);

            switch (extension.ToLower())
            {
                case ".jpg":
                    break;
                default:
                    lblInfo.Text = "<h3>Tip fotografije nije adekvatan.<br />Fotografija treba da ima \".jpg\" ekstenziju.</h3>";
                    return;
            }

            KorisnickiPodaci korisnik = new KorisnickiPodaci();
            string ImageName = korisnik.ObezbediKorisnickiKljuc();

            uploadDirectory = Path.Combine(Request.PhysicalApplicationPath, "Fotografije_Korisnika" + @"\");
            if (!System.IO.Directory.Exists(uploadDirectory))
                System.IO.Directory.CreateDirectory(uploadDirectory);


            string serverFileName = Path.GetFileName(ImageName + extension);
            string fullUploadPath = Path.Combine(uploadDirectory, serverFileName);

            Fotografije fotografija = new Fotografije();
            fotografija.PutanjaDoFotografije = "~/Fotografije_Korisnika" + @"/" + serverFileName;
            fotografija.SnimiPodatke_TabelaFotografije(fotografija.PutanjaDoFotografije);

            try
            {
                Uploader.PostedFile.SaveAs(fullUploadPath);
                lblInfo.Text = "<h3>Fotografija  je uspešno snimljena.</h3>";
            }
            catch (Exception err)
            {
                lblInfo.Text = err.Message;
            }
        }
    }

    protected void cmdSnimiPodatke_TabelaOsnovniPodaci_Click(object sender, EventArgs e)
    {
        OsnovniPodaci db = new OsnovniPodaci();
        db.Ime = txtIme.Text;
        db.Prezime = txtPrezime.Text;
        db.Pol = rbtnPol.SelectedValue.ToString();
        db.DatumRodjenja = txtDatumRodjenja.Text;
        db.Drzavljanstvo = txtDrzavljanstvo.Text;
        db.BracnoStanje = rbtnBracnoStanje.SelectedValue.ToString();
        db.Adresa = txtAdresa.Text;
        db.PostanskiBroj = txtPostanskiBroj.Text;
        db.Grad = txtGrad.Text;
        db.Opstina = txtOpstina.Text;
        db.Drzava = txtDrzava.Text;
        db.KucniTelefon = txtKucniTelefon.Text;
        db.MobilniTelefon = txtMobilniTelefon.Text;
        db.WebSite = txtEmail.Text;

        db.SnimiPodatke_TabelaOsnovniPodaci(
            db.Ime,
            db.Prezime,
            db.Pol,
            db.DatumRodjenja,
            db.Drzavljanstvo,
            db.BracnoStanje,
            db.Adresa,
            db.PostanskiBroj,
            db.Grad,
            db.Opstina,
            db.Drzava,
            db.KucniTelefon,
            db.MobilniTelefon,
            db.WebSite);
    }
}
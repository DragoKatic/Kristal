﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;
using System.Data.OleDb;
using System.Web.Configuration;

public partial class Radnici_LicnaSwotAnaliza : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            UcitajPodatkeLicnaSwotAnaliza();
        }
    }

    private string connectionStringKristal =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;


    protected void UcitajPodatkeLicnaSwotAnaliza()
    {
        UcitajSnage();
        UcitajSlabosti();
        UcitajSanse();
        UcitajPretnje();
    }

    protected void UcitajSnage()
    {
        string greska = "";
        string select = "";
        txtSnaga1.Text = "";
        txtSnaga2.Text = "";
        txtSnaga3.Text = "";
        txtSnaga4.Text = "";
        txtSnaga5.Text = "";
        txtSnaga6.Text = "";

        KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
        string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

        select += "SELECT * FROM `TabelaSnage` WHERE `korisnik_id` = ?";
        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            txtSnaga1.Text = reader["snaga_1"].ToString();
            txtSnaga2.Text = reader["snaga_2"].ToString();
            txtSnaga3.Text = reader["snaga_3"].ToString();
            txtSnaga4.Text = reader["snaga_4"].ToString();
            txtSnaga5.Text = reader["snaga_5"].ToString();
            txtSnaga6.Text = reader["snaga_6"].ToString();

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void UcitajSlabosti()
    {
        string greska = "";
        string select = "";
        txtSlabost1.Text = "";
        txtSlabost2.Text = "";
        txtSlabost3.Text = "";
        txtSlabost4.Text = "";
        txtSlabost5.Text = "";
        txtSlabost6.Text = "";

        KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
        string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

        select += "SELECT * FROM `TabelaSlabosti` WHERE `korisnik_id` = ?";
        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            txtSlabost1.Text = reader["slabost_1"].ToString();
            txtSlabost2.Text = reader["slabost_2"].ToString();
            txtSlabost3.Text = reader["slabost_3"].ToString();
            txtSlabost4.Text = reader["slabost_4"].ToString();
            txtSlabost5.Text = reader["slabost_5"].ToString();
            txtSlabost6.Text = reader["slabost_6"].ToString();

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void UcitajSanse()
    {
        string greska = "";
        string select = "";
        txtSansa1.Text = "";
        txtSansa2.Text = "";
        txtSansa3.Text = "";
        txtSansa4.Text = "";
        txtSansa5.Text = "";
        txtSansa6.Text = "";


        KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
        string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

        select += "SELECT * FROM `TabelaSanse` WHERE `korisnik_id` = ?";
        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            txtSansa1.Text = reader["sansa_1"].ToString();
            txtSansa2.Text = reader["sansa_2"].ToString();
            txtSansa3.Text = reader["sansa_3"].ToString();
            txtSansa4.Text = reader["sansa_4"].ToString();
            txtSansa5.Text = reader["sansa_5"].ToString();
            txtSansa6.Text = reader["sansa_6"].ToString();

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void UcitajPretnje()
    {
        string greska = "";
        string select = "";
        txtPretnja1.Text = "";
        txtPretnja2.Text = "";
        txtPretnja3.Text = "";
        txtPretnja4.Text = "";
        txtPretnja5.Text = "";
        txtPretnja6.Text = "";


        KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
        string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

        select += "SELECT * FROM `TabelaPretnje` WHERE `korisnik_id` = ?";
        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();
            
            txtPretnja1.Text = reader["pretnja_1"].ToString();
            txtPretnja2.Text = reader["pretnja_2"].ToString();
            txtPretnja3.Text = reader["pretnja_3"].ToString();
            txtPretnja4.Text = reader["pretnja_4"].ToString();
            txtPretnja5.Text = reader["pretnja_5"].ToString();
            txtPretnja6.Text = reader["pretnja_6"].ToString();

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void cmdSnimiPodatkeSwot_Click(object sender, EventArgs e)
    {
        Swot s = new Swot();

        s.Pretnja1 = txtPretnja1.Text;
        s.Pretnja2 = txtPretnja2.Text;
        s.Pretnja3 = txtPretnja3.Text;
        s.Pretnja4 = txtPretnja4.Text;
        s.Pretnja5 = txtPretnja5.Text;
        s.Pretnja6 = txtPretnja6.Text;

        s.Sansa1 = txtSansa1.Text;
        s.Sansa2 = txtSansa2.Text;
        s.Sansa3 = txtSansa3.Text;
        s.Sansa4 = txtSansa4.Text;
        s.Sansa5 = txtSansa5.Text;
        s.Sansa6 = txtSansa6.Text;

        s.Slabost1 = txtSlabost1.Text;
        s.Slabost2 = txtSlabost2.Text;
        s.Slabost3 = txtSlabost3.Text;
        s.Slabost4 = txtSlabost4.Text;
        s.Slabost5 = txtSlabost5.Text;
        s.Slabost6 = txtSlabost6.Text;

        s.Snaga1 = txtSnaga1.Text;
        s.Snaga2 = txtSnaga2.Text;
        s.Snaga3 = txtSnaga3.Text;
        s.Snaga4 = txtSnaga4.Text;
        s.Snaga5 = txtSnaga5.Text;
        s.Snaga6 = txtSnaga6.Text;

        s.SnimiPodatke_TabelaPretnje(
            s.Pretnja1,
            s.Pretnja2,
            s.Pretnja3,
            s.Pretnja4,
            s.Pretnja5,
            s.Pretnja6);

        s.SnimiPodatke_TabelaSanse(
            s.Sansa1,
            s.Sansa2,
            s.Sansa3,
            s.Sansa4,
            s.Sansa5,
            s.Sansa6);

        s.SnimiPodatke_TabelaSlabosti(
            s.Slabost1,
            s.Slabost2,
            s.Slabost3,
            s.Slabost4,
            s.Slabost5,
            s.Slabost6);

        s.SnimiPodatke_TabelaSnage(
            s.Snaga1,
            s.Snaga2,
            s.Snaga3,
            s.Snaga4,
            s.Snaga5,
            s.Snaga6);

        RazvojnePotrebe r = new RazvojnePotrebe();

        r.OpisPonasanja1 = txtSlabost1.Text;
        r.OpisPonasanja2 = txtSlabost2.Text;
        r.OpisPonasanja3 = txtSlabost3.Text;
        r.OpisPonasanja4 = txtSlabost4.Text;
        r.OpisPonasanja5 = txtSlabost5.Text;
        r.OpisPonasanja6 = txtSlabost6.Text;

        r.SnimiPodatke_OpisPonasanja_TabelaRazvojnePotrebe(
            r.OpisPonasanja1,
            r.OpisPonasanja2,
            r.OpisPonasanja3,
            r.OpisPonasanja4,
            r.OpisPonasanja5,
            r.OpisPonasanja6);

        Response.Redirect("~/Radnici/RazvojnePotrebe.aspx");
    }
}

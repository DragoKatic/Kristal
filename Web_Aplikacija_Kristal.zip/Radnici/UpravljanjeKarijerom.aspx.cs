﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Radnici_UpravljanjeKarijerom : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            UcitajUpravljanjeKarijerom();
        }
    }

    private string connectionStringKristal =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;

    protected void UcitajSnage(string korisnik_id)
    {
        string greska = "";
        string select = "";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        select += "SELECT * FROM `TabelaSnage` WHERE `korisnik_id` = ?";
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            txtSwot.Text += "Snage:\n";
            txtSwot.Text += reader["snaga_1"].ToString() + "\n";
            txtSwot.Text += reader["snaga_2"].ToString() + "\n";
            txtSwot.Text += reader["snaga_3"].ToString() + "\n";
            txtSwot.Text += reader["snaga_4"].ToString() + "\n";
            txtSwot.Text += reader["snaga_5"].ToString() + "\n";
            txtSwot.Text += reader["snaga_6"].ToString() + "\n";
            txtSwot.Text += ("\n");

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }

    }

    protected void UcitajSlabosti(string korisnik_id)
    {
        string greska = "";
        string select = "";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        select += "SELECT * FROM `TabelaSlabosti` WHERE `korisnik_id` = ?";
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            txtSwot.Text += "Slabosti:\n";
            txtSwot.Text += reader["slabost_1"].ToString() + "\n";
            txtSwot.Text += reader["slabost_2"].ToString() + "\n";
            txtSwot.Text += reader["slabost_3"].ToString() + "\n";
            txtSwot.Text += reader["slabost_4"].ToString() + "\n";
            txtSwot.Text += reader["slabost_5"].ToString() + "\n";
            txtSwot.Text += reader["slabost_6"].ToString() + "\n";
            txtSwot.Text += ("\n");

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void UcitajSanse(string korisnik_id)
    {
        string greska = "";
        string select = "";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        select += "SELECT * FROM `TabelaSanse` WHERE `korisnik_id` = ?";
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            txtSwot.Text += "Šanse:\n";
            txtSwot.Text += reader["sansa_1"].ToString() + "\n";
            txtSwot.Text += reader["sansa_2"].ToString() + "\n";
            txtSwot.Text += reader["sansa_3"].ToString() + "\n";
            txtSwot.Text += reader["sansa_4"].ToString() + "\n";
            txtSwot.Text += reader["sansa_5"].ToString() + "\n";
            txtSwot.Text += reader["sansa_6"].ToString() + "\n";
            txtSwot.Text += ("\n");

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void UcitajPretnje(string korisnik_id)
    {
        string greska = "";
        string select = "";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        select += "SELECT * FROM `TabelaPretnje` WHERE `korisnik_id` = ?";
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            txtSwot.Text += "Pretnje:\n";
            txtSwot.Text += reader["pretnja_1"].ToString() + "\n";
            txtSwot.Text += reader["pretnja_2"].ToString() + "\n";
            txtSwot.Text += reader["pretnja_3"].ToString() + "\n";
            txtSwot.Text += reader["pretnja_4"].ToString() + "\n";
            txtSwot.Text += reader["pretnja_5"].ToString() + "\n";
            txtSwot.Text += reader["pretnja_6"].ToString() + "\n";
            txtSwot.Text += ("\n");

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void UcitajMisije(string korisnik_id)
    {
        string greska = "";
        string select = "";

        txtMisija.Text = "";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        select += "SELECT * FROM `TabelaMisije` WHERE `korisnik_id` = ?";
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            txtMisija.Text = reader["misija"].ToString();


            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void UcitajTrenutnoStanje(string korisnik_id)
    {
        string greska = "";
        string select = "";

        txtMojaRealnost.Text = "";
        txtSlikaOMeni.Text = "";
        txtMojiKvaliteti.Text = "";
        txtMojaRealnost.Text = "";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        select += "SELECT * FROM `TabelaTrenutnoStanje` WHERE `korisnik_id` = ?";
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();
                                             
            txtSlikaOMeni.Text = reader["slika_o_meni"].ToString();
            txtMojiKvaliteti.Text = reader["moj_kvalitet"].ToString();
            txtMojaRealnost.Text = reader["moja_realnost"].ToString();

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void UcitajCiljeve(string korisnik_id)
    {
        string greska = "";
        string select = "";

        txtOpisCilja1.Text = "";
        txtOpisCilja2.Text = "";
        txtOpisCilja3.Text = "";
        txtOpisCilja4.Text = "";
        txtOpisCilja5.Text = "";
        txtOpisCilja6.Text = "";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        select += "SELECT * FROM `TabelaCiljevi` WHERE `korisnik_id` = ?";
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            txtOpisCilja1.Text = reader["opis_cilja_1"].ToString();
            txtOpisCilja2.Text = reader["opis_cilja_2"].ToString();
            txtOpisCilja3.Text = reader["opis_cilja_3"].ToString();
            txtOpisCilja4.Text = reader["opis_cilja_4"].ToString();
            txtOpisCilja5.Text = reader["opis_cilja_5"].ToString();
            txtOpisCilja6.Text = reader["opis_cilja_6"].ToString();

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void UcitajVrednovanjeOstvarenja(string korisnik_id)
    {
        string greska = "";
        string select = "";

        txtOpisOstvarenja1.Text = "";
        txtOpisOstvarenja2.Text = "";
        txtOpisOstvarenja3.Text = "";
        txtOpisOstvarenja4.Text = "";
        txtOpisOstvarenja5.Text = "";
        txtOpisOstvarenja6.Text = "";

        kalendarDatumOstvarenja1.SelectedDate = DateTime.Now;
        kalendarDatumOstvarenja2.SelectedDate = DateTime.Now;
        kalendarDatumOstvarenja3.SelectedDate = DateTime.Now;
        kalendarDatumOstvarenja4.SelectedDate = DateTime.Now;
        kalendarDatumOstvarenja5.SelectedDate = DateTime.Now;
        kalendarDatumOstvarenja6.SelectedDate = DateTime.Now;

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        select += "SELECT * FROM `TabelaVrednovanjeOstvarenja` WHERE `korisnik_id` = ?";
        OleDbCommand cmd = new OleDbCommand(select, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            txtOpisOstvarenja1.Text = reader["opis_ostvarenja_1"].ToString();
            txtOpisOstvarenja2.Text = reader["opis_ostvarenja_2"].ToString();
            txtOpisOstvarenja3.Text = reader["opis_ostvarenja_3"].ToString();
            txtOpisOstvarenja4.Text = reader["opis_ostvarenja_4"].ToString();
            txtOpisOstvarenja5.Text = reader["opis_ostvarenja_5"].ToString();
            txtOpisOstvarenja6.Text = reader["opis_ostvarenja_6"].ToString();

            kalendarDatumOstvarenja1.SelectedDate = Convert.ToDateTime(reader["datum_ostvarenja_1"].ToString());
            kalendarDatumOstvarenja2.SelectedDate = Convert.ToDateTime(reader["datum_ostvarenja_2"].ToString());
            kalendarDatumOstvarenja3.SelectedDate = Convert.ToDateTime(reader["datum_ostvarenja_3"].ToString());
            kalendarDatumOstvarenja4.SelectedDate = Convert.ToDateTime(reader["datum_ostvarenja_4"].ToString());
            kalendarDatumOstvarenja5.SelectedDate = Convert.ToDateTime(reader["datum_ostvarenja_5"].ToString());
            kalendarDatumOstvarenja6.SelectedDate = Convert.ToDateTime(reader["datum_ostvarenja_6"].ToString());

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }
    }

    protected void UcitajUpravljanjeKarijerom()
    {
        KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
        string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();
        UcitajSlabosti(korisnik_id);
        UcitajSnage(korisnik_id);
        UcitajPretnje(korisnik_id);
        UcitajSanse(korisnik_id);
        UcitajMisije(korisnik_id);
        UcitajTrenutnoStanje(korisnik_id);
        UcitajCiljeve(korisnik_id);
        UcitajVrednovanjeOstvarenja(korisnik_id);
    }
    protected void cmdSnimiPodatkeGrow_Click(object sender, EventArgs e)
    {
        Grow g = new Grow();

        g.Misija = txtMisija.Text;

        g.SnimiPodatke_TabelaMisije(g.Misija);

        g.SwotRezime = txtMojaRealnost.Text;
        g.SlikaOMeni = txtSlikaOMeni.Text;
        g.MojKvalitet = txtMojiKvaliteti.Text;
        g.MojaRealnost = txtMojaRealnost.Text;

        g.SnimiPodatke_TabelaTrenutnoStanje(
            g.SwotRezime,
            g.SlikaOMeni,
            g.MojKvalitet,
            g.MojaRealnost);

        g.OpisCilja1 = txtOpisCilja1.Text;
        g.OpisCilja2 = txtOpisCilja2.Text;
        g.OpisCilja3 = txtOpisCilja3.Text;
        g.OpisCilja4 = txtOpisCilja4.Text;
        g.OpisCilja5 = txtOpisCilja5.Text;
        g.OpisCilja6 = txtOpisCilja6.Text;

        g.SnimiPodatke_TabelaCiljevi(
            g.OpisCilja1,
            g.OpisCilja2,
            g.OpisCilja3,
            g.OpisCilja4,
            g.OpisCilja5,
            g.OpisCilja6);

        g.OpisOstvarenja1 = txtOpisOstvarenja1.Text;
        g.OpisOstvarenja2 = txtOpisOstvarenja2.Text;
        g.OpisOstvarenja3 = txtOpisOstvarenja3.Text;
        g.OpisOstvarenja4 = txtOpisOstvarenja4.Text;
        g.OpisOstvarenja5 = txtOpisOstvarenja5.Text;
        g.OpisOstvarenja6 = txtOpisOstvarenja6.Text;
        g.DatumOstvarenja1 = Convert.ToString(kalendarDatumOstvarenja1.SelectedDate);
        g.DatumOstvarenja2 = Convert.ToString(kalendarDatumOstvarenja2.SelectedDate);
        g.DatumOstvarenja3 = Convert.ToString(kalendarDatumOstvarenja3.SelectedDate);
        g.DatumOstvarenja4 = Convert.ToString(kalendarDatumOstvarenja4.SelectedDate);
        g.DatumOstvarenja5 = Convert.ToString(kalendarDatumOstvarenja5.SelectedDate);
        g.DatumOstvarenja6 = Convert.ToString(kalendarDatumOstvarenja6.SelectedDate);

        g.SnimiPodatke_TabelaVrednovanjeOstvarenja(
            g.OpisOstvarenja1,
            g.OpisOstvarenja2,
            g.OpisOstvarenja3,
            g.OpisOstvarenja4,
            g.OpisOstvarenja5,
            g.OpisOstvarenja6,
            g.DatumOstvarenja1,
            g.DatumOstvarenja2,
            g.DatumOstvarenja3,
            g.DatumOstvarenja4,
            g.DatumOstvarenja5,
            g.DatumOstvarenja6);
    }
}

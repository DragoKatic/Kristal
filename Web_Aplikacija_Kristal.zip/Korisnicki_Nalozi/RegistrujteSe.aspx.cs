﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;

public partial class Korisnicki_Nalozi_RegistrujteSe : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        CreateUserWizard1.ContinueDestinationPageUrl = Request.QueryString["ReturnUrl"];
    }

    protected void CreateUserWizard1_CreatedUser(object sender, EventArgs e)
    {
        string IdKorisnika = "";
        string ErrorMessage = "";

        FormsAuthentication.SetAuthCookie(CreateUserWizard1.UserName, false);

        string continueUrl = CreateUserWizard1.ContinueDestinationPageUrl;
        if (String.IsNullOrEmpty(continueUrl))
        {
            continueUrl = "~/Korisnicki_Nalozi/PrijaviteSe.aspx";
        }
        try
        {
            TextBox userNameTextBox =
                (TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("UserName");

            MembershipUser korisnik = Membership.GetUser(userNameTextBox.Text);
            IdKorisnika = korisnik.ProviderUserKey.ToString();

            KorisnickiPodaci rezervacija = new KorisnickiPodaci();
            rezervacija.KorisnikId = IdKorisnika;
            rezervacija.Rezervisi(rezervacija.KorisnikId);
        }
        catch (NullReferenceException izuzetak)
        {
            ErrorMessage = izuzetak.Message;
        }

        Response.Redirect(continueUrl);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.OleDb;
using System.Web.Configuration;

namespace KristalBiblioteka
{
    public class Samoaktualizacija
    {
        private string
            connectionString,
            korisnikId,
            postignuce,
            zadovoljstvo,
            ispunjenost,
            korisnost,
            sposobnost,
            ekspresivnost,
            samostalnost,
            vaznost,
            postovanje,
            uspesnost,
            neogranicenost,
            ponos,
            ostvarenost,
            perspektivnost,
            sigurnost,
            svrsishodnost,
            ambicioznost,
            realnost,
            razlicitost,
            samouverenost;

        public Samoaktualizacija()
        {
            connectionString =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;
        }

        public string KorisnikId
        {
            get { return korisnikId; }
            set { korisnikId = value; }
        }

        public string Postignuce
        {
            get {return postignuce;}
            set {postignuce = value;}
        }

        public string Zadovoljstvo
        {
            get {return zadovoljstvo;}
            set {zadovoljstvo = value;}
        }

        public string Ispunjenost
        {
            get {return ispunjenost;}
            set {ispunjenost = value;}
        }

        public string Korisnost
        {
            get {return korisnost;}
            set {korisnost = value;}
        }

        public string Sposobnost
        {
            get {return sposobnost;}
            set {sposobnost = value;}
        }

        public string Ekspresivnost
        {
            get {return ekspresivnost;}
            set {ekspresivnost = value;}
        }

        public string Samostalnost
        {
            get {return samostalnost;}
            set {samostalnost = value;}
        }

        public string Vaznost
        {
            get {return vaznost;}
            set {vaznost = value;;}
        }

        public string Postovanje
        {
            get {return postovanje;}
            set {postovanje = value;}
        }

        public string Uspesnost
        {
            get {return uspesnost;}
            set {uspesnost = value;}
        }

        public string Neogranicenost
        {
            get {return neogranicenost;}
            set {neogranicenost = value;}
        }

        public string Ponos
        {
            get {return ponos;}
            set {ponos = value;}
        }

        public string Ostvarenost
        {
            get {return ostvarenost;}
            set {ostvarenost = value;}
        }

        public string Perspektivnost
        {
            get {return perspektivnost;}
            set {perspektivnost = value;}
        }

        public string Sigurnost
        {
            get {return sigurnost;}
            set {sigurnost = value;}
        }

        public string Svrsishodnost
        {
            get {return svrsishodnost;}
            set {svrsishodnost = value;}
        }

        public string Ambicioznost
        {
            get {return ambicioznost;}
            set {ambicioznost = value;}
        }

        public string Realnost
        {
            get {return realnost;}
            set {realnost = value;}
        }

        public string Razlicitost
        {
            get {return razlicitost;}
            set {razlicitost = value;}
        }

        public string Samouverenost
        {
            get {return samouverenost;}
            set {samouverenost = value;}
        }

        public void SnimiPodatke_TabelaSamoaktualizacija(
            string postignuce,
            string zadovoljstvo,
            string ispunjenost,
            string korisnost,
            string sposobnost,
            string ekspresivnost,
            string samostalnost,
            string vaznost,
            string postovanje,
            string uspesnost,
            string neogranicenost,
            string ponos,
            string ostvarenost,
            string perspektivnost,
            string sigurnost,
            string svrsishodnost,
            string ambicioznost,
            string realnost,
            string razlicitost,
            string samouverenost)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaSamoaktualizacija` SET ");
            sb.Append("`postignuce` = ?, `zadovoljstvo` = ?, `ispunjenost` = ?, ");
            sb.Append("`korisnost` = ?, `sposobnost` = ?, `ekspresivnost` = ?, ");
            sb.Append("`samostalnost` = ?, `vaznost` = ?, `postovanje` = ?, ");
            sb.Append("`uspesnost` = ?, `neogranicenost` = ?, `ponos` = ?, ");
            sb.Append("`ostvarenost` = ?, `perspektivnost` = ?, `sigurnost` = ?, ");
            sb.Append("`svrsishodnost` = ?, `ambicioznost` = ?, `realnost` = ?, ");
            sb.Append("`razlicitost` = ?, `samouverenost` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.AddWithValue("postignuce", postignuce);
            cmd.Parameters.AddWithValue("zadovoljstvo", zadovoljstvo);
            cmd.Parameters.AddWithValue("ispunjenost", ispunjenost);
            cmd.Parameters.AddWithValue("korisnost", korisnost);
            cmd.Parameters.AddWithValue("sposobnost", sposobnost);
            cmd.Parameters.AddWithValue("ekspresivnost", ekspresivnost);
            cmd.Parameters.AddWithValue("samostalnost", samostalnost);
            cmd.Parameters.AddWithValue("vaznost", vaznost);
            cmd.Parameters.AddWithValue("postovanje", postovanje);
            cmd.Parameters.AddWithValue("uspesnost", uspesnost);
            cmd.Parameters.AddWithValue("neogranicenost", neogranicenost);
            cmd.Parameters.AddWithValue("ponos", ponos);
            cmd.Parameters.AddWithValue("ostvarenost", ostvarenost);
            cmd.Parameters.AddWithValue("perspektivnost", perspektivnost);
            cmd.Parameters.AddWithValue("sigurnost", sigurnost);
            cmd.Parameters.AddWithValue("svrsishodnost", svrsishodnost);
            cmd.Parameters.AddWithValue("ambicioznost", ambicioznost);
            cmd.Parameters.AddWithValue("realnost", realnost);
            cmd.Parameters.AddWithValue("razlicitost", razlicitost);
            cmd.Parameters.AddWithValue("samouverenost", samouverenost);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }
    }
}

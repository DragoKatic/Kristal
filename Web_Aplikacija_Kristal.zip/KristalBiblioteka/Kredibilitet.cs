﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.OleDb;
using System.Web.Configuration;

namespace KristalBiblioteka
{
    public class Kredibilitet
    {
        private string
            connectionString,
            korisnikId,
            staJeKredibilitet,
            staZaVasZnaciKredibilitet,
            vaznostTacnosti,
            vaznostPoverenja,
            proveraPoverenja,
            povracajPoverenja,
            popravkaKredibiliteta,
            osobeBezKredibiliteta,
            kogaZaposljavate,
            komePoveravatePosao,
            vaznostSamosvesnosti,
            osobeKojePrihvatajuGreske;

        public Kredibilitet()
        {
            connectionString =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;
        }

        public string KorisnikId
        {
            get {return korisnikId;}
            set {korisnikId = value;}
        }

        public string StaJeKredibilitet
        {
            get {return staJeKredibilitet;}
            set {staJeKredibilitet = value;}
        }

        public string StaZaVasZnaciKredibilitet
        {
            get {return staZaVasZnaciKredibilitet;}
            set {staZaVasZnaciKredibilitet = value;}
        }

        public string VaznostTacnosti
        {
            get {return vaznostTacnosti;}
            set {vaznostTacnosti = value;}
        }

        public string VaznostPoverenja
        {
            get {return vaznostPoverenja;}
            set {vaznostPoverenja = value;}
        }

        public string ProveraPoverenja
        {
            get {return proveraPoverenja;}
            set {proveraPoverenja = value;}
        }

        public string PovracajPoverenja
        {
            get {return povracajPoverenja;}
            set {povracajPoverenja = value;}
        }

        public string PopravkaKredibiliteta
        {
            get {return popravkaKredibiliteta;}
            set {popravkaKredibiliteta = value;}
        }

        public string OsobeBezKredibiliteta
        {
            get {return osobeBezKredibiliteta;}
            set {osobeBezKredibiliteta = value;}
        }

        public string KogaZaposljavate
        {
            get {return kogaZaposljavate;}
            set {kogaZaposljavate = value;}
        }

        public string KomePoveravatePosao
        {
            get {return komePoveravatePosao;}
            set {komePoveravatePosao = value;}
        }

        public string VaznostSamosvesnosti
        {
            get {return vaznostSamosvesnosti;}
            set {vaznostSamosvesnosti = value;}
        }

        public string OsobeKojePrihvatajuGreske
        {
            get {return osobeKojePrihvatajuGreske;}
            set { osobeKojePrihvatajuGreske = value; }
        }

        public void SnimiPodatke_TabelaKredibilitet(
            string sta_je_kredibilitet,
            string sta_za_vas_znaci_kredibilitet,
            string vaznost_tacnosti,
            string vaznost_poverenja,
            string provera_poverenja,
            string povracaj_poverenja,
            string popravka_kredibiliteta,
            string osobe_bez_kredibiliteta,
            string koga_zaposljavate,
            string kome_poveravate_posao,
            string vaznost_samosvesnosti,
            string osobe_koje_prihvataju_greske)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaKredibilitet` SET ");
            sb.Append("`sta_je_kredibilitet` = ?, ");
            sb.Append("`sta_za_vas_znaci_kredibilitet` = ?, ");
            sb.Append("`vaznost_tacnosti` = ?, ");
            sb.Append("`vaznost_poverenja` = ?, ");
            sb.Append("`provera_poverenja` = ?, ");
            sb.Append("`povracaj_poverenja` = ?, ");
            sb.Append("`popravka_kredibiliteta` = ?, ");
            sb.Append("`osobe_bez_kredibiliteta` = ?, ");
            sb.Append("`koga_zaposljavate` = ?, ");
            sb.Append("`kome_poveravate_posao` = ?, ");
            sb.Append("`vaznost_samosvesnosti` = ?, ");
            sb.Append("`osobe_koje_prihvataju_greske` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.AddWithValue("sta_je_kredibilitet", sta_je_kredibilitet);
            cmd.Parameters.AddWithValue("sta_za_vas_znaci_kredibilitet", sta_za_vas_znaci_kredibilitet);
            cmd.Parameters.AddWithValue("vaznost_tacnosti", vaznost_tacnosti);
            cmd.Parameters.AddWithValue("vaznost_poverenja", vaznost_poverenja);
            cmd.Parameters.AddWithValue("provera_poverenja", provera_poverenja);
            cmd.Parameters.AddWithValue("povracaj_poverenja", povracaj_poverenja);
            cmd.Parameters.AddWithValue("popravka_kredibiliteta", popravka_kredibiliteta);
            cmd.Parameters.AddWithValue("osobe_bez_kredibiliteta", osobe_bez_kredibiliteta);
            cmd.Parameters.AddWithValue("koga_zaposljavate", koga_zaposljavate);
            cmd.Parameters.AddWithValue("kome_poveravate_posao", kome_poveravate_posao);
            cmd.Parameters.AddWithValue("vaznost_samosvesnosti", vaznost_samosvesnosti);
            cmd.Parameters.AddWithValue("osobe_koje_prihvataju_greske", osobe_koje_prihvataju_greske);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }
    }
}

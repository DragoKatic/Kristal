﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.OleDb;
using System.Web.Configuration;

namespace KristalBiblioteka
{
    public class Fotografije
    {
        private string
            connectionString,
            korisnikId,
            putanjaDoFotografije;

        public Fotografije()
        {
            connectionString =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;
        }

        public string KorisnikId
        {
            get { return korisnikId; }
            set { korisnikId = value; }
        }

        public string PutanjaDoFotografije
        {
            get { return putanjaDoFotografije; }
            set { putanjaDoFotografije = value; }
        }

        public void SnimiPodatke_TabelaFotografije(string putanja_do_fotografije)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaFotografije` SET ");
            sb.Append("`putanja_do_fotografije` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;
            
            cmd.Parameters.AddWithValue("putanja_do_fotografije", putanja_do_fotografije);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }
    }
}

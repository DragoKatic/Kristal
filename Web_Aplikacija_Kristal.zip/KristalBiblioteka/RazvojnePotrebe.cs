﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.OleDb;
using System.Web.Configuration;

namespace KristalBiblioteka
{
    public class RazvojnePotrebe
    {
        private string
            connectionString,
            korisnikId,
            opisPonasanja1,
            opisPonasanja2,
            opisPonasanja3,
            opisPonasanja4,
            opisPonasanja5,
            opisPonasanja6,
            ciljKarijere1,
            ciljKarijere2,
            ciljKarijere3,
            ciljKarijere4,
            ciljKarijere5,
            ciljKarijere6,
            aktivnosti1,
            aktivnosti2,
            aktivnosti3,
            aktivnosti4,
            aktivnosti5,
            aktivnosti6,
            potrebniResursi1,
            potrebniResursi2,
            potrebniResursi3,
            potrebniResursi4,
            potrebniResursi5,
            potrebniResursi6,
            vremenskiRok1,
            vremenskiRok2,
            vremenskiRok3,
            vremenskiRok4,
            vremenskiRok5,
            vremenskiRok6,
            ostvareno1,
            ostvareno2,
            ostvareno3,
            ostvareno4,
            ostvareno5,
            ostvareno6;

        public RazvojnePotrebe()
        {
            connectionString =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;
        }

        public string KorisnikId
        {
            get { return korisnikId; }
            set { korisnikId = value; }
        }
        
        public string  OpisPonasanja1
        {
            get {return opisPonasanja1;}
            set {opisPonasanja1 = value;}
        }

        public string OpisPonasanja2
        {
            get {return opisPonasanja2;}
            set {opisPonasanja2 = value;}
        }

        public string OpisPonasanja3
        {
            get {return opisPonasanja3;}
            set {opisPonasanja3 = value;}
        }

        public string OpisPonasanja4
        {
            get {return opisPonasanja4;}
            set {opisPonasanja4 = value;}
        }

        public string OpisPonasanja5
        {
            get {return opisPonasanja5;}
            set {opisPonasanja5 = value;}
        }

        public string OpisPonasanja6
        {
            get {return opisPonasanja6;}
            set {opisPonasanja6 = value;}
        }

        public string CiljKarijere1
        {
            get {return ciljKarijere1;}
            set {ciljKarijere1 = value;}
        }

        public string CiljKarijere2
        {
            get {return ciljKarijere2;}
            set {ciljKarijere2 = value;}
        }

        public string CiljKarijere3
        {
            get {return ciljKarijere3;}
            set {ciljKarijere3 = value;}
        }

        public string CiljKarijere4
        {
            get {return ciljKarijere4;}
            set {ciljKarijere4 = value;}
        }

        public string CiljKarijere5
        {
            get {return ciljKarijere5;}
            set {ciljKarijere5 = value;}
        }

        public string CiljKarijere6
        {
            get {return ciljKarijere6;}
            set {ciljKarijere6 = value;}
        }

        public string Aktivnosti1
        {
            get {return aktivnosti1;}
            set {aktivnosti1 = value;}
        }

        public string Aktivnosti2
        {
            get {return aktivnosti2;}
            set {aktivnosti2 = value;}
        }

        public string Aktivnosti3
        {
            get {return aktivnosti3;}
            set {aktivnosti3 = value;}
        }

        public string Aktivnosti4
        {
            get {return aktivnosti4;}
            set {aktivnosti4 = value;}
        }

        public string Aktivnosti5
        {
            get {return aktivnosti5;}
            set {aktivnosti5 = value;}
        }

        public string Aktivnosti6
        {
            get {return aktivnosti6;}
            set {aktivnosti6 = value;}
        }

        public string PotrebniResursi1
        {
            get {return potrebniResursi1;}
            set {potrebniResursi1 = value;}
        }

        public string PotrebniResursi2
        {
            get {return potrebniResursi2;}
            set {potrebniResursi2 = value;}
        }

        public string PotrebniResursi3
        {
            get {return potrebniResursi3;}
            set {potrebniResursi3 = value;}
        }

        public string PotrebniResursi4
        {
            get {return potrebniResursi4;}
            set {potrebniResursi4 = value;}
        }

        public string PotrebniResursi5
        {
            get {return potrebniResursi5;}
            set {potrebniResursi5 = value;}
        }

        public string PotrebniResursi6
        {
            get {return potrebniResursi6;}
            set {potrebniResursi6 = value;}
        }

        public string VremenskiRok1
        {
            get {return vremenskiRok1;}
            set {vremenskiRok1 = value;}
        }

        public string VremenskiRok2
        {
            get {return vremenskiRok2;}
            set {vremenskiRok2 = value;}
        }

        public string VremenskiRok3
        {
            get {return vremenskiRok3;}
            set {vremenskiRok3 = value;}
        }

        public string VremenskiRok4
        {
            get {return vremenskiRok4;}
            set {vremenskiRok4 = value;}
        }

        public string VremenskiRok5
        {
            get {return vremenskiRok5;}
            set {vremenskiRok5 = value;}
        }

        public string VremenskiRok6
        {
            get {return vremenskiRok6;}
            set {vremenskiRok6 = value;}
        }

        public string Ostvareno1
        {
            get {return ostvareno1;}
            set {ostvareno1 = value;}
        }

        public string Ostvareno2
        {
            get {return ostvareno2;}
            set {ostvareno2 = value;}
        }

        public string Ostvareno3
        {
            get {return ostvareno3;}
            set {ostvareno3 = value;}
        }

        public string Ostvareno4
        {
            get {return ostvareno4;}
            set {ostvareno4 = value;}
        }

        public string Ostvareno5
        {
            get {return ostvareno5;}
            set {ostvareno5 = value;}
        }

        public string Ostvareno6
        {
            get {return ostvareno6;}
            set {ostvareno6 = value;}
        }
        


        public void SnimiPodatke_TabelaRazvojnePotrebe(
            string opis_ponasanja_1,
            string opis_ponasanja_2,
            string opis_ponasanja_3,
            string opis_ponasanja_4,
            string opis_ponasanja_5,
            string opis_ponasanja_6,
            string cilj_karijere_1,
            string cilj_karijere_2,
            string cilj_karijere_3,
            string cilj_karijere_4,
            string cilj_karijere_5,
            string cilj_karijere_6,
            string aktivnosti_1,
            string aktivnosti_2,
            string aktivnosti_3,
            string aktivnosti_4,
            string aktivnosti_5,
            string aktivnosti_6,
            string potrebni_resursi_1,
            string potrebni_resursi_2,
            string potrebni_resursi_3,
            string potrebni_resursi_4,
            string potrebni_resursi_5,
            string potrebni_resursi_6,
            string vremenski_rok_1,
            string vremenski_rok_2,
            string vremenski_rok_3,
            string vremenski_rok_4,
            string vremenski_rok_5,
            string vremenski_rok_6,
            string ostvareno_1,
            string ostvareno_2,
            string ostvareno_3,
            string ostvareno_4,
            string ostvareno_5,
            string ostvareno_6)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaRazvojnePotrebe` SET ");
            sb.Append("`opis_ponasanja_1` = ?, `opis_ponasanja_2` = ?, ");
            sb.Append("`opis_ponasanja_3` = ?, `opis_ponasanja_4` = ?, ");
            sb.Append("`opis_ponasanja_5` = ?, `opis_ponasanja_6` = ?, ");
            sb.Append("`cilj_karijere_1` = ?, `cilj_karijere_2` = ?, ");
            sb.Append("`cilj_karijere_3` = ?, `cilj_karijere_4` = ?, ");
            sb.Append("`cilj_karijere_5` = ?, `cilj_karijere_6` = ?, ");
            sb.Append("`aktivnosti_1` = ?, `aktivnosti_2` = ?, ");
            sb.Append("`aktivnosti_3` = ?, `aktivnosti_4` = ?, ");
            sb.Append("`aktivnosti_5` = ?, `aktivnosti_6` = ?, ");
            sb.Append("`potrebni_resursi_1` = ?, `potrebni_resursi_2` = ?, ");
            sb.Append("`potrebni_resursi_3` = ?, `potrebni_resursi_4` = ?, ");
            sb.Append("`potrebni_resursi_5` = ?, `potrebni_resursi_6` = ?, ");
            sb.Append("`vremenski_rok_1` = ?, `vremenski_rok_2` = ?, ");
            sb.Append("`vremenski_rok_3` = ?, `vremenski_rok_4` = ?, ");
            sb.Append("`vremenski_rok_5` = ?, `vremenski_rok_6` = ?, ");
            sb.Append("`ostvareno_1` = ?, `ostvareno_2` = ?, ");
            sb.Append("`ostvareno_3` = ?, `ostvareno_4` = ?, ");
            sb.Append("`ostvareno_5` = ?, `ostvareno_6` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.AddWithValue("opis_ponasanja_1", opis_ponasanja_1);
            cmd.Parameters.AddWithValue("opis_ponasanja_2", opis_ponasanja_2);
            cmd.Parameters.AddWithValue("opis_ponasanja_3", opis_ponasanja_3);
            cmd.Parameters.AddWithValue("opis_ponasanja_4", opis_ponasanja_4);
            cmd.Parameters.AddWithValue("opis_ponasanja_5", opis_ponasanja_5);
            cmd.Parameters.AddWithValue("opis_ponasanja_6", opis_ponasanja_6);
            
            cmd.Parameters.AddWithValue("cilj_karijere_1", cilj_karijere_1);
            cmd.Parameters.AddWithValue("cilj_karijere_2", cilj_karijere_2);
            cmd.Parameters.AddWithValue("cilj_karijere_3", cilj_karijere_3);
            cmd.Parameters.AddWithValue("cilj_karijere_4", cilj_karijere_4);
            cmd.Parameters.AddWithValue("cilj_karijere_5", cilj_karijere_5);
            cmd.Parameters.AddWithValue("cilj_karijere_6", cilj_karijere_6);

            cmd.Parameters.AddWithValue("aktivnosti_1", aktivnosti_1);
            cmd.Parameters.AddWithValue("aktivnosti_2", aktivnosti_2);
            cmd.Parameters.AddWithValue("aktivnosti_3", aktivnosti_3);
            cmd.Parameters.AddWithValue("aktivnosti_4", aktivnosti_4);
            cmd.Parameters.AddWithValue("aktivnosti_5", aktivnosti_5);
            cmd.Parameters.AddWithValue("aktivnosti_6", aktivnosti_6);
            
            cmd.Parameters.AddWithValue("potrebni_resursi_1", potrebni_resursi_1);
            cmd.Parameters.AddWithValue("potrebni_resursi_2", potrebni_resursi_2);
            cmd.Parameters.AddWithValue("potrebni_resursi_3", potrebni_resursi_3);
            cmd.Parameters.AddWithValue("potrebni_resursi_4", potrebni_resursi_4);
            cmd.Parameters.AddWithValue("potrebni_resursi_5", potrebni_resursi_5);
            cmd.Parameters.AddWithValue("potrebni_resursi_6", potrebni_resursi_6);
            
            cmd.Parameters.AddWithValue("vremenski_rok_1", vremenski_rok_1);
            cmd.Parameters.AddWithValue("vremenski_rok_2", vremenski_rok_2);
            cmd.Parameters.AddWithValue("vremenski_rok_3", vremenski_rok_3);
            cmd.Parameters.AddWithValue("vremenski_rok_4", vremenski_rok_4);
            cmd.Parameters.AddWithValue("vremenski_rok_5", vremenski_rok_5);
            cmd.Parameters.AddWithValue("vremenski_rok_6", vremenski_rok_6);
            
            cmd.Parameters.AddWithValue("ostvareno_1", ostvareno_1);
            cmd.Parameters.AddWithValue("ostvareno_2", ostvareno_2);
            cmd.Parameters.AddWithValue("ostvareno_3", ostvareno_3);
            cmd.Parameters.AddWithValue("ostvareno_4", ostvareno_4);
            cmd.Parameters.AddWithValue("ostvareno_5", ostvareno_5);
            cmd.Parameters.AddWithValue("ostvareno_6", ostvareno_6);

            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void SnimiPodatke_OpisPonasanja_TabelaRazvojnePotrebe(
            string opis_ponasanja_1,
            string opis_ponasanja_2,
            string opis_ponasanja_3,
            string opis_ponasanja_4,
            string opis_ponasanja_5,
            string opis_ponasanja_6)
        {
            OleDbConnection con1 = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaRazvojnePotrebe` SET ");
            sb.Append("`opis_ponasanja_1` = ?, ");
            sb.Append("`opis_ponasanja_2` = ?, ");
            sb.Append("`opis_ponasanja_3` = ?, ");
            sb.Append("`opis_ponasanja_4` = ?, ");
            sb.Append("`opis_ponasanja_5` = ?, ");
            sb.Append("`opis_ponasanja_6` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();
            
            OleDbCommand cmd1 = new OleDbCommand(update, con1);
            cmd1.CommandType = CommandType.Text;

            cmd1.Parameters.AddWithValue("opis_ponasanja_1", opis_ponasanja_1);
            cmd1.Parameters.AddWithValue("opis_ponasanja_2", opis_ponasanja_2);
            cmd1.Parameters.AddWithValue("opis_ponasanja_3", opis_ponasanja_3);
            cmd1.Parameters.AddWithValue("opis_ponasanja_4", opis_ponasanja_4);
            cmd1.Parameters.AddWithValue("opis_ponasanja_5", opis_ponasanja_5);
            cmd1.Parameters.AddWithValue("opis_ponasanja_6", opis_ponasanja_6);

            cmd1.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con1.Open();
                cmd1.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con1.Close();
            }
        }
    }
}

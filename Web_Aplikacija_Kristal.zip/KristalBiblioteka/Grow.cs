﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.OleDb;
using System.Web.Configuration;

namespace KristalBiblioteka
{
    public class Grow
    {
        private string
            connectionString,
            korisnikId,
            misija,
            swotRezime,
            slikaOMeni,
            mojKvalitet,
            mojaRealnost,
            opisCilja1,
            opisCilja2,
            opisCilja3,
            opisCilja4,
            opisCilja5,
            opisCilja6,
            opisOstvarenja1,
            opisOstvarenja2,
            opisOstvarenja3,
            opisOstvarenja4,
            opisOstvarenja5,
            opisOstvarenja6,
            datumOstvarenja1,
            datumOstvarenja2,
            datumOstvarenja3,
            datumOstvarenja4,
            datumOstvarenja5,
            datumOstvarenja6;

        public Grow()
        {
            connectionString =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;
        }

        public string KorisnikId
        {
            get {return korisnikId;}
            set {korisnikId = value;}
        }

        public string Misija
        {
            get {return misija;}
            set {misija = value;}
        }

        public string SwotRezime
        {
            get {return swotRezime;}
            set {swotRezime = value;}
        }

        public string SlikaOMeni
        {
            get {return slikaOMeni;}
            set {slikaOMeni = value;}
        }

        public string MojKvalitet
        {
            get {return mojKvalitet;}
            set {mojKvalitet = value;}
        }

        public string MojaRealnost
        {
            get {return mojaRealnost;}
            set {mojaRealnost = value;}
        }

        public string OpisCilja1
        {
            get {return opisCilja1;}
            set {opisCilja1 = value;}
        }

        public string OpisCilja2
        {
            get {return opisCilja2;}
            set {opisCilja2 = value;}
        }

        public string OpisCilja3
        {
            get {return opisCilja3;}
            set {opisCilja3 = value;}
        }

        public string OpisCilja4
        {
            get {return opisCilja4;}
            set {opisCilja4 = value;}
        }

        public string OpisCilja5
        {
            get {return opisCilja5;}
            set {opisCilja5 = value;}
        }

        public string OpisCilja6
        {
            get {return opisCilja6;}
            set {opisCilja6 = value;}
        }

        public string OpisOstvarenja1
        {
            get {return opisOstvarenja1;}
            set {opisOstvarenja1 = value;}
        }

        public string OpisOstvarenja2
        {
            get {return opisOstvarenja2;}
            set {opisOstvarenja2 = value;}
        }

        public string OpisOstvarenja3
        {
            get {return opisOstvarenja3;}
            set {opisOstvarenja3 = value;}
        }

        public string OpisOstvarenja4
        {
            get {return opisOstvarenja4;}
            set {opisOstvarenja4 = value;}
        }

        public string OpisOstvarenja5
        {
            get {return opisOstvarenja5;}
            set {opisOstvarenja5 = value;}
        }

        public string OpisOstvarenja6
        {
            get {return opisOstvarenja6;}
            set {opisOstvarenja6 = value;}
        }

        public string DatumOstvarenja1
        {
            get {return datumOstvarenja1;}
            set {datumOstvarenja1 = value;}
        }

        public string DatumOstvarenja2
        {
            get {return datumOstvarenja2;}
            set {datumOstvarenja2 = value;}
        }

        public string DatumOstvarenja3
        {
            get {return datumOstvarenja3;}
            set {datumOstvarenja3 = value;}
        }

        public string DatumOstvarenja4
        {
            get {return datumOstvarenja4;}
            set {datumOstvarenja4 = value;}
        }

        public string DatumOstvarenja5
        {
            get {return datumOstvarenja5;}
            set {datumOstvarenja5 = value;}
        }

        public string DatumOstvarenja6
        {
            get {return datumOstvarenja6;}
            set {datumOstvarenja6 = value;}
        }

        public void SnimiPodatke_TabelaMisije(string misija)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaMisije` SET `misija` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;
            
            cmd.Parameters.AddWithValue("misija", misija);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void SnimiPodatke_TabelaCiljevi(
            string opis_cilja_1,
            string opis_cilja_2,
            string opis_cilja_3,
            string opis_cilja_4,
            string opis_cilja_5,
            string opis_cilja_6)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaCiljevi` SET ");
            sb.Append("`opis_cilja_1` = ?, `opis_cilja_2` = ?, ");
            sb.Append("`opis_cilja_3` = ?, `opis_cilja_4` = ?, ");
            sb.Append("`opis_cilja_5` = ?, `opis_cilja_6` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;
            
            cmd.Parameters.AddWithValue("opis_cilja_1", opis_cilja_1);
            cmd.Parameters.AddWithValue("opis_cilja_2", opis_cilja_2);
            cmd.Parameters.AddWithValue("opis_cilja_3", opis_cilja_3);
            cmd.Parameters.AddWithValue("opis_cilja_4", opis_cilja_4);
            cmd.Parameters.AddWithValue("opis_cilja_5", opis_cilja_5);
            cmd.Parameters.AddWithValue("opis_cilja_6", opis_cilja_6);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void SnimiPodatke_TabelaTrenutnoStanje(
            string swot_rezime,
            string slika_o_meni,
            string moj_kvalitet,
            string moja_realnost)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaTrenutnoStanje` SET ");
            sb.Append("`swot_rezime` = ?, `slika_o_meni` = ?, ");
            sb.Append("`moj_kvalitet` = ?, `moja_realnost` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.AddWithValue("swot_rezime", swot_rezime);
            cmd.Parameters.AddWithValue("slika_o_meni", slika_o_meni);
            cmd.Parameters.AddWithValue("moj_kvalitet", moj_kvalitet);
            cmd.Parameters.AddWithValue("moja_realnost", moja_realnost);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void SnimiPodatke_TabelaVrednovanjeOstvarenja(
            string opis_ostvarenja_1,
            string opis_ostvarenja_2,
            string opis_ostvarenja_3,
            string opis_ostvarenja_4,
            string opis_ostvarenja_5,
            string opis_ostvarenja_6,
            string datum_ostvarenja_1,
            string datum_ostvarenja_2,
            string datum_ostvarenja_3,
            string datum_ostvarenja_4,
            string datum_ostvarenja_5,
            string datum_ostvarenja_6)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaVrednovanjeOstvarenja` SET ");
            sb.Append("`opis_ostvarenja_1` = ?, `opis_ostvarenja_2` = ?, ");
            sb.Append("`opis_ostvarenja_3` = ?, `opis_ostvarenja_4` = ?, ");
            sb.Append("`opis_ostvarenja_5` = ?, `opis_ostvarenja_6` = ?, ");
            sb.Append("`datum_ostvarenja_1` = ?, `datum_ostvarenja_2` = ?, ");
            sb.Append("`datum_ostvarenja_3` = ?, `datum_ostvarenja_4` = ?, ");
            sb.Append("`datum_ostvarenja_5` = ?, `datum_ostvarenja_6` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;
            
            cmd.Parameters.AddWithValue("opis_ostvarenja_1", opis_ostvarenja_1);
            cmd.Parameters.AddWithValue("opis_ostvarenja_2", opis_ostvarenja_2);
            cmd.Parameters.AddWithValue("opis_ostvarenja_3", opis_ostvarenja_3);
            cmd.Parameters.AddWithValue("opis_ostvarenja_4", opis_ostvarenja_4);
            cmd.Parameters.AddWithValue("opis_ostvarenja_5", opis_ostvarenja_5);
            cmd.Parameters.AddWithValue("opis_ostvarenja_6", opis_ostvarenja_6);
            cmd.Parameters.AddWithValue("datum_ostvarenja_1", datum_ostvarenja_1);
            cmd.Parameters.AddWithValue("datum_ostvarenja_2", datum_ostvarenja_2);
            cmd.Parameters.AddWithValue("datum_ostvarenja_3", datum_ostvarenja_3);
            cmd.Parameters.AddWithValue("datum_ostvarenja_4", datum_ostvarenja_4);
            cmd.Parameters.AddWithValue("datum_ostvarenja_5", datum_ostvarenja_5);
            cmd.Parameters.AddWithValue("datum_ostvarenja_6", datum_ostvarenja_6);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }
    }
}

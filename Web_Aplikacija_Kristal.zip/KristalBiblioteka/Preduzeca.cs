﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.OleDb;
using System.Web.Configuration;

namespace KristalBiblioteka
{
    public class Preduzeca
    {
        private string
            connectionString,
            korisnikId,
            naziv,
            pib,
            kontaktOsoba,
            fiksniTelefon,
            mobilniTelefon,
            adresa,
            postanskiBroj,
            mesto,
            region,
            eMail,
            webSite;

        public Preduzeca()
        {
            connectionString =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;
        }

        public string KorisnikId
        {
            get { return korisnikId; }
            set { korisnikId = value; }
        }

        public string Naziv
        {
            get {return naziv;}
            set {naziv = value;}
        }

        public string Pib
        {
            get {return pib;}
            set {pib = value;}
        }

        public string KontaktOsoba
        {
            get {return kontaktOsoba;}
            set {kontaktOsoba = value;}
        }

        public string FiksniTelefon
        {
            get {return fiksniTelefon;}
            set {fiksniTelefon = value;}
        }

        public string MobilniTelefon
        {
            get {return mobilniTelefon;}
            set {mobilniTelefon = value;}
        }

        public string Adresa
        {
            get {return adresa;}
            set {adresa = value;}
        }

        public string PostanskiBroj
        {
            get { return postanskiBroj; }
            set { postanskiBroj = value; }
        }

        public string Mesto
        {
            get {return mesto;}
            set {mesto = value;}
        }

        public string Region
        {
            get {return region;}
            set {region = value;}
        }

        public string EMail
        {
            get {return eMail;}
            set {eMail = value;}
        }

        public string WebSite
        {
            get {return webSite;}
            set {webSite = value;}
        }

        public void SnimiPodatke_TabelaPreduzeca(
            string naziv,
            string pib,
            string kontakt_osoba,
            string fiksni_telefon,
            string mobilni_telefon,
            string adresa,
            string postanski_broj,
            string mesto,
            string region,
            string e_mail,
            string web_site)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaPreduzeca` SET ");
            sb.Append("`naziv` = ?, `pib` = ?, `kontakt_osoba` = ?, `fiksni_telefon` = ?, ");
            sb.Append("`mobilni_telefon` = ?, `adresa` = ?, `postanski_broj` = ?, ");
            sb.Append("`mesto` = ?, `region` = ?, `e_mail` = ?, `web_site` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.AddWithValue("naziv", naziv);
            cmd.Parameters.AddWithValue("pib", pib);
            cmd.Parameters.AddWithValue("kontakt_osoba", kontakt_osoba);
            cmd.Parameters.AddWithValue("fiksni_telefon", fiksni_telefon);
            cmd.Parameters.AddWithValue("mobilni_telefon", mobilni_telefon);
            cmd.Parameters.AddWithValue("adresa", adresa);
            cmd.Parameters.AddWithValue("postanski_broj", postanski_broj);
            cmd.Parameters.AddWithValue("mesto", mesto);
            cmd.Parameters.AddWithValue("region", region);
            cmd.Parameters.AddWithValue("e_mail", e_mail);
            cmd.Parameters.AddWithValue("web_site", web_site);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }
    }
}

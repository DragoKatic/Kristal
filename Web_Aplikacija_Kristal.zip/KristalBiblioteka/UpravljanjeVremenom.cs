﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.OleDb;
using System.Web.Configuration;

namespace KristalBiblioteka
{
    public class UpravljanjeVremenom
    {
        private string
            connectionString,
            korisnikId,
            akt1Opis,
            akt1SatPon,
            akt1SatUto,
            akt1SatSre,
            akt1SatCet,
            akt1SatPet,
            akt1SatSub,
            akt1SatNed,
            akt1UkupnoSat,
            akt1UkupnoProc,
            akt2Opis,
            akt2SatPon,
            akt2SatUto,
            akt2SatSre,
            akt2SatCet,
            akt2SatPet,
            akt2SatSub,
            akt2SatNed,
            akt2UkupnoSat,
            akt2UkupnoProc,
            akt3Opis,
            akt3SatPon,
            akt3SatUto,
            akt3SatSre,
            akt3SatCet,
            akt3SatPet,
            akt3SatSub,
            akt3SatNed,
            akt3UkupnoSat,
            akt3UkupnoProc,
            akt4Opis,
            akt4SatPon,
            akt4SatUto,
            akt4SatSre,
            akt4SatCet,
            akt4SatPet,
            akt4SatSub,
            akt4SatNed,
            akt4UkupnoSat,
            akt4UkupnoProc,
            akt5Opis,
            akt5SatPon,
            akt5SatUto,
            akt5SatSre,
            akt5SatCet,
            akt5SatPet,
            akt5SatSub,
            akt5SatNed,
            akt5UkupnoSat,
            akt5UkupnoProc,
            akt6Opis,
            akt6SatPon,
            akt6SatUto,
            akt6SatSre,
            akt6SatCet,
            akt6SatPet,
            akt6SatSub,
            akt6SatNed,
            akt6UkupnoSat,
            akt6UkupnoProc,
            ukupnoUSatima,
            ukupnoUProcentima;

        public UpravljanjeVremenom()
        {
            connectionString =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;
        }

        public string KorisnikId
        {
            get { return korisnikId; }
            set { korisnikId = value; }
        }

        public string Akt1Opis
        {
            get {return akt1Opis;}
            set {akt1Opis = value;}
        }

        public string Akt1SatPon
        {
            get {return akt1SatPon;}
            set {akt1SatPon = value;}
        }

        public string Akt1SatUto
        {
            get {return akt1SatUto;}
            set {akt1SatUto = value;}
        }

        public string Akt1SatSre
        {
            get {return akt1SatSre;}
            set {akt1SatSre = value;}
        }

        public string Akt1SatCet
        {
            get {return akt1SatCet;}
            set {akt1SatCet = value;}
        }

        public string Akt1SatPet
        {
            get {return akt1SatPet;}
            set {akt1SatPet = value;}
        }

        public string Akt1SatSub
        {
            get {return akt1SatSub;}
            set {akt1SatSub = value;}
        }

        public string Akt1SatNed
        {
            get {return akt1SatNed;}
            set {akt1SatNed = value;}
        }

        public string Akt1UkupnoSat
        {
            get {return akt1UkupnoSat;}
            set {akt1UkupnoSat = value;}
        }

        public string Akt1UkupnoProc
        {
            get {return akt1UkupnoProc;}
            set {akt1UkupnoProc = value;}
        }

        public string Akt2Opis
        {
            get {return akt2Opis;}
            set {akt2Opis = value;}
        }

        public string Akt2SatPon
        {
            get {return akt2SatPon;}
            set {akt2SatPon = value;}
        }

        public string Akt2SatUto
        {
            get {return akt2SatUto;}
            set {akt2SatUto = value;}
        }

        public string Akt2SatSre
        {
            get {return akt2SatSre;}
            set {akt2SatSre = value;}
        }

        public string Akt2SatCet
        {
            get {return akt2SatCet;}
            set {akt2SatCet = value;}
        }

        public string Akt2SatPet
        {
            get {return akt2SatPet;}
            set {akt2SatPet = value;}
        }

        public string Akt2SatSub
        {
            get {return akt2SatSub;}
            set {akt2SatSub = value;}
        }

        public string Akt2SatNed
        {
            get {return akt2SatNed;}
            set {akt2SatNed = value;}
        }

        public string Akt2UkupnoSat
        {
            get {return akt2UkupnoSat;}
            set {akt2UkupnoSat = value;}
        }

        public string Akt2UkupnoProc
        {
            get {return akt2UkupnoProc;}
            set {akt2UkupnoProc = value;}
        }

        public string Akt3Opis
        {
            get {return akt3Opis;}
            set {akt3Opis = value;}
        }

        public string Akt3SatPon
        {
            get {return akt3SatPon;}
            set {akt3SatPon = value;}
        }

        public string Akt3SatUto
        {
            get {return akt3SatUto;}
            set {akt3SatUto = value;}
        }

        public string Akt3SatSre
        {
            get {return akt3SatSre;}
            set {akt3SatSre = value;}
        }

        public string Akt3SatCet
        {
            get {return akt3SatCet;}
            set {akt3SatCet = value;}
        }

        public string Akt3SatPet
        {
            get {return akt3SatPet;}
            set {akt3SatPet = value;}
        }

        public string Akt3SatSub
        {
            get {return akt3SatSub;}
            set {akt3SatSub = value;}
        }

        public string Akt3SatNed
        {
            get {return akt3SatNed;}
            set {akt3SatNed = value;}
        }

        public string Akt3UkupnoSat
        {
            get {return akt3UkupnoSat;}
            set {akt3UkupnoSat = value;}
        }

        public string Akt3UkupnoProc
        {
            get {return akt3UkupnoProc;}
            set {akt3UkupnoProc = value;}
        }

        public string Akt4Opis
        {
            get {return akt4Opis;}
            set {akt4Opis = value;}
        }

        public string Akt4SatPon
        {
            get {return akt4SatPon;}
            set {akt4SatPon = value;}
        }

        public string Akt4SatUto
        {
            get {return akt4SatUto;}
            set {akt4SatUto = value;}
        }

        public string Akt4SatSre
        {
            get {return akt4SatSre;}
            set {akt4SatSre = value;}
        }

        public string Akt4SatCet
        {
            get {return akt4SatCet;}
            set {akt4SatCet = value;}
        }

        public string Akt4SatPet
        {
            get {return akt4SatPet;}
            set {akt4SatPet = value;}
        }

        public string Akt4SatSub
        {
            get {return akt4SatSub;}
            set {akt4SatSub = value;}
        }

        public string Akt4SatNed
        {
            get {return akt4SatNed;}
            set {akt4SatNed = value;}
        }

        public string Akt4UkupnoSat
        {
            get {return akt4UkupnoSat;}
            set {akt4UkupnoSat = value;}
        }

        public string Akt4UkupnoProc
        {
            get {return akt4UkupnoProc;}
            set {akt4UkupnoProc = value;}
        }

        public string Akt5Opis
        {
            get {return akt5Opis;}
            set {akt5Opis = value;}
        }

        public string Akt5SatPon
        {
            get {return akt5SatPon;}
            set {akt5SatPon = value;}
        }

        public string Akt5SatUto
        {
            get {return akt5SatUto;}
            set {akt5SatUto = value;}
        }

        public string Akt5SatSre
        {
            get {return akt5SatSre;}
            set {akt5SatSre = value;}
        }

        public string Akt5SatCet
        {
            get {return akt5SatCet;}
            set {akt5SatCet = value;}
        }

        public string Akt5SatPet
        {
            get {return akt5SatPet;}
            set {akt5SatPet = value;}
        }

        public string Akt5SatSub
        {
            get {return akt5SatSub;}
            set {akt5SatSub = value;}
        }

        public string Akt5SatNed
        {
            get {return akt5SatNed;}
            set {akt5SatNed = value;}
        }

        public string Akt5UkupnoSat
        {
            get {return akt5UkupnoSat;}
            set {akt5UkupnoSat = value;}
        }

        public string Akt5UkupnoProc
        {
            get {return akt5UkupnoProc;}
            set {akt5UkupnoProc = value;}
        }

        public string Akt6Opis
        {
            get {return akt6Opis;}
            set {akt6Opis = value;}
        }

        public string Akt6SatPon
        {
            get {return akt6SatPon;}
            set {akt6SatPon = value;}
        }

        public string Akt6SatUto
        {
            get {return akt6SatUto;}
            set {akt6SatUto = value;}
        }

        public string Akt6SatSre
        {
            get {return akt6SatSre;}
            set {akt6SatSre = value;}
        }

        public string Akt6SatCet
        {
            get {return akt6SatCet;}
            set {akt6SatCet = value;}
        }

        public string Akt6SatPet
        {
            get {return akt6SatPet;}
            set {akt6SatPet = value;}
        }

        public string Akt6SatSub
        {
            get {return akt6SatSub;}
            set {akt6SatSub = value;}
        }

        public string Akt6SatNed
        {
            get {return akt6SatNed;}
            set {akt6SatNed = value;}
        }

        public string Akt6UkupnoSat
        {
            get {return akt6UkupnoSat;}
            set {akt6UkupnoSat = value;}
        }

        public string Akt6UkupnoProc
        {
            get {return akt6UkupnoProc;}
            set {akt6UkupnoProc = value;}
        }

        public string UkupnoUSatima
        {
            get {return ukupnoUSatima;}
            set {ukupnoUSatima = value;}
        }

        public string UkupnoUProcentima
        {
            get {return ukupnoUProcentima;}
            set {ukupnoUProcentima = value;}
        }

        public void SnimiPodatke_TabelaTabelaUpravljanjeVremenom(
            string akt1_opis,
            string akt1_sat_pon,
            string akt1_sat_uto,
            string akt1_sat_sre,
            string akt1_sat_cet,
            string akt1_sat_pet,
            string akt1_sat_sub,
            string akt1_sat_ned,
            string akt1_ukupno_sat,
            string akt1_ukupno_proc,
            string akt2_opis,
            string akt2_sat_pon,
            string akt2_sat_uto,
            string akt2_sat_sre,
            string akt2_sat_cet,
            string akt2_sat_pet,
            string akt2_sat_sub,
            string akt2_sat_ned,
            string akt2_ukupno_sat,
            string akt2_ukupno_proc,
            string akt3_opis,
            string akt3_sat_pon,
            string akt3_sat_uto,
            string akt3_sat_sre,
            string akt3_sat_cet,
            string akt3_sat_pet,
            string akt3_sat_sub,
            string akt3_sat_ned,
            string akt3_ukupno_sat,
            string akt3_ukupno_proc,
            string akt4_opis,
            string akt4_sat_pon,
            string akt4_sat_uto,
            string akt4_sat_sre,
            string akt4_sat_cet,
            string akt4_sat_pet,
            string akt4_sat_sub,
            string akt4_sat_ned,
            string akt4_ukupno_sat,
            string akt4_ukupno_proc,
            string akt5_opis,
            string akt5_sat_pon,
            string akt5_sat_uto,
            string akt5_sat_sre,
            string akt5_sat_cet,
            string akt5_sat_pet,
            string akt5_sat_sub,
            string akt5_sat_ned,
            string akt5_ukupno_sat,
            string akt5_ukupno_proc,
            string akt6_opis,
            string akt6_sat_pon,
            string akt6_sat_uto,
            string akt6_sat_sre,
            string akt6_sat_cet,
            string akt6_sat_pet,
            string akt6_sat_sub,
            string akt6_sat_ned,
            string akt6_ukupno_sat,
            string akt6_ukupno_proc,
            string ukupno_u_satima,
            string ukupno_u_procentima)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaUpravljanjeVremenom` SET ");
            sb.Append("`akt1_opis` = ?, `akt1_sat_pon` = ?, `akt1_sat_uto` = ?, ");
            sb.Append("`akt1_sat_sre` = ?, `akt1_sat_cet` = ?, `akt1_sat_pet` = ?, ");
            sb.Append("`akt1_sat_sub` = ?, `akt1_sat_ned` = ?, `akt1_ukupno_sat` = ?, ");
            sb.Append("`akt1_ukupno_proc` = ?, `akt2_opis` = ?, `akt2_sat_pon` = ?, ");
            sb.Append("`akt2_sat_uto` = ?, `akt2_sat_sre` = ?, `akt2_sat_cet` = ?, ");
            sb.Append("`akt2_sat_pet` = ?, `akt2_sat_sub` = ?, `akt2_sat_ned` = ?, ");
            sb.Append("`akt2_ukupno_sat` = ?, `akt2_ukupno_proc` = ?, `akt3_opis` = ?, ");
            sb.Append("`akt3_sat_pon` = ?, `akt3_sat_uto` = ?, `akt3_sat_sre` = ?, ");
            sb.Append("`akt3_sat_cet` = ?, `akt3_sat_pet` = ?, `akt3_sat_sub` = ?, ");
            sb.Append("`akt3_sat_ned` = ?, `akt3_ukupno_sat` = ?, `akt3_ukupno_proc` = ?, ");
            sb.Append("`akt4_opis` = ?, `akt4_sat_pon` = ?, `akt4_sat_uto` = ?, ");
            sb.Append("`akt4_sat_sre` = ?, `akt4_sat_cet` = ?, `akt4_sat_pet` = ?, ");
            sb.Append("`akt4_sat_sub` = ?, `akt4_sat_ned` = ?, `akt4_ukupno_sat` = ?, ");
            sb.Append("`akt4_ukupno_proc` = ?, `akt5_opis` = ?, `akt5_sat_pon` = ?, ");
            sb.Append("`akt5_sat_uto` = ?, `akt5_sat_sre` = ?, `akt5_sat_cet` = ?, ");
            sb.Append("`akt5_sat_pet` = ?, `akt5_sat_sub` = ?, `akt5_sat_ned` = ?, ");
            sb.Append("`akt5_ukupno_sat` = ?, `akt5_ukupno_proc` = ?, `akt6_opis` = ?, ");
            sb.Append("`akt6_sat_pon` = ?, `akt6_sat_uto` = ?, `akt6_sat_sre` = ?, ");
            sb.Append("`akt6_sat_cet` = ?, `akt6_sat_pet` = ?, `akt6_sat_sub` = ?, ");
            sb.Append("`akt6_sat_ned` = ?, `akt6_ukupno_sat` = ?, `akt6_ukupno_proc` = ?, ");
            sb.Append("`ukupno_u_satima` = ?, `ukupno_u_procentima` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;
            
            cmd.Parameters.AddWithValue("akt1_opis", akt1_opis);
            cmd.Parameters.AddWithValue("akt1_sat_pon", akt1_sat_pon);
            cmd.Parameters.AddWithValue("akt1_sat_uto", akt1_sat_uto);
            cmd.Parameters.AddWithValue("akt1_sat_sre", akt1_sat_sre);
            cmd.Parameters.AddWithValue("akt1_sat_cet", akt1_sat_cet);
            cmd.Parameters.AddWithValue("akt1_sat_pet", akt1_sat_pet);
            cmd.Parameters.AddWithValue("akt1_sat_sub", akt1_sat_sub);
            cmd.Parameters.AddWithValue("akt1_sat_ned", akt1_sat_ned);
            cmd.Parameters.AddWithValue("akt1_ukupno_sat", akt1_ukupno_sat);
            cmd.Parameters.AddWithValue("akt1_ukupno_proc", akt1_ukupno_proc);
            
            cmd.Parameters.AddWithValue("akt2_opis", akt2_opis);
            cmd.Parameters.AddWithValue("akt2_sat_pon", akt2_sat_pon);
            cmd.Parameters.AddWithValue("akt2_sat_uto", akt2_sat_uto);
            cmd.Parameters.AddWithValue("akt2_sat_sre", akt2_sat_sre);
            cmd.Parameters.AddWithValue("akt2_sat_cet", akt2_sat_cet);
            cmd.Parameters.AddWithValue("akt2_sat_pet", akt2_sat_pet);
            cmd.Parameters.AddWithValue("akt2_sat_sub", akt2_sat_sub);
            cmd.Parameters.AddWithValue("akt2_sat_ned", akt2_sat_ned);
            cmd.Parameters.AddWithValue("akt2_ukupno_sat", akt2_ukupno_sat);
            cmd.Parameters.AddWithValue("akt2_ukupno_proc", akt2_ukupno_proc);
            
            cmd.Parameters.AddWithValue("akt3_opis", akt3_opis);
            cmd.Parameters.AddWithValue("akt3_sat_pon", akt3_sat_pon);
            cmd.Parameters.AddWithValue("akt3_sat_uto", akt3_sat_uto);
            cmd.Parameters.AddWithValue("akt3_sat_sre", akt3_sat_sre);
            cmd.Parameters.AddWithValue("akt3_sat_cet", akt3_sat_cet);
            cmd.Parameters.AddWithValue("akt3_sat_pet", akt3_sat_pet);
            cmd.Parameters.AddWithValue("akt3_sat_sub", akt3_sat_sub);
            cmd.Parameters.AddWithValue("akt3_sat_ned", akt3_sat_ned);
            cmd.Parameters.AddWithValue("akt3_ukupno_sat", akt3_ukupno_sat);
            cmd.Parameters.AddWithValue("akt3_ukupno_proc", akt3_ukupno_proc);
            
            cmd.Parameters.AddWithValue("akt4_opis", akt4_opis);
            cmd.Parameters.AddWithValue("akt4_sat_pon", akt4_sat_pon);
            cmd.Parameters.AddWithValue("akt4_sat_uto", akt4_sat_uto);
            cmd.Parameters.AddWithValue("akt4_sat_sre", akt4_sat_sre);
            cmd.Parameters.AddWithValue("akt4_sat_cet", akt4_sat_cet);
            cmd.Parameters.AddWithValue("akt4_sat_pet", akt4_sat_pet);
            cmd.Parameters.AddWithValue("akt4_sat_sub", akt4_sat_sub);
            cmd.Parameters.AddWithValue("akt4_sat_ned", akt4_sat_ned);
            cmd.Parameters.AddWithValue("akt4_ukupno_sat", akt4_ukupno_sat);
            cmd.Parameters.AddWithValue("akt4_ukupno_proc", akt4_ukupno_proc);
            
            cmd.Parameters.AddWithValue("akt5_opis", akt5_opis);
            cmd.Parameters.AddWithValue("akt5_sat_pon", akt5_sat_pon);
            cmd.Parameters.AddWithValue("akt5_sat_uto", akt5_sat_uto);
            cmd.Parameters.AddWithValue("akt5_sat_sre", akt5_sat_sre);
            cmd.Parameters.AddWithValue("akt5_sat_cet", akt5_sat_cet);
            cmd.Parameters.AddWithValue("akt5_sat_pet", akt5_sat_pet);
            cmd.Parameters.AddWithValue("akt5_sat_sub", akt5_sat_sub);
            cmd.Parameters.AddWithValue("akt5_sat_ned", akt5_sat_ned);
            cmd.Parameters.AddWithValue("akt5_ukupno_sat", akt5_ukupno_sat);
            cmd.Parameters.AddWithValue("akt5_ukupno_proc", akt5_ukupno_proc);
            
            cmd.Parameters.AddWithValue("akt6_opis", akt6_opis);
            cmd.Parameters.AddWithValue("akt6_sat_pon", akt6_sat_pon);
            cmd.Parameters.AddWithValue("akt6_sat_uto", akt6_sat_uto);
            cmd.Parameters.AddWithValue("akt6_sat_sre", akt6_sat_sre);
            cmd.Parameters.AddWithValue("akt6_sat_cet", akt6_sat_cet);
            cmd.Parameters.AddWithValue("akt6_sat_pet", akt6_sat_pet);
            cmd.Parameters.AddWithValue("akt6_sat_sub", akt6_sat_sub);
            cmd.Parameters.AddWithValue("akt6_sat_ned", akt6_sat_ned);
            cmd.Parameters.AddWithValue("akt6_ukupno_sat", akt6_ukupno_sat);
            cmd.Parameters.AddWithValue("akt6_ukupno_proc", akt6_ukupno_proc);

            cmd.Parameters.AddWithValue("ukupno_u_satima", ukupno_u_satima);
            cmd.Parameters.AddWithValue("ukupno_u_procentima", ukupno_u_procentima);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }
    }
}

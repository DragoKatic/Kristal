﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.OleDb;
using System.Web.Configuration;

namespace KristalBiblioteka
{
    public class PoslovniOglasi
    {
        private string
            connectionString,
            korisnikId,
            naziv,
            radnoMesto,
            mesto,
            opstina,
            kategorija,
            minStepenObrazovanja,
            maxStepenObrazovanja,
            oglas,
            obavestenje,
            eMail,
            webSite;

        public PoslovniOglasi()
        {
            connectionString =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;
        }

        public string KorisnikId
        {
            get { return korisnikId; }
            set { korisnikId = value; }
        }

        public string Naziv
        {
            get {return naziv;}
            set {naziv = value;}
        }

        public string RadnoMesto
        {
            get {return radnoMesto;}
            set {radnoMesto = value;}
        }

        public string Mesto
        {
            get {return mesto;}
            set {mesto = value;}
        }

        public string Opstina
        {
            get {return opstina;}
            set {opstina = value;}
        }

        public string Kategorija
        {
            get {return kategorija;}
            set {kategorija = value;}
        }

        public string MinStepenObrazovanja
        {
            get {return minStepenObrazovanja;}
            set {minStepenObrazovanja = value;}
        }

        public string MaxStepenObrazovanja
        {
            get {return maxStepenObrazovanja;}
            set {maxStepenObrazovanja = value;}
        }

        public string Oglas
        {
            get {return oglas;}
            set {oglas = value;}
        }

        public string Obavestenje
        {
            get {return obavestenje;}
            set {obavestenje = value;}
        }

        public string EMail
        {
            get {return eMail;}
            set {eMail = value;}
        }

        public string WebSite
        {
            get {return webSite;}
            set {webSite = value;}
        }

        public void SnimiPodatke_TabelaPoslovniOglas(
            string naziv,
            string radno_mesto,
            string mesto,
            string opstina,
            string kategorija,
            string min_stepen_obrazovanja,
            string max_stepen_obrazovanja,
            string oglas,
            string obavestenje,
            string e_mail,
            string web_site)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaPoslovniOglas` SET ");
            sb.Append("`naziv` = ?, `radno_mesto` = ?, `mesto` = ?, `opstina` = ?, ");
            sb.Append("`kategorija` = ?, `min_stepen_obrazovanja` = ?, ");
            sb.Append("`max_stepen_obrazovanja` = ?, `oglas` = ?, ");
            sb.Append("`obavestenje` = ?, `e_mail` = ?, `web_site` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.AddWithValue("naziv", naziv);
            cmd.Parameters.AddWithValue("radno_mesto", radno_mesto);
            cmd.Parameters.AddWithValue("mesto", mesto);
            cmd.Parameters.AddWithValue("opstina", opstina);
            cmd.Parameters.AddWithValue("kategorija", kategorija);
            cmd.Parameters.AddWithValue("min_stepen_obrazovanja", min_stepen_obrazovanja);
            cmd.Parameters.AddWithValue("max_stepen_obrazovanja", max_stepen_obrazovanja);
            cmd.Parameters.AddWithValue("oglas", oglas);
            cmd.Parameters.AddWithValue("obavestenje", obavestenje);
            cmd.Parameters.AddWithValue("e_mail", e_mail);
            cmd.Parameters.AddWithValue("web_site", web_site);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }
    }
}

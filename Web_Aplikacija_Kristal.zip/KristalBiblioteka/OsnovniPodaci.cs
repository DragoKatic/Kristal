﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.OleDb;
using System.Web.Configuration;

namespace KristalBiblioteka
{
    public class OsnovniPodaci
    {
        private string
            connectionString,
            korisnikId,
            ime,
            prezime,
            pol,
            datumRodjenja,
            drzavljanstvo,
            bracnoStanje,
            adresa,
            postanskiBroj,
            grad,
            opstina,
            drzava,
            kucniTelefon,
            mobilniTelefon,
            webSite;

        public OsnovniPodaci()
        {
            connectionString =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;
        }

        public string KorisnikId
        {
            get { return korisnikId; }
            set { korisnikId = value; }
        }

        public string Ime
        {
            get { return ime; }
            set { ime = value; }
        }

        public string Prezime
        {
            get { return prezime; }
            set { prezime = value; }
        }

        public string Pol
        {
            get { return pol; }
            set { pol = value; }
        }

        public string DatumRodjenja
        {
            get { return datumRodjenja; }
            set { datumRodjenja = value; }
        }

        public string Drzavljanstvo
        {
            get { return drzavljanstvo; }
            set { drzavljanstvo = value; }
        }

        public string BracnoStanje
        {
            get { return bracnoStanje; }
            set { bracnoStanje = value; }
        }

        public string Adresa
        {
            get { return adresa; }
            set { adresa = value; }
        }

        public string PostanskiBroj
        {
            get { return postanskiBroj; }
            set { postanskiBroj = value; }
        }

        public string Grad
        {
            get { return grad; }
            set { grad = value; }
        }

        public string Opstina
        {
            get { return opstina; }
            set { opstina = value; }
        }

        public string Drzava
        {
            get { return drzava; }
            set { drzava = value; }
        }

        public string KucniTelefon
        {
            get { return kucniTelefon; }
            set { kucniTelefon = value; }
        }

        public string MobilniTelefon
        {
            get { return mobilniTelefon; }
            set { mobilniTelefon = value; }
        }

        public string WebSite
        {
            get { return webSite; }
            set { webSite = value; }
        }

        public void SnimiPodatke_TabelaOsnovniPodaci(
            string ime,
            string prezime,
            string pol,
            string datum_rodjenja,
            string drzavljanstvo,
            string bracno_stanje,
            string adresa,
            string postanski_broj,
            string grad,
            string opstina,
            string drzava,
            string kucni_telefon,
            string mobilni_telefon,
            string web_site)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaOsnovniPodaci` SET ");
            sb.Append("`ime` = ?, `prezime` = ?, `pol` = ?, `datum_rodjenja` = ?, ");
            sb.Append("`drzavljanstvo` = ?, `bracno_stanje` = ?, `adresa` = ?, ");
            sb.Append("`postanski_broj` = ?, `grad` = ?, `opstina` = ?, ");
            sb.Append("`drzava` = ?, `kucni_telefon` = ?, `mobilni_telefon` = ?, ");
            sb.Append("`web_site` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.AddWithValue("ime", ime);
            cmd.Parameters.AddWithValue("prezime", prezime);
            cmd.Parameters.AddWithValue("pol", pol);
            cmd.Parameters.AddWithValue("datum_rodjenja", datum_rodjenja);
            cmd.Parameters.AddWithValue("drzavljanstvo", drzavljanstvo);
            cmd.Parameters.AddWithValue("bracno_stanje", bracno_stanje);
            cmd.Parameters.AddWithValue("adresa", adresa);
            cmd.Parameters.AddWithValue("postanski_broj", postanski_broj);
            cmd.Parameters.AddWithValue("grad", grad);
            cmd.Parameters.AddWithValue("opstina", opstina);
            cmd.Parameters.AddWithValue("drzava", drzava);
            cmd.Parameters.AddWithValue("kucni_telefon", kucni_telefon);
            cmd.Parameters.AddWithValue("mobilni_telefon", mobilni_telefon);
            cmd.Parameters.AddWithValue("web_site", web_site);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }
    }
}

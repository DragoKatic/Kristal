﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.OleDb;
using System.Web.Configuration;

namespace KristalBiblioteka
{
    public class OpstaInteresovanja
    {
        private string
            connectionString,
            korisnikId,
            winOcena,
            winGodine,
            winOpis,
            linuxOcena,
            linuxGodine,
            linuxOpis,
            officeOcena,
            officeGodine,
            officeOpis,
            omiljeniOs,
            omiljenaArhitektura,
            hobi,
            posaoUSlobodnoVreme,
            ekspertiza,
            oblastiKojeVolite,
            ponosIPosao,
            aktivnostiProjekti;

        public OpstaInteresovanja()
        {
            connectionString =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;
        }

        public string KorisnikId
        {
            get { return korisnikId; }
            set { korisnikId = value; }
        }

        public string WinOcena
        {
            get {return winOcena;}
            set {winOcena = value;}
        }

        public string WinGodine
        {
            get {return winGodine;}
            set {winGodine = value;}
        }

        public string WinOpis
        {
            get {return winOpis;}
            set {winOpis = value;}
        }

        public string LinuxOcena
        {
            get {return linuxOcena;}
            set {linuxOcena = value;}
        }

        public string LinuxGodine
        {
            get {return linuxGodine;}
            set {linuxGodine = value;}
        }

        public string LinuxOpis
        {
            get {return linuxOpis;}
            set {linuxOpis = value;}
        }

        public string OfficeOcena
        {
            get {return officeOcena;}
            set {officeOcena = value;}
        }

        public string OfficeGodine
        {
            get {return officeGodine;}
            set {officeGodine = value;}
        }

        public string OfficeOpis
        {
            get {return officeOpis;}
            set {officeOpis = value;}
        }

        public string OmiljeniOs
        {
            get {return omiljeniOs;}
            set {omiljeniOs = value;}
        }

        public string OmiljenaArhitektura
        {
            get {return omiljenaArhitektura;}
            set {omiljenaArhitektura = value;}
        }

        public string Hobi
        {
            get {return hobi;}
            set {hobi = value;}
        }

        public string PosaoUSlobodnoVreme
        {
            get {return posaoUSlobodnoVreme;}
            set {posaoUSlobodnoVreme = value;}
        }

        public string Ekspertiza
        {
            get {return ekspertiza;}
            set {ekspertiza = value;}
        }

        public string OblastiKojeVolite
        {
            get {return oblastiKojeVolite;}
            set {oblastiKojeVolite = value;}
        }

        public string PonosIPosao
        {
            get {return ponosIPosao;}
            set {ponosIPosao = value;}
        }

        public string AktivnostiProjekti
        {
            get { return aktivnostiProjekti; }
            set { aktivnostiProjekti = value; }
        }

        public void SnimiPodatke_TabelaOpstaInteresovanja(
            string win_ocena,
            string win_godine,
            string win_opis,
            string linux_ocena,
            string linux_godine,
            string linux_opis,
            string office_ocena,
            string office_godine,
            string office_opis,
            string omiljeni_os,
            string omiljena_arhitektura,
            string hobi,
            string posao_u_slobodno_vreme,
            string ekspertiza,
            string oblasti_koje_volite,
            string ponos_i_posao,
            string aktivnosti_projekti)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaOpstaInteresovanja` SET ");
            sb.Append("`win_ocena` = ?, `win_godine` = ?, `win_opis` = ?, ");
            sb.Append("`linux_ocena` = ?, `linux_godine` = ?, `linux_opis` = ?, ");
            sb.Append("`office_ocena` = ?, `office_godine` = ?, `office_opis` = ?, ");
            sb.Append("`omiljeni_os` = ?, `omiljena_arhitektura` = ?, `hobi` = ?, ");
            sb.Append("`posao_u_slobodno_vreme` = ?, `ekspertiza` = ?, ");
            sb.Append("`oblasti_koje_volite` = ?, `ponos_i_posao` = ?, ");
            sb.Append("`aktivnosti_projekti` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.AddWithValue("win_ocena", win_ocena);
            cmd.Parameters.AddWithValue("win_godine", win_godine);
            cmd.Parameters.AddWithValue("win_opis", win_opis);
            cmd.Parameters.AddWithValue("linux_ocena", linux_ocena);
            cmd.Parameters.AddWithValue("linux_godine", linux_godine);
            cmd.Parameters.AddWithValue("linux_opis", linux_opis);
            cmd.Parameters.AddWithValue("office_ocena", office_ocena);
            cmd.Parameters.AddWithValue("office_godine", office_godine);
            cmd.Parameters.AddWithValue("office_opis", office_opis);
            cmd.Parameters.AddWithValue("omiljeni_os", omiljeni_os);
            cmd.Parameters.AddWithValue("omiljena_arhitektura", omiljena_arhitektura);
            cmd.Parameters.AddWithValue("hobi", hobi);
            cmd.Parameters.AddWithValue("posao_u_slobodno_vreme", posao_u_slobodno_vreme);
            cmd.Parameters.AddWithValue("ekspertiza", ekspertiza);
            cmd.Parameters.AddWithValue("oblasti_koje_volite", oblasti_koje_volite);
            cmd.Parameters.AddWithValue("ponos_i_posao", ponos_i_posao);
            cmd.Parameters.AddWithValue("aktivnosti_projekti", aktivnosti_projekti);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }
    }
}

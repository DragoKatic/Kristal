﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.OleDb;
using System.Web.Configuration;

namespace KristalBiblioteka
{
    public class Swot
    {
        private string
            connectionString,
            korisnikId,
            pretnja1,
            pretnja2,
            pretnja3,
            pretnja4,
            pretnja5,
            pretnja6,
            sansa1,
            sansa2,
            sansa3,
            sansa4,
            sansa5,
            sansa6,
            slabost1,
            slabost2,
            slabost3,
            slabost4,
            slabost5,
            slabost6,
            snaga1,
            snaga2,
            snaga3,
            snaga4,
            snaga5,
            snaga6;

        public Swot()
        {
            connectionString =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;
        }

        public string KorisnikId
        {
            get {return korisnikId;}
            set {korisnikId = value;}
        }

        public string Pretnja1
        {
            get {return pretnja1;}
            set {pretnja1 = value;}
        }

        public string Pretnja2
        {
            get {return pretnja2;}
            set {pretnja2 = value;}
        }

        public string Pretnja3
        {
            get {return pretnja3;}
            set {pretnja3 = value;}
        }
        
        public string Pretnja4
        {
            get {return pretnja4;}
            set {pretnja4 = value;}
        }

        public string Pretnja5
        {
            get {return pretnja5;}
            set {pretnja5 = value;}
        }

        public string Pretnja6
        {
            get {return pretnja6;}
            set {pretnja6 = value;}
        }

        public string Sansa1
        {
            get {return sansa1;}
            set {sansa1 = value;}
        }

        public string Sansa2
        {
            get {return sansa2;}
            set {sansa2 = value;}
        }

        public string Sansa3
        {
            get {return sansa3;}
            set {sansa3 = value;}
        }

        public string Sansa4
        {
            get {return sansa4;}
            set {sansa4 = value;}
        }

        public string Sansa5
        {
            get {return sansa5;}
            set {sansa5 = value;}
        }

        public string Sansa6
        {
            get {return sansa6;}
            set {sansa6 = value;}
        }

        public string Slabost1
        {
            get {return slabost1;}
            set {slabost1 = value;}
        }

        public string Slabost2
        {
            get {return slabost2;}
            set {slabost2 = value;}
        }

        public string Slabost3
        {
            get {return slabost3;}
            set {slabost3 = value;}
        }

        public string Slabost4
        {
            get {return slabost4;}
            set {slabost4 = value;}
        }

        public string Slabost5
        {
            get {return slabost5;}
            set {slabost5 = value;}
        }

        public string Slabost6
        {
            get {return slabost6;}
            set {slabost6 = value;}
        }

        public string Snaga1
        {
            get {return snaga1;}
            set {snaga1 = value;}
        }

        public string Snaga2
        {
            get {return snaga2;}
            set {snaga2 = value;}
        }

        public string Snaga3
        {
            get {return snaga3;}
            set {snaga3 = value;}
        }

        public string Snaga4
        {
            get {return snaga4;}
            set {snaga4 = value;}
        }

        public string Snaga5
        {
            get {return snaga5;}
            set {snaga5 = value;}
        }

        public string Snaga6
        {
            get {return snaga6;}
            set {snaga6 = value;}
        }

        public void SnimiPodatke_TabelaPretnje(
            string pretnja_1,
            string pretnja_2,
            string pretnja_3,
            string pretnja_4,
            string pretnja_5,
            string pretnja_6)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaPretnje` SET `pretnja_1` = ?, ");
            sb.Append("`pretnja_2` = ?, `pretnja_3` = ?, `pretnja_4` = ?, ");
            sb.Append("`pretnja_5` = ?, `pretnja_6` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;
            
            cmd.Parameters.AddWithValue("pretnja_1", pretnja_1);
            cmd.Parameters.AddWithValue("pretnja_2", pretnja_2);
            cmd.Parameters.AddWithValue("pretnja_3", pretnja_3);
            cmd.Parameters.AddWithValue("pretnja_4", pretnja_4);
            cmd.Parameters.AddWithValue("pretnja_5", pretnja_5);
            cmd.Parameters.AddWithValue("pretnja_6", pretnja_6);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch(Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void SnimiPodatke_TabelaSanse(
            string sansa_1,
            string sansa_2,
            string sansa_3,
            string sansa_4,
            string sansa_5,
            string sansa_6)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaSanse` SET `sansa_1` = ?, ");
            sb.Append("`sansa_2` = ?, `sansa_3` = ?, `sansa_4` = ?, ");
            sb.Append("`sansa_5` = ?, `sansa_6` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;
            
            cmd.Parameters.AddWithValue("sansa_1", sansa_1);
            cmd.Parameters.AddWithValue("sansa_2", sansa_2);
            cmd.Parameters.AddWithValue("sansa_3", sansa_3);
            cmd.Parameters.AddWithValue("sansa_4", sansa_4);
            cmd.Parameters.AddWithValue("sansa_5", sansa_5);
            cmd.Parameters.AddWithValue("sansa_6", sansa_6);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void SnimiPodatke_TabelaSlabosti(
            string slabost_1,
            string slabost_2,
            string slabost_3,
            string slabost_4,
            string slabost_5,
            string slabost_6)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaSlabosti` SET `slabost_1` = ?, ");
            sb.Append("`slabost_2` = ?, `slabost_3` = ?, ");
            sb.Append("`slabost_4` = ?, `slabost_5` = ?, `slabost_6` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;
            
            cmd.Parameters.AddWithValue("slabost_1", slabost_1);
            cmd.Parameters.AddWithValue("slabost_2", slabost_2);
            cmd.Parameters.AddWithValue("slabost_3", slabost_3);
            cmd.Parameters.AddWithValue("slabost_4", slabost_4);
            cmd.Parameters.AddWithValue("slabost_5", slabost_5);
            cmd.Parameters.AddWithValue("slabost_6", slabost_6);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void SnimiPodatke_TabelaSnage(
            string snaga_1,
            string snaga_2,
            string snaga_3,
            string snaga_4,
            string snaga_5,
            string snaga_6)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaSnage` SET `snaga_1` = ?, ");
            sb.Append("`snaga_2` = ?, `snaga_3` = ?, `snaga_4` = ?, ");
            sb.Append("`snaga_5` = ?, `snaga_6` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;
            
            cmd.Parameters.AddWithValue("snaga_1", snaga_1);
            cmd.Parameters.AddWithValue("snaga_2", snaga_2);
            cmd.Parameters.AddWithValue("snaga_3", snaga_3);
            cmd.Parameters.AddWithValue("snaga_4", snaga_4);
            cmd.Parameters.AddWithValue("snaga_5", snaga_5);
            cmd.Parameters.AddWithValue("snaga_6", snaga_6);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }
    }
}

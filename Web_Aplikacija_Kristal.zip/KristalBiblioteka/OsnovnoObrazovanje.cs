﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.OleDb;
using System.Web.Configuration;

namespace KristalBiblioteka
{
    public class OsnovnoObrazovanje
    {
        private string
            connectionString,
            korisnikId,
            vozackaDozvola,
            engleskiJezikNivo,
            francuskiJezikNivo,
            nemackiJezikNivo,
            italijanskiJezikNivo,
            ruskiJezikNivo,
            drugiJezik,
            drugiJezikNivo,
            stepenSkolovanja,
            nazivSkole,
            smerStudija,
            godinaZavrsetkaSkole,
            oblastMagistrature,
            oblastDoktorata,
            specijalistickaZnanja,
            drugaObrazovanja,
            promeneUPoslu,
            knjigeOPoslu,
            standardiUPoslu;

        public OsnovnoObrazovanje()
        {
            connectionString =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;
        }

        public string KorisnikId
        {
            get { return korisnikId; }
            set { korisnikId = value; }
        }

        public string VozackaDozvola
        {
            get { return vozackaDozvola; }
            set { vozackaDozvola = value; }
        }

        public string EngleskiJezikNivo
        {
            get { return engleskiJezikNivo; }
            set { engleskiJezikNivo = value; }
        }

        public string FrancuskiJezikNivo
        {
            get { return francuskiJezikNivo; }
            set { francuskiJezikNivo = value; }
        }

        public string NemackiJezikNivo
        {
            get { return nemackiJezikNivo; }
            set { nemackiJezikNivo = value; }
        }

        public string ItalijanskiJezikNivo
        {
            get { return italijanskiJezikNivo; }
            set { italijanskiJezikNivo = value; }
        }

        public string RuskiJezikNivo
        {
            get { return ruskiJezikNivo; }
            set { ruskiJezikNivo = value; }
        }

        public string DrugiJezik
        {
            get { return drugiJezik; }
            set { drugiJezik = value; }
        }

        public string DrugiJezikNivo
        {
            get { return drugiJezikNivo; }
            set { drugiJezikNivo = value; }
        }

        public string StepenSkolovanja
        {
            get { return stepenSkolovanja; }
            set { stepenSkolovanja = value; }
        }

        public string NazivSkole
        {
            get { return nazivSkole; }
            set { nazivSkole = value; }
        }

        public string SmerStudija
        {
            get { return smerStudija; }
            set { smerStudija = value; }
        }

        public string GodinaZavrsetkaSkole
        {
            get { return godinaZavrsetkaSkole; }
            set { godinaZavrsetkaSkole = value; }
        }

        public string OblastMagistrature
        {
            get { return oblastMagistrature; }
            set { oblastMagistrature = value; }
        }

        public string OblastDoktorata
        {
            get { return oblastDoktorata; }
            set { oblastDoktorata = value; }
        }

        public string SpecijalistickaZnanja
        {
            get { return specijalistickaZnanja; }
            set { specijalistickaZnanja = value; }
        }

        public string DrugaObrazovanja
        {
            get { return drugaObrazovanja; }
            set { drugaObrazovanja = value; }
        }

        public string PromeneUPoslu
        {
            get { return promeneUPoslu; }
            set { promeneUPoslu = value; }
        }

        public string KnjigeOPoslu
        {
            get { return knjigeOPoslu; }
            set { knjigeOPoslu = value; }
        }

        public string StandardiUPoslu
        {
            get { return standardiUPoslu; }
            set { standardiUPoslu = value; }
        }

        public void SnimiPodatke_TabelaOsnovnoObrazovanje(
            string vozacka_dozvola,
            string engleski_jezik_nivo,
            string francuski_jezik_nivo,
            string nemacki_jezik_nivo,
            string italijanski_jezik_nivo,
            string ruski_jezik_nivo,
            string drugi_jezik,
            string drugi_jezik_nivo,
            string stepen_skolovanja,
            string naziv_skole,
            string smer_studija,
            string godina_zavrsetka_skole,
            string oblast_magistrature,
            string oblast_doktorata,
            string specijalisticka_znanja,
            string druga_obrazovanja,
            string promene_u_poslu,
            string knjige_o_poslu,
            string standardi_u_poslu)
        {
            OleDbConnection con = new OleDbConnection(connectionString);

            string greska = "";
            string update = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("UPDATE `TabelaOsnovnoObrazovanje` SET ");
            sb.Append("`vozacka_dozvola` = ?, ");
            sb.Append("`engleski_jezik_nivo` = ?, ");
            sb.Append("`francuski_jezik_nivo` = ?, ");
            sb.Append("`nemacki_jezik_nivo` = ?, ");
            sb.Append("`italijanski_jezik_nivo` = ?, ");
            sb.Append("`ruski_jezik_nivo` = ?, ");
            sb.Append("`drugi_jezik` = ?, ");
            sb.Append("`drugi_jezik_nivo` = ?, ");
            sb.Append("`stepen_skolovanja` = ?, ");
            sb.Append("`naziv_skole` = ?, ");
            sb.Append("`smer_studija` = ?, ");
            sb.Append("`godina_zavrsetka_skole` = ?, ");
            sb.Append("`oblast_magistrature` = ?, ");
            sb.Append("`oblast_doktorata` = ?, ");
            sb.Append("`specijalisticka_znanja` = ?, ");
            sb.Append("`druga_obrazovanja` = ?, ");
            sb.Append("`promene_u_poslu` = ?, ");
            sb.Append("`knjige_o_poslu` = ?, ");
            sb.Append("`standardi_u_poslu` = ? ");
            sb.Append("WHERE `korisnik_id` = ?");

            update += sb.ToString();

            KorisnickiPodaci noviKorisnik = new KorisnickiPodaci();
            string korisnik_id = noviKorisnik.ObezbediKorisnickiKljuc();

            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.AddWithValue("vozacka_dozvola", vozacka_dozvola);
            cmd.Parameters.AddWithValue("engleski_jezik_nivo", engleski_jezik_nivo);
            cmd.Parameters.AddWithValue("francuski_jezik_nivo", francuski_jezik_nivo);
            cmd.Parameters.AddWithValue("nemacki_jezik_nivo", nemacki_jezik_nivo);
            cmd.Parameters.AddWithValue("italijanski_jezik_nivo", italijanski_jezik_nivo);
            cmd.Parameters.AddWithValue("ruski_jezik_nivo", ruski_jezik_nivo);
            cmd.Parameters.AddWithValue("drugi_jezik", drugi_jezik);
            cmd.Parameters.AddWithValue("drugi_jezik_nivo", drugi_jezik_nivo);
            cmd.Parameters.AddWithValue("stepen_skolovanja", stepen_skolovanja);
            cmd.Parameters.AddWithValue("naziv_skole", naziv_skole);
            cmd.Parameters.AddWithValue("smer_studija", smer_studija);
            cmd.Parameters.AddWithValue("godina_zavrsetka_skole", godina_zavrsetka_skole);
            cmd.Parameters.AddWithValue("oblast_magistrature", oblast_magistrature);
            cmd.Parameters.AddWithValue("oblast_doktorata", oblast_doktorata);
            cmd.Parameters.AddWithValue("specijalisticka_znanja", specijalisticka_znanja);
            cmd.Parameters.AddWithValue("druga_obrazovanja", druga_obrazovanja);
            cmd.Parameters.AddWithValue("promene_u_poslu", promene_u_poslu);
            cmd.Parameters.AddWithValue("knjige_o_poslu", knjige_o_poslu);
            cmd.Parameters.AddWithValue("standardi_u_poslu", standardi_u_poslu);
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }
    }
}

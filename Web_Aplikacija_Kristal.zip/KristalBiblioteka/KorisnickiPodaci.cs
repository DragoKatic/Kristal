﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Web.Configuration;
using System.Web.Security;

namespace KristalBiblioteka
{
    public class KorisnickiPodaci
    {
        private string 
            korisnikId,
            connectionStringAspnetDb,
            connectionStringKristal;

        public KorisnickiPodaci()
        {
            connectionStringAspnetDb = 
                WebConfigurationManager.ConnectionStrings[
                "AspnetDbKonekcija"].ConnectionString;

            connectionStringKristal =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;
        }

        public string KorisnikId
        {
            get { return korisnikId; }
            set { korisnikId = value; }
        }

        public void Rezervisi(string korisnik_id)
        {
            RezervisiTabelaID(korisnik_id);
            RezervisiTabelaCiljevi(korisnik_id);
            RezervisiTabelaFotografije(korisnik_id);
            RezervisiTabelaMisije(korisnik_id);
            RezervisiTabelaOsnovniPodaci(korisnik_id);
            RezervisiTabelaOsnovnoObrazovanje(korisnik_id);
            RezervisiTabelaPretnje(korisnik_id);
            RezervisiTabelaRazvojnePotrebe(korisnik_id);
            RezervisiTabelaSanse(korisnik_id);
            RezervisiTabelaSlabosti(korisnik_id);
            RezervisiTabelaSnage(korisnik_id);
            RezervisiTabelaTrenutnoStanje(korisnik_id);
            RezervisiTabelaVrednovanjeOstvarenja(korisnik_id);
            RezervisiTabelaKredibilitet(korisnik_id);
            RezervisiTabelaOpstaInteresovanja(korisnik_id);
            RezervisiTabelaUpravljanjeVremenom(korisnik_id);
            RezervisiTabelaSamoaktualizacija(korisnik_id);
            RezervisiTabelaPreduzeca(korisnik_id);
            RezervisiTabelaPoslovniOglas(korisnik_id);
        }

        public void RezervisiTabelaPoslovniOglas(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaPoslovniOglas` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaPreduzeca(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaPreduzeca` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaSamoaktualizacija(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaSamoaktualizacija` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaUpravljanjeVremenom(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaUpravljanjeVremenom` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaOpstaInteresovanja(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaOpstaInteresovanja` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch(Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaKredibilitet(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaKredibilitet` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch(Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaID(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaID` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch(Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaMisije(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaMisije` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaPretnje(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaPretnje` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaRazvojnePotrebe(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaRazvojnePotrebe` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaTrenutnoStanje(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaTrenutnoStanje` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaCiljevi(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaCiljevi` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaSnage(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaSnage` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaOsnovnoObrazovanje(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaOsnovnoObrazovanje` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaSanse(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaSanse` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaSlabosti(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaSlabosti` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaOsnovniPodaci(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaOsnovniPodaci` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaFotografije(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaFotografije` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public void RezervisiTabelaVrednovanjeOstvarenja(string korisnik_id)
        {
            string greska = "";
            string insert = "INSERT INTO `TabelaVrednovanjeOstvarenja` (`korisnik_id`) VALUES (?)";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(insert, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("korisnik_id", korisnik_id);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                greska = err.Message;
            }
            finally
            {
                con.Close();
            }
        }

        public string ObezbediKorisnickiKljuc()
        {
            string UserID = "";
            string ErrorMessage = "";
            string UserName = "";

            MembershipUser korisnik = Membership.GetUser();
            UserName = korisnik.UserName.ToString();

            string selectUserID = "SELECT  `UserId` FROM  `aspnet_Users` WHERE `UserName`= `?`";
            OleDbConnection con = new OleDbConnection(connectionStringKristal);
            OleDbCommand cmd = new OleDbCommand(selectUserID, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("UserName", UserName);
            OleDbDataReader reader;
            try
            {
                con.Open();
                reader = cmd.ExecuteReader();
                reader.Read();
                UserID = reader["UserId"].ToString();
                reader.Close();
            }

            catch (Exception err)
            {
                ErrorMessage = err.Message;
            }

            finally
            {
                con.Close();
            }

            return UserID;
        }

        public string ObezbediKorisnickoIme()
        {
            string UserName = "";
            string ErrorMessage = "";

            try
            {
                MembershipUser korisnik = Membership.GetUser();
                UserName = korisnik.UserName.ToString();
            }
            catch (NullReferenceException e)
            {
                ErrorMessage = e.Message;
            }

            return UserName;
        }

        public string ObezbediKorisnickiEmail()
        {
            string UserEmail = "";
            string ErrorMessage = "";

            try
            {
                MembershipUser korisnik = Membership.GetUser();
                UserEmail = korisnik.Email.ToString();
            }
            catch (NullReferenceException e)
            {
                ErrorMessage = e.Message;
            }

            return UserEmail;
        }

        public string ObezbediBrojPrijavljenihKorisnika()
        {
            string BrPrijavljenihKorisnika = "";
            string ErrorMessage = "";

            try
            {
                BrPrijavljenihKorisnika =
                    System.Web.Security.Membership.GetNumberOfUsersOnline().ToString();
            }
            catch (NullReferenceException e)
            {
                ErrorMessage = e.Message;
            }

            return BrPrijavljenihKorisnika;
        }

        public string ObezbediBrojRegistrovanihKorisnika()
        {
            string BrKorisnika = "";
            string ErrorMessage = "";
            int brojac = 0;

            try
            {
                string query = "SELECT * FROM TabelaID";
                OleDbConnection con = new OleDbConnection(connectionStringKristal);
                OleDbCommand cmd = new OleDbCommand(query, con);
                OleDbDataReader reader;

                try
                {
                    con.Open();
                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        brojac++;
                    }
                    reader.Close();
                    BrKorisnika = (String)brojac.ToString();
                }
                catch (Exception e)
                {
                    ErrorMessage = e.Message;
                }
                finally
                {
                    con.Close();
                }
            }
            catch (NullReferenceException e)
            {
                ErrorMessage = e.Message;
            }

            return BrKorisnika;
        }
    }
}


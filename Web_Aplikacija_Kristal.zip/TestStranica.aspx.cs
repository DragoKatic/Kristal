﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class TestStranica : System.Web.UI.Page
{
    private string connectionStringKristal =
        WebConfigurationManager.ConnectionStrings["KristalKonekcija"].ConnectionString;
    
    private string connectionStringAspnetDb =
        WebConfigurationManager.ConnectionStrings["AspnetDbKonekcija"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            IzvestajKristal();
            IzvestajAspnetDb();
            IzvestajKorisnik();
        }
    }

    protected void IzvestajKristal()
    {
        OleDbConnection con = new OleDbConnection(connectionStringKristal);

        lblStatusKonekcijeKristal.Text = "<br />";

        try
        {
            con.Open();

            lblStatusKonekcijeKristal.Text +=
                "<b>Connection is: </b>" + con.State.ToString() + "<br /><br />";
            lblStatusKonekcijeKristal.Text +=
                "<b>Server Version: </b>" + con.ServerVersion.ToString() + "<br />";
            lblStatusKonekcijeKristal.Text +=
                "<b>Data Source: </b>" + con.DataSource.ToString() + "<br />";
            lblStatusKonekcijeKristal.Text +=
                "<b>ConnectionString: </b>" + con.ConnectionString.ToString() + "<br />";
            lblStatusKonekcijeKristal.Text +=
                "<b>ConnectionTimeout: </b>" + con.ConnectionTimeout.ToString() + "<br />";
        }

        catch (Exception err)
        {
            lblStatusKonekcijeKristal.Text += "Error reading database <br />";
            lblStatusKonekcijeKristal.Text += err.Message;
        }

        finally
        {
            con.Close();

            lblStatusKonekcijeKristal.Text += "<br />";
            lblStatusKonekcijeKristal.Text += "<b>Now Connection Is: </b>";
            lblStatusKonekcijeKristal.Text += con.State.ToString();
            lblStatusKonekcijeKristal.Text += "<br />";
        }
    }

    protected void IzvestajAspnetDb()
    {
        SqlConnection con = new SqlConnection(connectionStringAspnetDb);

        lblStatusKonekcijeAspnetDbKonekcija.Text = "<br />";

        try
        {
            con.Open();

            lblStatusKonekcijeAspnetDbKonekcija.Text +=
                "<b>Connection is: </b>" + con.State.ToString() + "<br /><br />";
            lblStatusKonekcijeAspnetDbKonekcija.Text +=
                "<b>Server Version: </b>" + con.ServerVersion.ToString() + "<br />";
            lblStatusKonekcijeAspnetDbKonekcija.Text +=
                "<b>Data Source: </b>" + con.DataSource.ToString() + "<br />";
            lblStatusKonekcijeAspnetDbKonekcija.Text +=
                "<b>ConnectionString: </b>" + con.ConnectionString.ToString() + "<br />";
            lblStatusKonekcijeAspnetDbKonekcija.Text +=
                "<b>ConnectionTimeout: </b>" + con.ConnectionTimeout.ToString() + "<br />";
        }

        catch (Exception err)
        {
            lblStatusKonekcijeAspnetDbKonekcija.Text += "Error reading database <br />";
            lblStatusKonekcijeAspnetDbKonekcija.Text += err.Message;
        }

        finally
        {
            con.Close();

            lblStatusKonekcijeAspnetDbKonekcija.Text += "<br />";
            lblStatusKonekcijeAspnetDbKonekcija.Text += "<b>Now Connection Is: </b>";
            lblStatusKonekcijeAspnetDbKonekcija.Text += con.State.ToString();
            lblStatusKonekcijeAspnetDbKonekcija.Text += "<br />";
        }
    }

    protected void IzvestajKorisnik()
    {
        KorisnickiPodaci kp = new KorisnickiPodaci();
        lblKorisnikID.Text = kp.ObezbediKorisnickiKljuc();
    }
}

﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;
using System.Data.OleDb;
using System.Web.Configuration;

public partial class Rukovodioci_SwotZaposlenih : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            UcitajPodatke_ImenaZaposlenih();
        }
    }

    private string connectionStringKristal =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;

    protected void UcitajPodatke_ImenaZaposlenih()
    {
        ddlImenaRadnika.Items.Clear();

        string greska = "";
        string selectTabelaOsnovniPodaci =
            "SELECT `korisnik_id`, `ime`, `prezime` FROM `TabelaOsnovniPodaci`";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(selectTabelaOsnovniPodaci, con);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                ListItem newItem = new ListItem();
                newItem.Text = reader["ime"] + "  " + reader["prezime"];
                newItem.Value = reader["korisnik_id"].ToString();
                ddlImenaRadnika.Items.Add(newItem);
            }

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }


    }

    protected void ddlImenaRadnika_SelectedIndexChanged(object sender, EventArgs e)
    {
        UcitajPodatke_TabelaSnage();
        UcitajPodatke_TabelaSlabosti();
        UcitajPodatke_TabelaSanse();
        UcitajPodatke_TabelaPretnje();
    }

    protected void UcitajPodatke_TabelaSnage()
    {
        string greska = "";
        lblSnage.Text = "";
        string selectTabelaSnage =
            "SELECT * FROM [TabelaSnage] WHERE ([korisnik_id] = '" + ddlImenaRadnika.SelectedItem.Value + "')";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(selectTabelaSnage, con);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            lblSnage.Text += "<br />";
            lblSnage.Text += reader["snaga_1"];
            lblSnage.Text += "<br />";
            lblSnage.Text += reader["snaga_2"];
            lblSnage.Text += "<br />";
            lblSnage.Text += reader["snaga_3"];
            lblSnage.Text += "<br />";
            lblSnage.Text += reader["snaga_4"];
            lblSnage.Text += "<br />";
            lblSnage.Text += reader["snaga_5"];
            lblSnage.Text += "<br />";
            lblSnage.Text += reader["snaga_6"];
            lblSnage.Text += "<br /><br />";

            reader.Close();
        }
        catch (Exception err)
        {
            greska = err.Message;
        }
        finally
        {
            con.Close();
        }
    }

    protected void UcitajPodatke_TabelaSlabosti()
    {
        string greska = "";
        lblSlabosti.Text = "";
        string selectTabelaSlabosti =
            "SELECT * FROM [TabelaSlabosti] WHERE ([korisnik_id] = '" + ddlImenaRadnika.SelectedItem.Value + "')";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(selectTabelaSlabosti, con);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            lblSlabosti.Text += "<br />";
            lblSlabosti.Text += reader["slabost_1"];
            lblSlabosti.Text += "<br />";
            lblSlabosti.Text += reader["slabost_2"];
            lblSlabosti.Text += "<br />";
            lblSlabosti.Text += reader["slabost_3"];
            lblSlabosti.Text += "<br />";
            lblSlabosti.Text += reader["slabost_4"];
            lblSlabosti.Text += "<br />";
            lblSlabosti.Text += reader["slabost_5"];
            lblSlabosti.Text += "<br />";
            lblSlabosti.Text += reader["slabost_6"];
            lblSlabosti.Text += "<br /><br />";

            reader.Close();
        }
        catch (Exception err)
        {
            greska = err.Message;
        }
        finally
        {
            con.Close();
        }
    }
    protected void UcitajPodatke_TabelaSanse()
    {
        string greska = "";
        lblSanse.Text = "";
        string selectTabelaSanse =
            "SELECT * FROM [TabelaSanse] WHERE ([korisnik_id] = '" + ddlImenaRadnika.SelectedItem.Value + "')";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(selectTabelaSanse, con);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            lblSanse.Text += "<br />";
            lblSanse.Text += reader["sansa_1"];
            lblSanse.Text += "<br />";
            lblSanse.Text += reader["sansa_2"];
            lblSanse.Text += "<br />";
            lblSanse.Text += reader["sansa_3"];
            lblSanse.Text += "<br />";
            lblSanse.Text += reader["sansa_4"];
            lblSanse.Text += "<br />";
            lblSanse.Text += reader["sansa_5"];
            lblSanse.Text += "<br />";
            lblSanse.Text += reader["sansa_6"];
            lblSanse.Text += "<br /><br />";

            reader.Close();
        }
        catch (Exception err)
        {
            greska = err.Message;
        }
        finally
        {
            con.Close();
        }
    }
    protected void UcitajPodatke_TabelaPretnje()
    {
        string greska = "";
        lblPretnje.Text = "";
        string selectTabelaPretnje =
            "SELECT * FROM [TabelaPretnje] WHERE ([korisnik_id] = '" + ddlImenaRadnika.SelectedItem.Value + "')";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(selectTabelaPretnje, con);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            lblPretnje.Text += "<br />";
            lblPretnje.Text += reader["pretnja_1"];
            lblPretnje.Text += "<br />";
            lblPretnje.Text += reader["pretnja_2"];
            lblPretnje.Text += "<br />";
            lblPretnje.Text += reader["pretnja_3"];
            lblPretnje.Text += "<br />";
            lblPretnje.Text += reader["pretnja_4"];
            lblPretnje.Text += "<br />";
            lblPretnje.Text += reader["pretnja_5"];
            lblPretnje.Text += "<br />";
            lblPretnje.Text += reader["pretnja_6"];
            lblPretnje.Text += "<br /><br />";

            reader.Close();
        }
        catch (Exception err)
        {
            greska = err.Message;
        }
        finally
        {
            con.Close();
        }
    }


}

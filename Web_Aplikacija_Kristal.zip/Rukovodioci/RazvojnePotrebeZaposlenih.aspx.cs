﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using KristalBiblioteka;
using System.Data.OleDb;
using System.Web.Configuration;

public partial class Rukovodioci_RazvojnePotrebeZaposlenih : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            UcitajPodatke_ImenaZaposlenih();
        }
    }

    private string connectionStringKristal =
                WebConfigurationManager.ConnectionStrings[
                "KristalKonekcija"].ConnectionString;

    protected void UcitajPodatke_ImenaZaposlenih()
    {
        ddlImenaRadnika.Items.Clear();

        string greska = "";
        string selectTabelaOsnovniPodaci =
            "SELECT `korisnik_id`, `ime`, `prezime` FROM `TabelaOsnovniPodaci`";

        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(selectTabelaOsnovniPodaci, con);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                ListItem newItem = new ListItem();
                newItem.Text = reader["ime"] + "  " + reader["prezime"];
                newItem.Value = reader["korisnik_id"].ToString();
                ddlImenaRadnika.Items.Add(newItem);
            }

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }


    }
    protected void ddlImenaRadnika_SelectedIndexChanged(Object sender, EventArgs e)
    {
        string greska = "";
        string selectTabelaRazvojnePotrebe =
            "SELECT * FROM [TabelaRazvojnePotrebe] WHERE ([korisnik_id] = '" + ddlImenaRadnika.SelectedItem.Value + "')";
        

        lblOpis1.Text = "";
        lblCilj1.Text = "";
        lblAktivnosti1.Text = "";
        lblResursi1.Text = "";
        chkBoxOstvareno1.Checked = false;

        lblOpis2.Text = "";
        lblCilj2.Text = "";
        lblAktivnosti2.Text = "";
        lblResursi2.Text = "";
        chkBoxOstvareno2.Checked = false;

        lblOpis3.Text = "";
        lblCilj3.Text = "";
        lblAktivnosti3.Text = "";
        lblResursi3.Text = "";
        chkBoxOstvareno3.Checked = false;

        lblOpis4.Text = "";
        lblCilj4.Text = "";
        lblAktivnosti4.Text = "";
        lblResursi4.Text = "";
        chkBoxOstvareno4.Checked = false;

        lblOpis5.Text = "";
        lblCilj5.Text = "";
        lblAktivnosti5.Text = "";
        lblResursi5.Text = "";
        chkBoxOstvareno5.Checked = false;

        lblOpis6.Text = "";
        lblCilj6.Text = "";
        lblAktivnosti6.Text = "";
        lblResursi6.Text = "";
        chkBoxOstvareno6.Checked = false;
        
        OleDbConnection con = new OleDbConnection(connectionStringKristal);
        OleDbCommand cmd = new OleDbCommand(selectTabelaRazvojnePotrebe, con);
        OleDbDataReader reader;

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            reader.Read();

            lblOpis1.Text += "<b>";
            lblOpis1.Text += "Opis ponašanja: </b></br>";
            lblOpis1.Text += reader["opis_ponasanja_1"];
            lblOpis1.Text += "</br>";
            lblCilj1.Text += "<b>";
            lblCilj1.Text += "Cilj karijere: </b></br>";
            lblCilj1.Text += reader["cilj_karijere_1"];
            lblCilj1.Text += "</br>";
            lblAktivnosti1.Text += "<b>";
            lblAktivnosti1.Text += "Način za dostizanje cilja: </b></br>";
            lblAktivnosti1.Text += reader["aktivnosti_1"];
            lblAktivnosti1.Text += "</br>";
            lblResursi1.Text += "<b>";
            lblResursi1.Text += "Potrebni resursi: </b></br>";
            lblResursi1.Text += reader["potrebni_resursi_1"];
            lblResursi1.Text += "</br>";
            kalendarVremenskiRok1.SelectedDate = Convert.ToDateTime(reader["vremenski_rok_1"].ToString());
            chkBoxOstvareno1.Checked = Convert.ToBoolean(reader["ostvareno_1"].ToString());

            lblOpis2.Text += "<b>";
            lblOpis2.Text += "Opis ponašanja: </b></br>";
            lblOpis2.Text += reader["opis_ponasanja_2"];
            lblOpis2.Text += "</br>";
            lblCilj2.Text += "<b>";
            lblCilj2.Text += "Cilj karijere: </b></br>";
            lblCilj2.Text += reader["cilj_karijere_2"];
            lblCilj2.Text += "</br>";
            lblAktivnosti2.Text += "<b>";
            lblAktivnosti2.Text += "Način za dostizanje cilja: </b></br>";
            lblAktivnosti2.Text += reader["aktivnosti_2"];
            lblAktivnosti2.Text += "</br>";
            lblResursi2.Text += "<b>";
            lblResursi2.Text += "Potrebni resursi: </b></br>";
            lblResursi2.Text += reader["potrebni_resursi_2"];
            lblResursi2.Text += "</br>";
            kalendarVremenskiRok2.SelectedDate = Convert.ToDateTime(reader["vremenski_rok_2"].ToString());
            chkBoxOstvareno2.Checked = Convert.ToBoolean(reader["ostvareno_2"].ToString());

            lblOpis3.Text += "<b>";
            lblOpis3.Text += "Opis ponašanja: </b></br>";
            lblOpis3.Text += reader["opis_ponasanja_3"];
            lblOpis3.Text += "</br>";
            lblCilj3.Text += "<b>";
            lblCilj3.Text += "Cilj karijere: </b></br>";
            lblCilj3.Text += reader["cilj_karijere_3"];
            lblCilj3.Text += "</br>";
            lblAktivnosti3.Text += "<b>";
            lblAktivnosti3.Text += "Način za dostizanje cilja: </b></br>";
            lblAktivnosti3.Text += reader["aktivnosti_3"];
            lblAktivnosti3.Text += "</br>";
            lblResursi3.Text += "<b>";
            lblResursi3.Text += "Potrebni resursi: </b></br>";
            lblResursi3.Text += reader["potrebni_resursi_3"];
            lblResursi3.Text += "</br>";
            kalendarVremenskiRok3.SelectedDate = Convert.ToDateTime(reader["vremenski_rok_3"].ToString());
            chkBoxOstvareno3.Checked = Convert.ToBoolean(reader["ostvareno_3"].ToString());

            lblOpis4.Text += "<b>";
            lblOpis4.Text += "Opis ponašanja: </b></br>";
            lblOpis4.Text += reader["opis_ponasanja_4"];
            lblOpis4.Text += "</br>";
            lblCilj4.Text += "<b>";
            lblCilj4.Text += "Cilj karijere: </b></br>";
            lblCilj4.Text += reader["cilj_karijere_4"];
            lblCilj4.Text += "</br>";
            lblAktivnosti4.Text += "<b>";
            lblAktivnosti4.Text += "Način za dostizanje cilja: </b></br>";
            lblAktivnosti4.Text += reader["aktivnosti_4"];
            lblAktivnosti4.Text += "</br>";
            lblResursi4.Text += "<b>";
            lblResursi4.Text += "Potrebni resursi: </b></br>";
            lblResursi4.Text += reader["potrebni_resursi_4"];
            lblResursi4.Text += "</br>";
            kalendarVremenskiRok4.SelectedDate = Convert.ToDateTime(reader["vremenski_rok_4"].ToString());
            chkBoxOstvareno4.Checked = Convert.ToBoolean(reader["ostvareno_4"].ToString());

            lblOpis5.Text += "<b>";
            lblOpis5.Text += "Opis ponašanja: </b></br>";
            lblOpis5.Text += reader["opis_ponasanja_5"];
            lblOpis5.Text += "</br>";
            lblCilj5.Text += "<b>";
            lblCilj5.Text += "Cilj karijere: </b></br>";
            lblCilj5.Text += reader["cilj_karijere_5"];
            lblCilj5.Text += "</br>";
            lblAktivnosti5.Text += "<b>";
            lblAktivnosti5.Text += "Način za dostizanje cilja: </b></br>";
            lblAktivnosti5.Text += reader["aktivnosti_5"];
            lblAktivnosti5.Text += "</br>";
            lblResursi5.Text += "<b>";
            lblResursi5.Text += "Potrebni resursi: </b></br>";
            lblResursi5.Text += reader["potrebni_resursi_5"];
            lblResursi5.Text += "</br>";
            kalendarVremenskiRok5.SelectedDate = Convert.ToDateTime(reader["vremenski_rok_5"].ToString());
            chkBoxOstvareno5.Checked = Convert.ToBoolean(reader["ostvareno_5"].ToString());

            lblOpis6.Text += "<b>";
            lblOpis6.Text += "Opis ponašanja: </b></br>";
            lblOpis6.Text += reader["opis_ponasanja_6"];
            lblOpis6.Text += "</br>";
            lblCilj6.Text += "<b>";
            lblCilj6.Text += "Cilj karijere: </b></br>";
            lblCilj6.Text += reader["cilj_karijere_6"];
            lblCilj6.Text += "</br>";
            lblAktivnosti6.Text += "<b>";
            lblAktivnosti6.Text += "Način za dostizanje cilja: </b></br>";
            lblAktivnosti6.Text += reader["aktivnosti_6"];
            lblAktivnosti6.Text += "</br>";
            lblResursi6.Text += "<b>";
            lblResursi6.Text += "Potrebni resursi: </b></br>";
            lblResursi6.Text += reader["potrebni_resursi_6"];
            lblResursi6.Text += "</br>";
            kalendarVremenskiRok6.SelectedDate = Convert.ToDateTime(reader["vremenski_rok_6"].ToString());
            chkBoxOstvareno6.Checked = Convert.ToBoolean(reader["ostvareno_6"].ToString());

            reader.Close();
        }

        catch (Exception err)
        {
            greska = err.Message;
        }

        finally
        {
            con.Close();
        }

    }
}
